package utils;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;


/**
 * Provides validation rules for employee-related form input.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class EmployeeValidator {

    private static final Pattern NAME_PATTERN =
            Pattern.compile("^[\\p{L}\\s'.-]+$");

    private static final Pattern ADDRESS_PATTERN =
            Pattern.compile("[\\p{L}\\d\\s.,'\\-/#]+");

    private static final Pattern PHONE_PATTERN =
        Pattern.compile("^[0-9\\-\\s()+]+$");

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private static final Pattern SUPERVISOR_PATTERN =
            Pattern.compile("^[\\p{L}\\d\\s'./-]+$");

    private static final Pattern SSS_PATTERN =
            Pattern.compile("\\d{2}-\\d{7}-\\d");

    private static final Pattern PHILHEALTH_PATTERN =
            Pattern.compile("\\d{12}");

    private static final Pattern TIN_PATTERN =
            Pattern.compile("\\d{3}-\\d{3}-\\d{3}-\\d{3}");

    private static final Pattern PAGIBIG_PATTERN =
            Pattern.compile("\\d{12}");

    public static boolean isValidRequiredText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    public static boolean isValidName(String value) {
        return isValidRequiredText(value)
                && NAME_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidAddress(String value) {
        return isValidRequiredText(value)
                && ADDRESS_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidPhone(String value) {
        return value != null
                && PHONE_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidEmail(String value) {
        return isValidRequiredText(value)
                && EMAIL_PATTERN.matcher(value.trim()).matches()
                && !value.contains("..");
    }

    public static boolean isValidSupervisor(String value) {
        return isValidRequiredText(value)
                && SUPERVISOR_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidSSS(String value) {
        return value != null
                && SSS_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidPhilHealth(String value) {
        return value != null
                && PHILHEALTH_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidTIN(String value) {
        return value != null
                && TIN_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidPagibig(String value) {
        return value != null
                && PAGIBIG_PATTERN.matcher(value.trim()).matches();
    }

    public static boolean isValidBirthday(LocalDate birthday) {
        return birthday != null
                && !birthday.isAfter(LocalDate.now())
                && Period.between(birthday, LocalDate.now()).getYears() >= 18;
    }

    public static boolean isValidCompensation(String value) {
        if (value == null || value.trim().isEmpty()) {
            return false;
        }

        try {
            double parsed = Double.parseDouble(value.replace(",", "").trim());
            return parsed >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static ValidationResult validateEmployeeUpdateFields(
            String firstName,
            String lastName,
            String street,
            String barangay,
            String city,
            String province,
            String zipcode,
            String phone,
            String email,
            String sss,
            String philHealth,
            String tin,
            String pagibig,
            String supervisor,
            LocalDate birthday,
            String basicSalary,
            String riceSubsidy,
            String phoneAllowance,
            String clothingAllowance
    ) {
        ValidationResult result = new ValidationResult();

        if (!isValidName(firstName)) {
            result.addError("First name is required and must not contain invalid characters.");
        }

        if (!isValidName(lastName)) {
            result.addError("Last name is required and must not contain invalid characters.");
        }

        if (!isValidAddress(street)) {
            result.addError("Street is required and must not contain invalid characters.");
        }

        if (!isValidAddress(barangay)) {
            result.addError("Barangay is required and must not contain invalid characters.");
        }

        if (!isValidAddress(city)) {
            result.addError("City is required and must not contain invalid characters.");
        }

        if (!isValidAddress(province)) {
            result.addError("Province is required and must not contain invalid characters.");
        }

        if (!isValidZipcode(zipcode)) {
            result.addError("Zip code is required and must contain numbers only.");
}

        if (!isValidPhone(phone)) {
            result.addError("Phone number must be in ###-###-### format.");
        }

        if (!isValidEmail(email)) {
            result.addError("Email address is invalid.");
        }

        if (!isValidSSS(sss)) {
            result.addError("SSS Number must be in XX-XXXXXXX-X format.");
        }

        if (!isValidPhilHealth(philHealth)) {
            result.addError("PhilHealth Number must contain exactly 12 digits.");
        }

        if (!isValidTIN(tin)) {
            result.addError("TIN Number must be in XXX-XXX-XXX-XXX format.");
        }

        if (!isValidPagibig(pagibig)) {
            result.addError("Pag-IBIG Number must contain exactly 12 digits.");
        }

        if (isValidRequiredText(supervisor) && !isValidSupervisor(supervisor)) {
            result.addError("Supervisor name contains invalid characters.");
        }

        if (!isValidBirthday(birthday)) {
            result.addError("Employee must be at least 18 years old.");
        }

        if (!isValidCompensation(basicSalary)
                || !isValidCompensation(riceSubsidy)
                || !isValidCompensation(phoneAllowance)
                || !isValidCompensation(clothingAllowance)) {
            result.addError("Salary and allowances must be valid numbers.");
        }

        return result;
    }

    public static class ValidationResult {

        private final List<String> errors = new ArrayList<>();

        public boolean isValid() {
            return errors.isEmpty();
        }

        public List<String> getErrors() {
            return new ArrayList<>(errors);
        }

        public void addError(String message) {
            if (message != null && !errors.contains(message)) {
                errors.add(message);
            }
        }

        public void showErrors() {
            if (!isValid()) {
                StringBuilder message =
                        new StringBuilder("Please fix the following errors:\n\n");

                for (String error : errors) {
                    message.append("• ").append(error).append("\n");
                }

                JOptionPane.showMessageDialog(
                        null,
                        message.toString(),
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    public static boolean isValidZipcode(String value) {
        return value != null
            && !value.trim().isEmpty()
            && value.trim().matches("^\\d+$");
    }
}