package utils;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Provides shared date and time formatting utilities.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class DateTimeUtils {

    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("HH:mm");

    private static final DateTimeFormatter TIME_WITH_SECONDS_FORMAT =
            DateTimeFormatter.ofPattern("hh:mm:ss a");

    public static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    private static final DateTimeFormatter MONTH_FORMAT =
            DateTimeFormatter.ofPattern("MMM");

    private static final DateTimeFormatter DAY_FORMAT =
            DateTimeFormatter.ofPattern("dd");

    // Format current time (HH:mm)
    public static String getCurrentTime() {
        return LocalTime.now().format(TIME_FORMAT);
    }

    // Format current time with seconds (for dashboard clock)
    public static String getCurrentTimeWithSeconds() {
        return LocalTime.now().format(TIME_WITH_SECONDS_FORMAT);
    }

    // Format current date
    public static String getCurrentDate() {
        return LocalDate.now().format(DATE_FORMAT);
    }

    // Format current month
    public static String getCurrentMonth() {
        return LocalDate.now().format(MONTH_FORMAT).toUpperCase();
    }

    // Format current day
    public static String getCurrentDay() {
        return LocalDate.now().format(DAY_FORMAT);
    }
}
