package utils;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Provides numeric formatting helpers for payroll and display values.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class NumberFormattingUtils {

    // Formatter instance for Philippine Peso currency
    private static final NumberFormat formatter;

    static {
        // Set up formatter using English (Philippines) locale
        Locale philippineLocale = new Locale("en", "PH");
        formatter = NumberFormat.getCurrencyInstance(philippineLocale);
        formatter.setMinimumFractionDigits(2); // Always show 2 decimal places
        formatter.setMaximumFractionDigits(2); // Cap at 2 decimal places
    }

    /**
     * Formats a double value as Philippine Peso (₱), with comma separators.
     *
     * Example: 1000.5 → ₱1,000.50
     *
     * @param value the numeric value to format
     * @return a string formatted as currency (Example: ₱1,000.50)
     */
    public static String formatCurrency(double value) {
        return formatter.format(value);
    }

    /**
     * Formats a double value to two decimal places, with commas,
     * but without the peso symbol (₱).
     *
     * Example: 1000.5 → 1,000.50
     *
     * @param value the numeric value to format
     * @return a plain number string with commas (Example: 1,000.50)
     */
    public static String formatPlainNumber(double value) {
        return String.format("%,.2f", value);
    }

    /**
     * Formats a double value to two decimal places,
     * with no commas and no currency symbol.
     *
     * Example: 1000.5 → 1000.50
     *
     * or computations that require raw number formatting.
     *
     * @param value the numeric value to format
     * @return a plain string (Example: 1000.50)
     */
    public static String formatPlainRawNumber(double value) {
        return String.format("%.2f", value);
    }
}
