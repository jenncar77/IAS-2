package utils;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * Provides shared window and navigation utilities for Swing frames.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class WindowUtils {

    /**
     * Applies standard configuration settings to a JFrame.
     * This ensures a consistent look and behavior across all system windows.
     *
     * Configuration applied:
     * - Sets the window title
     * - Centers the window on the screen
     * - Disables resizing to preserve layout consistency
     *
     * @param frame the JFrame to configure
     * @param title the window title
     */
    public static void applyStandardWindowConfig(JFrame frame, String title) {
        frame.setTitle(title);                 // Apply system window title
        frame.setLocationRelativeTo(null);     // Center window on screen
        frame.setResizable(false);             // Prevent resizing to keep layout stable
    }

    /**
     * Makes a JLabel behave like a clickable UI element.
     * This method adds hover effects and executes a custom action when clicked.
     *
     * Behavior added:
     * - Cursor changes to a hand pointer
     * - Text color changes on hover
     * - Executes a provided action when clicked
     *
     * Example usage:
     * WindowUtils.applyClickableLabelAction(lblHelp, () -> openHelp());
     *
     * @param label the JLabel to make interactive
     * @param action the action to execute when the label is clicked
     */
    public static void applyClickableLabelAction(JLabel label, Runnable action) {
        Color originalColor = Color.WHITE;
        Color hoverColor = new Color(173, 216, 230); // sidebar hover color

        label.setForeground(originalColor);
        label.setCursor(new Cursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (action != null) {
                    action.run();
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(hoverColor);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(originalColor);
            }
        });
    }

    /**
     * Applies navigation behavior to sidebar labels.
     * When the label is clicked, the system opens another frame
     * and closes the current one.
     *
     * Behavior added:
     * - Cursor changes to hand pointer
     * - Hover feedback
     * - Opens destination frame
     * - Closes the parent frame
     *
     * Example usage:
     * WindowUtils.applyNavigationLabel(lblPayroll, this, new PayrollFrame());
     *
     * @param label the sidebar JLabel acting as a navigation button
     * @param parent the current JFrame that will be closed
     * @param destination the JFrame to open when clicked
     */
    public static void applyNavigationLabel(JLabel label, JFrame parent, JFrame destination) {

        label.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Show clickable cursor

        label.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                if (destination != null) {
                    destination.setVisible(true);    // Open destination window
                }

                if (parent != null) {
                    parent.dispose();                // Close current window
                }
            }
        });
    }

}
