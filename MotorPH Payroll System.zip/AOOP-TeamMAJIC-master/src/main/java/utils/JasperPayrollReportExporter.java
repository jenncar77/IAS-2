package utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;

/**
 * Exports payroll summary data using the JasperReports monthly report template.
 */
public class JasperPayrollReportExporter {

    private static final String JRXML_TEMPLATE = "/reports/PayrollReportPerDepartment.jrxml";

    public static void exportPayrollReport(
            String department,
            String payrollPeriod,
            double totalGrossSalary,
            double totalDeductions,
            double totalNetPay,
            String outputFilePath
    ) {
        exportReport(
                department,
                payrollPeriod,
                totalGrossSalary,
                totalDeductions,
                totalNetPay,
                new JREmptyDataSource(),
                outputFilePath
        );
    }

    public static void exportPayrollReportFromTable(
            TableModel payrollTableModel,
            String payrollPeriod,
            double totalGrossSalary,
            double totalDeductions,
            double totalNetPay,
            String outputFilePath
    ) {
        exportReport(
                "All Departments",
                payrollPeriod,
                totalGrossSalary,
                totalDeductions,
                totalNetPay,
                createTableDataSource(payrollTableModel),
                outputFilePath
        );
    }

    private static void exportReport(
            String department,
            String payrollPeriod,
            double totalGrossSalary,
            double totalDeductions,
            double totalNetPay,
            JRDataSource dataSource,
            String outputFilePath
    ) {
        try {
            JasperReport jasperReport = loadReport();

            Map<String, Object> params = new HashMap<>();
            params.put("Department", department);
            params.put("department", department);
            params.put("payrollPeriod", payrollPeriod);
            params.put("totalGrossSalary", totalGrossSalary);
            params.put("totalDeductions", totalDeductions);
            params.put("totalNetPay", totalNetPay);

            JasperPrint jasperPrint = JasperFillManager.fillReport(
                    jasperReport,
                    params,
                    dataSource
            );

            JasperExportManager.exportReportToPdfFile(jasperPrint, outputFilePath);
        } catch (Exception e) {
            throw new RuntimeException("Failed to export payroll report: " + e.getMessage(), e);
        }
    }

    private static JasperReport loadReport() throws Exception {
        configureJasperCompilerClasspath();

        try (var reportStream = JasperPayrollReportExporter.class.getResourceAsStream(JRXML_TEMPLATE)) {
            if (reportStream == null) {
                throw new RuntimeException("PayrollReportPerDepartment.jrxml not found in resources/reports.");
            }

            return JasperCompileManager.compileReport(reportStream);
        }
    }

    private static JRMapCollectionDataSource createTableDataSource(TableModel model) {
        List<Map<String, ?>> rows = new ArrayList<>();

        if (model == null) {
            return new JRMapCollectionDataSource(rows);
        }

        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalSss = BigDecimal.ZERO;
        BigDecimal totalPhilhealth = BigDecimal.ZERO;
        BigDecimal totalPagibig = BigDecimal.ZERO;
        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;

        for (int row = 0; row < model.getRowCount(); row++) {
            BigDecimal grossPay = toBigDecimal(model.getValueAt(row, 4));
            BigDecimal sssContribution = toBigDecimal(model.getValueAt(row, 6));
            BigDecimal philhealthContribution = toBigDecimal(model.getValueAt(row, 8));
            BigDecimal pagibigContribution = toBigDecimal(model.getValueAt(row, 10));
            BigDecimal withholdingTax = toBigDecimal(model.getValueAt(row, 12));
            BigDecimal netPay = toBigDecimal(model.getValueAt(row, 13));

            Map<String, Object> record = new HashMap<>();
            record.put("employee_number", safeText(model.getValueAt(row, 0)));
            record.put("employee_name", safeText(model.getValueAt(row, 1)));
            record.put("position_name", safeText(model.getValueAt(row, 2)));
            record.put("department_name", safeText(model.getValueAt(row, 3)));
            record.put("gross_pay", grossPay);
            record.put("sss_number", safeText(model.getValueAt(row, 5)));
            record.put("sss_contribution", sssContribution);
            record.put("philhealth_number", safeText(model.getValueAt(row, 7)));
            record.put("philhealth_contribution", philhealthContribution);
            record.put("pagibig_number", safeText(model.getValueAt(row, 9)));
            record.put("pagibig_contribution", pagibigContribution);
            record.put("tin_number", safeText(model.getValueAt(row, 11)));
            record.put("withholding_tax", withholdingTax);
            record.put("net_pay", netPay);
            rows.add(record);

            totalGross = totalGross.add(grossPay);
            totalSss = totalSss.add(sssContribution);
            totalPhilhealth = totalPhilhealth.add(philhealthContribution);
            totalPagibig = totalPagibig.add(pagibigContribution);
            totalTax = totalTax.add(withholdingTax);
            totalNet = totalNet.add(netPay);
        }

        if (!rows.isEmpty()) {
            Map<String, Object> totalRecord = new HashMap<>();
            totalRecord.put("employee_number", "TOTAL");
            totalRecord.put("employee_name", "");
            totalRecord.put("position_name", "");
            totalRecord.put("department_name", "");
            totalRecord.put("gross_pay", totalGross);
            totalRecord.put("sss_number", "");
            totalRecord.put("sss_contribution", totalSss);
            totalRecord.put("philhealth_number", "");
            totalRecord.put("philhealth_contribution", totalPhilhealth);
            totalRecord.put("pagibig_number", "");
            totalRecord.put("pagibig_contribution", totalPagibig);
            totalRecord.put("tin_number", "");
            totalRecord.put("withholding_tax", totalTax);
            totalRecord.put("net_pay", totalNet);
            rows.add(totalRecord);
        }

        return new JRMapCollectionDataSource(rows);
    }

    private static String safeText(Object value) {
        return value == null ? "" : value.toString();
    }
    private static BigDecimal toBigDecimal(Object value) {
        if (value instanceof BigDecimal decimal) {
            return decimal;
        }
        if (value instanceof Number number) {
            return BigDecimal.valueOf(number.doubleValue());
        }

        String text = safeText(value).replace(",", "").replace("₱", "").trim();
        return text.isEmpty() ? BigDecimal.ZERO : new BigDecimal(text);
    }

    private static void configureJasperCompilerClasspath() {
        System.setProperty(
                "net.sf.jasperreports.compiler.classpath",
                System.getProperty("java.class.path")
        );
    }
}