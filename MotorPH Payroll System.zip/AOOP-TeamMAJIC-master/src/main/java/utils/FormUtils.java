package utils;

import model.EmployeeDetails;
import model.PayrollSummary;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.io.IOException;
import java.time.LocalDate;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import com.toedter.calendar.JDateChooser;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Provides shared form utilities for Swing components.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class FormUtils {

    private static final Color LOCKED_COLOR = new Color(204, 204, 204);
    private static final Color EDITABLE_COLOR = Color.WHITE;

     /**
     * Collects employee details from form fields and combo boxes.
     * If a field is left blank, it retains the value from the existing employee (if provided).
     *
     */
public static EmployeeDetails collectEmployeeDetailsFromForm(
        JTextField[] fields,
        JDateChooser jDateChooserBirthday, 
        JComboBox<String> cmbStatus,
        JComboBox<String> cmbPosition
) {
    String empNo = fields[0].getText();
    String lastName = EmployeeFormatter.formatName(fields[1].getText());
    String firstName = EmployeeFormatter.formatName(fields[2].getText());

    String birthday = "";
    if (jDateChooserBirthday.getDate() != null) {
        LocalDate bday = jDateChooserBirthday.getDate().toInstant()
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate();
        java.time.format.DateTimeFormatter formatter =
        java.time.format.DateTimeFormatter.ofPattern("MM/dd/yyyy");
        birthday = bday.format(formatter);
    }

    String address = EmployeeFormatter.formatAddress(fields[3].getText())
        .replace("\"", "")
        .replace(",", " ");
    String phone = EmployeeFormatter.formatPhone(fields[4].getText());
    String email = EmployeeFormatter.formatEmail(fields[5].getText());
    String sss = EmployeeFormatter.formatSSS(fields[6].getText());
    String philhealth = fields[7].getText();
    String tin = EmployeeFormatter.formatTIN(fields[8].getText());
    String pagibig = fields[9].getText();

    String status = (String) cmbStatus.getSelectedItem();
    String position = (String) cmbPosition.getSelectedItem();

    String supervisor = EmployeeFormatter.formatSupervisorName(fields[10].getText(), position);

    // Compensation Fields
    String basicSalary = fields[11].getText().trim();
        String rice = fields[12].getText().trim();
        String phoneAllowance = fields[13].getText().trim();
        String clothing = fields[14].getText().trim();

        String gross = fields[15].getText();
        String hourly = fields[16].getText();

        // Validate & format compensation fields
        if (!EmployeeValidator.isValidCompensation(basicSalary)) {
            showValidationError("Basic Salary");
            return null;
        }
        if (!EmployeeValidator.isValidCompensation(rice)) {
            showValidationError("Rice Subsidy");
            return null;
        }
        if (!EmployeeValidator.isValidCompensation(phoneAllowance)) {
            showValidationError("Phone Allowance");
            return null;
        }
        if (!EmployeeValidator.isValidCompensation(clothing)) {
            showValidationError("Clothing Allowance");
            return null;
        }

        // Format compensation if valid
        basicSalary = String.format("%.2f", safeParseDouble(basicSalary));
        rice = String.format("%.2f", safeParseDouble(rice));
        phoneAllowance = String.format("%.2f", safeParseDouble(phoneAllowance));
        clothing = String.format("%.2f", safeParseDouble(clothing));

        gross = String.format("%.2f", safeParseDouble(fields[15].getText()));
        hourly = String.format("%.2f", safeParseDouble(fields[16].getText()));


    // Reflect formatted values in UI
    fields[1].setText(lastName);
    fields[2].setText(firstName);
    fields[3].setText(address);
    fields[4].setText(phone);
    fields[5].setText(email);
    fields[6].setText(sss);
    fields[8].setText(tin);
    fields[10].setText(supervisor);
    fields[11].setText(basicSalary);
    fields[12].setText(rice);
    fields[13].setText(phoneAllowance);
    fields[14].setText(clothing);

    return new EmployeeDetails(new String[] {
        empNo, lastName, firstName, birthday, address, phone, email,
        sss, philhealth, tin, pagibig, status, position, supervisor,
        basicSalary, rice, phoneAllowance, clothing, gross, hourly
    });
}


    private static void showValidationError(String fieldName) {
        JOptionPane.showMessageDialog(null,
            "Invalid input for " + fieldName + ". Must be a numeric value with 2 decimal places.",
            "Validation Error",
            JOptionPane.WARNING_MESSAGE
        );
    }

    /**
     * Locks all text fields and combo boxes in the container.
     */
    public static void lockAllFields(Container container, boolean matchPanelColor) {
        for (Component c : container.getComponents()) {
            if (c instanceof JTextField field) {
                field.setEditable(false);
                field.setFocusable(false);
                field.setBackground(matchPanelColor ? field.getParent().getBackground() : LOCKED_COLOR);
            } else if (c instanceof JComboBox<?> comboBox) {
                comboBox.setEnabled(false);
                comboBox.setFocusable(false);
                comboBox.setBackground(matchPanelColor ? comboBox.getParent().getBackground() : LOCKED_COLOR);
            } else if (c instanceof Container nested) {
                lockAllFields(nested, matchPanelColor);
            }
        }
    }

    /**
     * Unlocks all fields except for the employee number field.
     */
    public static void unlockAllFieldsExceptEmpNo(Container container) {
        for (Component c : container.getComponents()) {
            if (c instanceof JTextField field) {
                if ("txtfldEmpNo".equals(field.getName())) {
                    field.setEditable(false);
                    field.setFocusable(false);
                    field.setBackground(LOCKED_COLOR);
                } else {
                    field.setEditable(true);
                    field.setFocusable(true);
                    field.setBackground(EDITABLE_COLOR);
                }
            } else if (c instanceof JComboBox<?> comboBox) {
                comboBox.setEnabled(true);
                comboBox.setFocusable(true);
                comboBox.setBackground(EDITABLE_COLOR);
            } else if (c instanceof Container nested) {
                unlockAllFieldsExceptEmpNo(nested);
            }
        }
    }

    /**
     * Clears all form fields in the container.
     */
    public static void clearAllFields(Container container) {
        for (Component c : container.getComponents()) {
            if (c instanceof JTextField field) {
                field.setText("");
            } else if (c instanceof JComboBox<?> comboBox) {
                comboBox.setSelectedIndex(-1);
            } else if (c instanceof Container nested) {
                clearAllFields(nested);
            }
        }
    }

    /**
     * Populates form fields with data from an EmployeeDetails object.
     */
    public static void populateFieldsFromEmployee(Container container, EmployeeDetails emp) {
    for (Component c : container.getComponents()) {
        if (c instanceof JTextField field) {
            String name = field.getName();
            if (name == null) continue;

            switch (name) {
                case "txtfldEmpNo" -> field.setText(emp.getEmployeeNumber());
                case "txtfldLastName" -> field.setText(emp.getPerson().getLastName());
                case "txtfldFirstName" -> field.setText(emp.getPerson().getFirstName());
                case "txtfldAddress" -> {
                    field.setText(emp.getContact().getAddress());
                    field.setCaretPosition(0);
                }
                case "txtfldPhoneNo" -> field.setText(emp.getContact().getPhoneNo());
                case "txtfldEmail" -> field.setText(emp.getContact().getEmail());
                case "txtfldSSS" -> field.setText(emp.getGovID().getSSS());
                case "txtfldPhilhealth" -> field.setText(emp.getGovID().getPhilhealth());
                case "txtfldTIN" -> field.setText(emp.getGovID().getTIN());
                case "txtfldPagibig" -> field.setText(emp.getGovID().getPagibig());
                case "cmbbxStatus" -> field.setText(emp.getJobDetails().getEmployeeStatus());
                case "cmbbxPosition" -> {
                    field.setText(emp.getJobDetails().getPosition().getDisplayName());
                    field.setCaretPosition(0);
                }
                case "txtfldSupervisor" -> {
                    field.setText(emp.getJobDetails().getSupervisorFullName());
                    field.setCaretPosition(0);
                }
                case "txtfldBasicSalary" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getBasicSalary()));
                case "txtfldRiceSubsidy" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getRiceSubsidy()));
                case "txtfldPhoneAllowance" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getPhoneAllowance()));
                case "txtfldClothingAllowance" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getClothingAllowance()));
                case "txtfldHourlyRate" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getHourlyRate()));
                case "txtfldGrossSemiMonthly" -> field.setText(NumberFormattingUtils.formatPlainNumber(emp.getCompensation().getGrossSemiMonthly()));
            }

        } else if (c instanceof JComboBox comboBox) {
            String name = comboBox.getName();
            if (name == null) continue;

            switch (name) {
                case "cmbbxPosition" -> comboBox.setSelectedItem(emp.getJobDetails().getPosition().getDisplayName());
                case "cmbbxStatus" -> comboBox.setSelectedItem(emp.getJobDetails().getEmployeeStatus());
            }
        } 
        
        else if (c instanceof JDateChooser dateChooser) {
            String name = dateChooser.getName();
            if (name == null) continue;

            if ("txtfldBirthday".equals(name)) {
                LocalDate bday = emp.getPerson().getBirthday();

                if (bday != null) {
                    java.util.Date utilDate = java.sql.Date.valueOf(bday);
                    dateChooser.setDate(utilDate);
                } else {
                    dateChooser.setDate(null);
                }
            }
        }
        else if (c instanceof Container nested) {
            populateFieldsFromEmployee(nested, emp); //
        }
    }
}

    /**
     * Resets the add-employee form fields to default values.
     */
    public static void resetAddEmployeeFormFields(
            JTextField txtfldLastName,
            JTextField txtfldFirstName,
            JDateChooser jDateChooserBirthday,
            JTextField txtfldAddress,
            JTextField txtfldPhoneNo,
            JTextField txtfldEmail,
            JTextField txtfldSSS,
            JTextField txtfldPhilhealth,
            JTextField txtfldTIN,
            JTextField txtfldPagibig,
            JComboBox<String> cmbbxStatus,
            JComboBox<String> cmbbxPosition,
            JTextField txtfldSupervisor,
            JTextField txtfldBasicSalary,
            JTextField txtfldRiceSubsidy,
            JTextField txtfldPhoneAllowance,
            JTextField txtfldClothingAllowance,
            JTextField txtfldGrossSemiMonthly,
            JTextField txtfldHourlyRate
    ) {
        txtfldLastName.setText("");
        txtfldFirstName.setText("");
        jDateChooserBirthday.setDate(null);
        txtfldAddress.setText("");
        txtfldPhoneNo.setText("###-###-###");
        txtfldEmail.setText("");
        txtfldSSS.setText("");
        txtfldPhilhealth.setText("");
        txtfldTIN.setText("");
        txtfldPagibig.setText("");
        cmbbxStatus.setSelectedItem(null);
        cmbbxPosition.setSelectedItem(null);
        txtfldSupervisor.setText("");
        txtfldBasicSalary.setText("");
        txtfldRiceSubsidy.setText("");
        txtfldPhoneAllowance.setText("");
        txtfldClothingAllowance.setText("");
        txtfldGrossSemiMonthly.setText("");
        txtfldHourlyRate.setText("");
    }

    /**
     * Disables update buttons.
     */
    public static void disableUpdateButtons(JButton btnSaveUpdate, JButton btnCancelUpdate) {
        btnSaveUpdate.setEnabled(false);
        btnCancelUpdate.setEnabled(false);
    }

    /**
     * Enables update buttons.
     */
    public static void enableUpdateButtons(JButton btnSaveUpdate, JButton btnCancelUpdate) {
        btnSaveUpdate.setEnabled(true);
        btnCancelUpdate.setEnabled(true);
    }

    /**
     * Populates the position combo box from enum values.
     */
    public static void populatePositionComboBox(JComboBox<String> comboBox) {
        comboBox.removeAllItems();
        for (EmployeePosition pos : EmployeePosition.values()) {
            comboBox.addItem(pos.getDisplayName());
        }
    }

    /**
     * Populates the status combo box.
     */
    public static void populateStatusComboBox(JComboBox<String> comboBox) {
        comboBox.removeAllItems();
        comboBox.addItem("Regular");
        comboBox.addItem("Probationary");
    }

    /**
     * Attaches a listener to automatically compute gross and hourly rate when basic salary changes.
     */
    public static void attachAutoComputeListener(JTextField basicSalaryField, JTextField grossField, JTextField hourlyRateField) {
    DocumentListener listener = new DocumentListener() {
        private void compute() {
            String input = basicSalaryField.getText().trim();

            // Clear computed fields by default
            grossField.setText("");
            hourlyRateField.setText("");

            // Return early if empty
            if (input.isEmpty()) return;

            // Remove commas and validate numeric format (e.g., 12345.67)
            input = input.replace(",", "");
            if (!input.matches("\\d+(\\.\\d{1,2})?")) {
                return; // Don't compute if input is invalid
            }

            try {
                double basic = Double.parseDouble(input);

                // Compute derived values
                double gross = basic / 2;
                double hourly = basic / 168; // Assuming 8 hours/day * 21 working days

                // Update target fields
                grossField.setText(NumberFormattingUtils.formatPlainRawNumber(gross));
                hourlyRateField.setText(NumberFormattingUtils.formatPlainRawNumber(hourly));
            } catch (NumberFormatException e) {
                // Do nothing; fields already cleared
            }
        }

        @Override
        public void insertUpdate(DocumentEvent e) { compute(); }

        @Override
        public void removeUpdate(DocumentEvent e) { compute(); }

        @Override
        public void changedUpdate(DocumentEvent e) { compute(); }
    };

    // Attach the listener to the basic salary input field
    basicSalaryField.getDocument().addDocumentListener(listener);

}
    /**
     * Makes a JTextField read-only and grayed out.
     */
    public static void makeDisplayOnly(JTextField field) {
        field.setEditable(false);
        field.setFocusable(false);
        field.setBackground(Color.LIGHT_GRAY);
    }


public static void populateFormWithEmployeeData(Container container, EmployeeDetails employee) {
    for (Component component : container.getComponents()) {
        if (component instanceof JTextField textField && textField.getName() != null) {
            switch (textField.getName()) {
                case "empNo" -> textField.setText(employee.getEmployeeNumber());
                case "lastName" -> textField.setText(employee.getPerson().getLastName());
                case "firstName" -> textField.setText(employee.getPerson().getFirstName());
                case "address" -> textField.setText(employee.getContact().getAddress());
                case "phoneNo" -> textField.setText(employee.getContact().getPhoneNo());
                case "email" -> textField.setText(employee.getContact().getEmail());
                case "sss" -> textField.setText(employee.getGovID().getSSS());
                case "philhealth" -> textField.setText(employee.getGovID().getPhilhealth());
                case "tin" -> textField.setText(employee.getGovID().getTIN());
                case "pagibig" -> textField.setText(employee.getGovID().getPagibig());
                case "supervisor" -> textField.setText(employee.getJobDetails().getSupervisorFullName());
                case "basicSalary" -> textField.setText(String.valueOf(employee.getCompensation().getBasicSalary()));
                case "riceSubsidy" -> textField.setText(String.valueOf(employee.getCompensation().getRiceSubsidy()));
                case "phoneAllowance" -> textField.setText(String.valueOf(employee.getCompensation().getPhoneAllowance()));
                case "clothingAllowance" -> textField.setText(String.valueOf(employee.getCompensation().getClothingAllowance()));
                case "grossSemiMonthly" -> textField.setText(String.valueOf(employee.getCompensation().getGrossSemiMonthly()));
                case "hourlyRate" -> textField.setText(String.valueOf(employee.getCompensation().getHourlyRate()));
            }
        } else if (component instanceof JDateChooser dateChooser && dateChooser.getName() != null) {
            if ("birthday".equals(dateChooser.getName())) {
                LocalDate bday = employee.getPerson().getBirthday();
                if (bday != null) {
                    // Convert LocalDate to java.util.Date
                    Date utilDate = java.sql.Date.valueOf(bday);
                    dateChooser.setDate(utilDate);
                } else {
                    dateChooser.setDate(null);
                }
            }
        } else if (component instanceof JComboBox comboBox && comboBox.getName() != null) {
            switch (comboBox.getName()) {
                case "status" -> comboBox.setSelectedItem(employee.getJobDetails().getEmployeeStatus());
                case "position" -> comboBox.setSelectedItem(employee.getJobDetails().getPosition());
            }
        } else if (component instanceof Container nestedContainer) {
            populateFormWithEmployeeData(nestedContainer, employee); // Recurse into panels
        }
    }
}


    /**
 * Applies tooltips to all relevant input fields in the employee form.
 *
 * @param txtfldEmpNo              System-generated unique employee number (non-editable)
 * @param txtfldLastName           Employee’s last name
 * @param txtfldFirstName          Employee’s first name
 * @param txtfldBirthday           Employee’s date of birth (MM/DD/YYYY)
 * @param txtfldAddress            Complete residential address
 * @param txtfldPhoneNo            Contact number in ###-###-### format
 * @param txtfldEmail              Employee email address
 * @param txtfldSSS                SSS number (10 digits, format: XX-XXXXXXX-X)
 * @param txtfldPhilhealth         PhilHealth number (12 digits)
 * @param txtfldTIN                TIN number (12 digits, format: XXX-XXX-XXX-XXX)
 * @param txtfldPagibig            Pag-IBIG number (12 digits)
 * @param cmbbxStatus              Employment status dropdown (Regular or Probationary)
 * @param cmbbxPosition            Position dropdown (e.g., HR Manager, Accounting Staff, etc.)
 * @param txtfldSupervisor         Supervisor’s full name (First + Last Name)
 * @param txtfldBasicSalary        Monthly basic salary (editable, 2 decimals)
 * @param txtfldRiceSubsidy        Rice subsidy allowance (2 decimals)
 * @param txtfldPhoneAllowance     Phone allowance (2 decimals)
 * @param txtfldClothingAllowance  Clothing allowance (2 decimals)
 * @param txtfldGrossSemiMonthly   System-generated gross semi-monthly salary (non-editable)
 * @param txtfldHourlyRate         System-generated hourly rate (non-editable)
 */


public static void applyTooltips(
        JTextField txtfldEmpNo,
        JTextField txtfldLastName,
        JTextField txtfldFirstName,
        JDateChooser jDateChooserBirthday,
        JTextField txtfldStreet,
        JTextField txtfldBarangay,
        JTextField txtfldCity,
        JTextField txtfldProvince,
        JTextField txtfldZipcode,
        JTextField txtfldPhoneNo,
        JTextField txtfldEmail,
        JTextField txtfldSSS,
        JTextField txtfldPhilhealth,
        JTextField txtfldTIN,
        JTextField txtfldPagibig,
        JComboBox<String> cmbbxStatus,
        JComboBox<String> cmbbxPosition,
        JTextField txtfldSupervisor,
        JTextField txtfldBasicSalary,
        JTextField txtfldRiceSubsidy,
        JTextField txtfldPhoneAllowance,
        JTextField txtfldClothingAllowance,
        JTextField txtfldGrossSemiMonthly,
        JTextField txtfldHourlyRate
        ) {

    // Identification
    txtfldEmpNo.setToolTipText("System-generated unique employee number. This field is not editable.");

    // Basic personal information
    txtfldLastName.setToolTipText("Enter the employee’s last name.");
    txtfldFirstName.setToolTipText("Enter the employee’s first name.");
    jDateChooserBirthday.setToolTipText("Select employee birthday. Future dates are not allowed.");
    txtfldStreet.setToolTipText("Enter street address.");
    txtfldBarangay.setToolTipText("Enter barangay.");
    txtfldCity.setToolTipText("Enter city or municipality.");
    txtfldProvince.setToolTipText("Enter province.");
    txtfldZipcode.setToolTipText("Enter ZIP code.");

    // Contact and government identification numbers
    txtfldPhoneNo.setToolTipText("Enter a 9-digit phone number in the format ###-###-###.");
    txtfldEmail.setToolTipText("Enter a valid email address (for example, employee@motorph.com).");
    txtfldSSS.setToolTipText("Enter a valid 10-digit SSS number (format: ##-#######-#).");
    txtfldPhilhealth.setToolTipText("Enter a 12-digit PhilHealth number (e.g., 123456789012).");
    txtfldTIN.setToolTipText("Enter a valid 12-digit TIN number (format: ###-###-###-###).");
    txtfldPagibig.setToolTipText("Enter a 12-digit Pag-IBIG number (e.g., 123456789012).");

    // Employment and supervisory details
    cmbbxStatus.setToolTipText("Choose the employment status: Regular or Probationary.");
    cmbbxPosition.setToolTipText("Select the employee’s position from the dropdown.");
    txtfldSupervisor.setToolTipText("Enter the full name of the direct supervisor (First + Last name).");

    // Compensation details
    txtfldBasicSalary.setToolTipText("Enter the monthly basic salary. Gross semi-monthly and hourly rate will auto-calculate.");
    txtfldRiceSubsidy.setToolTipText("Enter the rice subsidy amount (optional, 2 decimal places).");
    txtfldPhoneAllowance.setToolTipText("Enter the phone allowance amount (up to 2 decimal places, e.g., 1000.00).");
    txtfldClothingAllowance.setToolTipText("Enter the clothing allowance amount (up to 2 decimal places, e.g., 1500.00).");

    // Auto-calculated fields
    txtfldGrossSemiMonthly.setToolTipText("Auto-generated based on basic salary. This field is not editable.");
    txtfldHourlyRate.setToolTipText("Auto-generated based on basic salary. This field is not editable.");
}

private static double safeParseDouble(String value) {
    if (value == null || value.trim().isEmpty()) return 0.0;

    // REMOVE commas and spaces
    value = value.replace(",", "").trim();

    return Double.parseDouble(value);
}
}
