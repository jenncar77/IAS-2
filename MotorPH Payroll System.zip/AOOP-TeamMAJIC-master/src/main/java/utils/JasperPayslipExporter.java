package utils;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

/**
 * Exports employee payslip data using the JasperReports payslip template.
 */
public class JasperPayslipExporter {

    public static void exportPayslip(
            String employeeNumber,
            String employeeName,
            String position,
            String department,
            String payrollPeriod,
            String startDate,
            String endDate,
            double grossSalary,
            double totalDeductions,
            double netPay,
            double sss,
            double philHealth,
            double pagibig,
            double tax,
            double monthlySalary,
            double totalAllowances,
            double riceSubsidy,
            double phoneAllowance,
            double clothingAllowance,
            double dailyRate,
            double daysWorked,
            double overtime,
            String outputFilePath
    ) {
        configureJasperCompilerClasspath();

        try (InputStream reportStream = JasperPayslipExporter.class.getResourceAsStream(
                        "/reports/EmployeePayslip.jrxml");
                InputStream logoStream = JasperPayslipExporter.class.getResourceAsStream(
                        "/reports/MotorPHPayslipLogo.jpg")) {

            if (reportStream == null) {
                throw new RuntimeException(
                        "EmployeePayslip.jrxml not found in src/main/resources/reports."
                );
            }

            if (logoStream == null) {
                throw new RuntimeException(
                        "MotorPHPayslipLogo.jpg not found in src/main/resources/reports."
                );
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            Map<String, Object> params = new HashMap<>();
            params.put("logo", logoStream);
            params.put("employeeNumber", employeeNumber);
            params.put("employeeName", employeeName);
            params.put("position", position);
            params.put("department", department);
            params.put("payrollPeriod", payrollPeriod);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            params.put("payslipNo", "PS-" + employeeNumber);

            params.put("monthlySalary", monthlySalary);
            params.put("totalAllowances", totalAllowances);
            params.put("grossSalary", grossSalary);
            params.put("grossPay", grossSalary);
            params.put("totalDeductions", totalDeductions);
            params.put("netPay", netPay);
            params.put("dailyRate", dailyRate);
            params.put("daysWorked", daysWorked);
            params.put("overtime", overtime);

            params.put("riceSubsidy", riceSubsidy);
            params.put("phoneAllowance", phoneAllowance);
            params.put("clothingAllowance", clothingAllowance);
            params.put("sss", sss);
            params.put("philHealth", philHealth);
            params.put("pagibig", pagibig);
            params.put("tax", tax);

            JasperPrint jasperPrint = JasperFillManager.fillReport(
                    jasperReport,
                    params,
                    new JREmptyDataSource()
            );

            JasperExportManager.exportReportToPdfFile(jasperPrint, outputFilePath);
        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to export payslip: " + e.getMessage(),
                    e
            );
        }
    }

    private static void configureJasperCompilerClasspath() {
        System.setProperty(
                "net.sf.jasperreports.compiler.classpath",
                System.getProperty("java.class.path")
        );
    }
}