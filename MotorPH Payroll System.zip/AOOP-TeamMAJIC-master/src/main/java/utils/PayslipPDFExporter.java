package utils;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Exports employee payslips to PDF format.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class PayslipPDFExporter {

    // Font definitions used throughout the PDF
    private static final Font mediumSizeText = new Font(Font.FontFamily.COURIER, 12, Font.BOLD);
    private static final Font regularText = new Font(Font.FontFamily.COURIER, 12);
    private static final Font smallItalic = new Font(Font.FontFamily.COURIER, 9, Font.ITALIC);
    private static final Font sectionTitle = new Font(Font.FontFamily.COURIER, 13, Font.BOLD);
    private static final Font redValue = new Font(Font.FontFamily.COURIER, 12, Font.NORMAL, BaseColor.RED);
    private static final Font footerFont = new Font(Font.FontFamily.COURIER, 10, Font.ITALIC);
    private static final Font boldText = new Font(Font.FontFamily.COURIER, 12, Font.BOLD);

    /**
     * Exports a payslip PDF to the specified file name.
     */
    public static void exportPayslip(
            String employeeNumber,
            String employeeName,
            String position,
            String monthYear,
            String cutoffPeriod,
            double grossIncome,
            double sss,
            double philHealth,
            double pagibig,
            double tax,
            double totalDeductions,
            double netIncome,
            String fileName
    ) {
        try {
            // Create PDF document with margins
            Document document = new Document(PageSize.A4, 50, 50, 50, 50);
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            // Add title header
            Paragraph title = new Paragraph("MotorPH Employee Payslip", new Font(Font.FontFamily.COURIER, 18, Font.BOLD));
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20f);
            document.add(title);

            // Add employee details
            document.add(new Paragraph("Employee Number : " + employeeNumber, mediumSizeText));
            document.add(new Paragraph("Employee Name : " + employeeName, mediumSizeText));
            document.add(new Paragraph("Position : " + position, mediumSizeText));
            document.add(new Paragraph("Payroll Period : " + cutoffPeriod + " of " + monthYear, mediumSizeText));
            document.add(Chunk.NEWLINE);

            // Section: Payroll Overview
            Paragraph overviewTitle = new Paragraph("Payroll Overview", sectionTitle);
            overviewTitle.setSpacingAfter(10f);
            document.add(overviewTitle);

            // Add income and deductions overview
            addRegularRow(document, "Gross Salary", NumberFormattingUtils.formatPlainNumber(grossIncome));
            addSubNote(document, "includes Bi-Monthly Allowances");
            addRegularRow(document, "Total Deductions", NumberFormattingUtils.formatPlainNumber(totalDeductions));

            // Visual separator
            addDashedLine(document);

            // Display Net Salary in bold
            addBoldRow(document, "Net Salary", NumberFormattingUtils.formatPlainNumber(netIncome));
            document.add(Chunk.NEWLINE);

            // Section: Detailed Breakdown of Deductions
            Paragraph breakdownHeader = new Paragraph("Breakdown of Salary Deductions", smallItalic);
            breakdownHeader.setSpacingBefore(5f);
            document.add(breakdownHeader);

            // Add detailed deductions
            addColoredRow(document, "SSS Deduction", NumberFormattingUtils.formatPlainNumber(sss), redValue);
            addColoredRow(document, "PhilHealth Deduction", NumberFormattingUtils.formatPlainNumber(philHealth), redValue);
            addColoredRow(document, "Pag-IBIG Deduction", NumberFormattingUtils.formatPlainNumber(pagibig), redValue);
            addColoredRow(document, "Tax", NumberFormattingUtils.formatPlainNumber(tax), redValue);

            // Footer disclaimer
            document.add(Chunk.NEWLINE);
            Paragraph footerNote = new Paragraph(
                    "This payslip is system-generated and does not require a signature.",
                    footerFont
            );
            footerNote.setAlignment(Element.ALIGN_RIGHT);
            document.add(footerNote);

            document.close();
            System.out.println("Payslip PDF saved: " + fileName);

        } catch (Exception e) {
            System.err.println("Error exporting payslip PDF: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Adds a standard row to the document with regular font.
     */
    private static void addRegularRow(Document doc, String label, String value) throws DocumentException {
        addLabelWithValue(doc, label, value, regularText);
    }

    /**
     * Adds a bold row to the document.
     */
    private static void addBoldRow(Document doc, String label, String value) throws DocumentException {
        addLabelWithValue(doc, label, value, boldText);
    }

    /**
     * Adds a row with a custom font (Example: red for deductions).
     */
    private static void addColoredRow(Document doc, String label, String value, Font font) throws DocumentException {
        addLabelWithValue(doc, label, value, font);
    }

    /**
     * Core method to add label-value pair with styling into a two-column table.
     */
    private static void addLabelWithValue(Document doc, String label, String value, Font valueFont) throws DocumentException {
        PdfPTable table = new PdfPTable(2); // Two columns: label and value
        table.setWidthPercentage(100);
        table.setWidths(new int[]{70, 30}); // Wider label, narrower value
        table.setSpacingBefore(5f);

        PdfPCell labelCell = new PdfPCell(new Phrase(label, regularText));
        PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));

        // Remove borders and align value to right
        labelCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

        table.addCell(labelCell);
        table.addCell(valueCell);
        doc.add(table);
    }

    /**
     * Adds an italic sub-note (indented) under a row.
     */
    private static void addSubNote(Document doc, String note) throws DocumentException {
        Paragraph sub = new Paragraph(note, smallItalic);
        sub.setIndentationLeft(10f);
        sub.setSpacingAfter(5f);
        doc.add(sub);
    }

    /**
     * Adds a visual dashed line separator (right-aligned).
     */
    private static void addDashedLine(Document doc) throws DocumentException {
        Paragraph line = new Paragraph("------------------------------");
        line.setAlignment(Element.ALIGN_RIGHT);
        doc.add(line);
    }

    /**
     * Opens a file chooser dialog for saving the PDF with .pdf extension.
     */
    public static String promptForFileLocation(String empNo) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Payslip PDF");

        // Default filename in Downloads folder
        String defaultFilename = "Payslip_" + sanitizeFilename(empNo) + ".pdf";
        fileChooser.setSelectedFile(new File(System.getProperty("user.home") + "/Downloads/" + defaultFilename));
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents", "pdf"));

        int userSelection = fileChooser.showSaveDialog(null);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            String path = fileToSave.getAbsolutePath();
            return path.toLowerCase().endsWith(".pdf") ? path : path + ".pdf";
        }
        return null;
    }

    /**
     * Sanitizes filename by replacing illegal characters with underscores.
     */
    private static String sanitizeFilename(String filename) {
        return filename.replaceAll("[^a-zA-Z0-9-_]", "_");
    }
}
