package utils;

/**
 * Enumerates the supported employee positions used by the system.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public enum EmployeePosition {

    CEO("Chief Executive Officer"),
    COO("Chief Operating Officer"),
    CFO("Chief Finance Officer"),
    CMO("Chief Marketing Officer"),

    IT_OPS_SYSTEMS("IT Operations and Systems"),

    HR_MANAGER("HR Manager"),
    HR_TEAM_LEAD("HR Team Leader"),
    HR_RANK_AND_FILE("HR Rank and File"),

    ACCOUNTING_HEAD("Accounting Head"),
    PAYROLL_MANAGER("Payroll Manager"),
    PAYROLL_TEAM_LEAD("Payroll Team Leader"),
    PAYROLL_RANK_AND_FILE("Payroll Rank and File"),

    ACCOUNT_MANAGER("Account Manager"),
    ACCOUNT_TEAM_LEAD("Account Team Leader"),
    ACCOUNT_RANK_AND_FILE("Account Rank and File"),

    SALES_MARKETING("Sales & Marketing"),
    SUPPLY_CHAIN_LOGISTICS("Supply Chain and Logistics"),
    CUSTOMER_SERVICE_RELATIONS("Customer Service and Relations");

    private final String displayName;

    // Constructor: maps enum constant to readable display name
    EmployeePosition(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets the display-friendly name for GUI or reports.
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Converts a display name string
     * into its corresponding enum constant.
     */
    public static EmployeePosition fromDisplayName(String displayName) {
        for (EmployeePosition position : EmployeePosition.values()) {
            if (position.displayName.equalsIgnoreCase(displayName.trim())) {
                return position;
            }
        }
        throw new IllegalArgumentException("No enum constant for display name: " + displayName);
    }

    /**
     * Returns the display name when enum is printed or used in UI.
     */
    @Override
    public String toString() {
        return displayName;
    }
}
