package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.TextStyle;
import java.util.*;

/**
 * Provides helper methods for payroll cutoff and date-range calculations.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class CutoffDateUtils {

    // Formatter for "Month Year" labels (example: July 2025)
    private static final DateTimeFormatter MONTH_YEAR_FORMATTER =
            DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH);

    // Formatter for attendance  dates (example: 7/18/2025)
    private static final DateTimeFormatter ATTENDANCE_DATE_FORMAT =
            DateTimeFormatter.ofPattern("M/d/yyyy");

    /**
     * Parses a month-year string (example: "July 2025") into a YearMonth object.
     */
    public static YearMonth parseYearMonth(String monthYear) {
        return YearMonth.parse(monthYear, MONTH_YEAR_FORMATTER);
    }

    /**
     * Converts a cutoff range string (example: "1st-15th") and a month-year string
     * into an array of two LocalDate objects: start and end.
     */
    public static LocalDate[] getCutoffDateRange(String monthYear, String cutoff) {
        if (monthYear == null || cutoff == null) return null;

        try {
            // Normalize cutoff string (replace en dash with hyphen)
            cutoff = cutoff.replace("–", "-").trim();
            String[] parts = cutoff.split("-");

            if (parts.length != 2) return null;

            // Remove ordinal suffixes (st, nd, rd, th) from both dates
            int startDay = Integer.parseInt(parts[0].replaceAll("[^\\d]", ""));
            int endDay = Integer.parseInt(parts[1].replaceAll("[^\\d]", ""));

            // Parse "Month Year" string to extract year and month
            YearMonth ym = YearMonth.parse(monthYear, MONTH_YEAR_FORMATTER);
            int year = ym.getYear();
            int month = ym.getMonthValue();

            // Construct LocalDate range from parsed values
            LocalDate start = LocalDate.of(year, month, startDay);
            LocalDate end = LocalDate.of(year, month, endDay);

            return new LocalDate[]{start, end};

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Appends the correct English ordinal suffix to a day number.
     * Example: 1 → 1st, 2 → 2nd, 3 → 3rd, 4 → 4th, etc.
     */
    public static String getDayWithSuffix(int day) {
        if (day >= 11 && day <= 13) return day + "th";

        return switch (day % 10) {
            case 1 -> day + "st";
            case 2 -> day + "nd";
            case 3 -> day + "rd";
            default -> day + "th";
        };
    }

   /**
     * Sorts a set of month-year strings (example: "July 2025") chronologically.
     */
    public static List<String> getSortedMonths(Set<String> months) {
        List<String> sorted = new ArrayList<>(months);
        sorted.sort(Comparator.comparing(s -> YearMonth.parse(s, MONTH_YEAR_FORMATTER)));
        return sorted;
    }

    /**
     * Alias for getSortedMonths to improve clarity in UI usage.
     */
    public static List<String> sortMonthLabels(Set<String> monthKeys) {
        return getSortedMonths(monthKeys);
    }

    /**
     * Returns the current system month in "MMMM yyyy" format.
     */
    public static String getCurrentMonthYear() {
        return LocalDate.now().format(MONTH_YEAR_FORMATTER);
    }
}
