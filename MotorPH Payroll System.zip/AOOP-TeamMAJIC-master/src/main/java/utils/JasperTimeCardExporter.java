package utils;

import java.io.InputStream;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;

/**
 * Exports employee time card data using the JasperReports time card template.
 */
public class JasperTimeCardExporter {

    private static final String JRXML_TEMPLATE = "/reports/EmployeeTimeCard.jrxml";
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("H:mm");

    public static void exportTimeCard(
            String employeeNumber,
            String employeeName,
            String position,
            String department,
            String payPeriod,
            String startDate,
            String endDate,
            List<String[]> attendanceRows,
            String outputFilePath
    ) {
        configureJasperCompilerClasspath();

        try (InputStream reportStream = JasperTimeCardExporter.class.getResourceAsStream(JRXML_TEMPLATE);
                InputStream logoStream = JasperTimeCardExporter.class.getResourceAsStream(
                        "/reports/MotorPHPayslipLogo.jpg")) {

            if (reportStream == null) {
                throw new RuntimeException(
                        "EmployeeTimeCard.jrxml not found in src/main/resources/reports."
                );
            }

            if (logoStream == null) {
                throw new RuntimeException(
                        "MotorPHPayslipLogo.jpg not found in src/main/resources/reports."
                );
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            Map<String, Object> params = new HashMap<>();
            params.put("logo", logoStream);
            params.put("employeeNumber", employeeNumber);
            params.put("employeeName", employeeName);
            params.put("position", position);
            params.put("department", department);
            params.put("payPeriod", payPeriod);
            params.put("startDate", startDate);
            params.put("endDate", endDate);
            params.put("totalHours", calculateTotalHours(attendanceRows));

            JasperPrint jasperPrint = JasperFillManager.fillReport(
                    jasperReport,
                    params,
                    createDataSource(attendanceRows)
            );

            JasperExportManager.exportReportToPdfFile(jasperPrint, outputFilePath);
        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to export time card: " + e.getMessage(),
                    e
            );
        }
    }

    private static JRMapCollectionDataSource createDataSource(List<String[]> attendanceRows) {
        List<Map<String, ?>> rows = new ArrayList<>();

        if (attendanceRows == null) {
            return new JRMapCollectionDataSource(rows);
        }

        for (String[] row : attendanceRows) {
            Map<String, Object> record = new HashMap<>();
            String clockIn = row.length > 4 ? safeText(row[4]) : "";
            String clockOut = row.length > 5 ? safeText(row[5]) : "";

            record.put("attendance_date", row.length > 3 ? safeText(row[3]) : "");
            record.put("clock_in", clockIn);
            record.put("clock_out", clockOut);
            record.put("total_hours", calculateHours(clockIn, clockOut));
            rows.add(record);
        }

        return new JRMapCollectionDataSource(rows);
    }

    private static String calculateTotalHours(List<String[]> attendanceRows) {
        int totalMinutes = 0;

        if (attendanceRows != null) {
            for (String[] row : attendanceRows) {
                String clockIn = row.length > 4 ? safeText(row[4]) : "";
                String clockOut = row.length > 5 ? safeText(row[5]) : "";
                totalMinutes += toMinutes(calculateHours(clockIn, clockOut));
            }
        }

        return formatMinutes(totalMinutes);
    }

    private static String calculateHours(String clockIn, String clockOut) {
        if (clockIn.isBlank() || clockOut.isBlank()) {
            return "";
        }

        LocalTime in = LocalTime.parse(clockIn, TIME_FORMAT);
        LocalTime out = LocalTime.parse(clockOut, TIME_FORMAT);
        long minutes = Duration.between(in, out).toMinutes();

        if (minutes >= 300) {
            minutes -= 60;
        }

        if (minutes < 0) {
            minutes = 0;
        }

        return formatMinutes((int) minutes);
    }

    private static int toMinutes(String hoursText) {
        if (hoursText == null || hoursText.isBlank() || !hoursText.contains(":")) {
            return 0;
        }

        String[] parts = hoursText.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    private static String formatMinutes(int minutes) {
        return String.format("%02d:%02d", minutes / 60, minutes % 60);
    }

    private static String safeText(Object value) {
        return value == null ? "" : value.toString();
    }

    private static void configureJasperCompilerClasspath() {
        System.setProperty(
                "net.sf.jasperreports.compiler.classpath",
                System.getProperty("java.class.path")
        );
    }
}
