package utils;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Provides helper methods for formatting employee values for display.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class EmployeeFormatter {

    /**
     * Formats names while preserving suffixes and Roman numerals.
     */
    public static String formatName(String input) {
        if (input == null || input.trim().isEmpty()) return input;

        Set<String> romanNumerals = Set.of(
            "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X",
            "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX"
        );

        Set<String> suffixes = Set.of(
            "JR.", "SR.", "PH.D.", "M.D.", "D.D.S.", "R.N."
        );

        return Arrays.stream(input.trim().split("\\s+"))
            .map(word -> {
                String upperWord = word.toUpperCase();

                // Preserve known suffixes
                if (suffixes.contains(upperWord)) return upperWord;

                // Preserve Roman numerals, with or without punctuation
                String cleaned = upperWord.replaceAll("[^A-Z]", "");
                if (romanNumerals.contains(cleaned)) return upperWord;

                // Preserve all-uppercase acronyms
                if (word.matches("[A-Z]{2,}")) return word;

                // Default: Capitalize first letter only
                return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
            })
            .collect(Collectors.joining(" "));
    }

    /**
     * Capitalizes each word in the address except those with digits or special chars.
     */
    public static String formatAddress(String input) {
        if (input == null || input.trim().isEmpty()) return input;

        return Arrays.stream(input.trim().split("\\s+"))
            .map(word -> {
                // Leave as-is if word contains digits or special characters
                if (word.matches(".*[0-9/#\\-].*")) return word;

                // Otherwise, capitalize normally
                return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
            })
            .collect(Collectors.joining(" "));
    }

    /**
     * Normalizes and formats birthday to MM/dd/yyyy.
     * Accepts formats like yyyy/MM/dd, MM-dd-yyyy, or 01012000.
     */
    public static String formatBirthday(String birthday) {
        birthday = birthday.trim().replaceAll("-", "/"); // Normalize delimiters

        if (birthday.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return birthday;
        }

        if (birthday.matches("\\d{4}/\\d{2}/\\d{2}")) {
            String[] parts = birthday.split("/");
            return parts[1] + "/" + parts[2] + "/" + parts[0]; // yyyy/MM/dd → MM/dd/yyyy
        }

        if (birthday.matches("\\d{8}")) {
            return birthday.replaceAll("(\\d{2})(\\d{2})(\\d{4})", "$1/$2/$3"); // 01012000 → 01/01/2000
        }

        return birthday; // Unrecognized format
    }

    /**
     * Parses a birthday string into a LocalDate object.
     */
    public static LocalDate parseBirthday(String birthday) {
    if (birthday == null || birthday.trim().isEmpty()) return null;

    birthday = birthday.trim();

    try {
        // First try formatted version
        String normalized = formatBirthday(birthday);
        return LocalDate.parse(normalized, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    } catch (Exception e) {
        try {
            // Fallback: handle yyyy-MM-dd directly
            return LocalDate.parse(birthday, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception ex) {
            return null;
        }
    }
}

    /**
     * Formats a 9-digit phone number to ###-###-###.
     */
    public static String formatPhone(String phone) {
        phone = phone.replaceAll("[^\\d]", ""); // Remove all non-digits

        return phone.matches("\\d{9}")
            ? phone.replaceAll("(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3")
            : phone;
    }

    /**
     * Normalizes an email by trimming whitespace and using lowercase.
     */
    public static String formatEmail(String email) {
        if (email == null) {
            return "";
        }
        return email.trim().toLowerCase();
    }

    /**
     * Formats a 10-digit SSS number to ##-#######-#.
     */
    public static String formatSSS(String sss) {
        sss = sss.replaceAll("[^\\d]", "");

        return sss.matches("\\d{10}")
            ? sss.replaceAll("(\\d{2})(\\d{7})(\\d)", "$1-$2-$3")
            : sss;
    }

    /**
     * Removes formatting from PhilHealth number and validates 12-digit length.
     */
    public static String formatPhilhealthNumber(String input) {
        if (input == null) return "Invalid PhilHealth Number";

        String digitsOnly = input.replaceAll("\\D", "");

        return digitsOnly.length() == 12
            ? digitsOnly
            : "Invalid PhilHealth Number";
    }

    /**
     * Formats a 12-digit TIN as ###-###-###-###.
     */
    public static String formatTIN(String tin) {
        tin = tin.replaceAll("[^\\d]", "");

        return tin.matches("\\d{12}")
            ? tin.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3-$4")
            : tin;
    }

    /**
     * Validates and normalizes Pag-IBIG number to 12-digit plain format.
     */
    public static String formatPagibigNumber(String input) {
        if (input == null) return "Invalid Pagibig Number";

        String digitsOnly = input.replaceAll("\\D", "");

        return digitsOnly.length() == 12
            ? digitsOnly
            : "Invalid PhilHealth Number"; // Possible copy-paste mistake: returns PhilHealth error message
    }

    /**
     * Formats supervisor name while preserving suffixes and allowing "N/A" for CEO.
     */
    public static String formatSupervisorName(String name, String employeePosition) {
        if (name == null || name.trim().isEmpty()) {
            return (employeePosition != null && employeePosition.equalsIgnoreCase("CEO"))
                ? "N/A"
                : "Unknown";
        }

        Set<String> romanNumerals = Set.of(
            "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X",
            "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX"
        );

        Set<String> suffixes = Set.of(
            "JR.", "SR.", "PH.D.", "M.D.", "D.D.S.", "R.N."
        );

        Set<String> preservedTerms = Set.of("N/A");

        return Arrays.stream(name.trim().split("\\s+"))
            .map(word -> {
                String upperWord = word.toUpperCase();

                if (preservedTerms.contains(upperWord)) return upperWord;
                if (suffixes.contains(upperWord)) return upperWord;

                String cleaned = upperWord.replaceAll("[^A-Z]", "");
                if (romanNumerals.contains(cleaned)) return upperWord;

                if (word.matches("[A-Z]{2,}")) return word;

                return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
            })
            .collect(Collectors.joining(" "));
    }

    /**
     * Converts numeric compensation string to 2-decimal format without commas.
     * Fallbacks to "0.00" if invalid or empty.
     */
    public static String formatCompensation(String value) {
        if (value == null || value.trim().isEmpty()) return "0.00";

        try {
            String cleanValue = value.replace(",", "").trim();
            double parsed = Double.parseDouble(cleanValue);
            DecimalFormat df = new DecimalFormat("0.00");
            return df.format(parsed);
        } catch (NumberFormatException e) {
            return "0.00";
        }
    }
}
