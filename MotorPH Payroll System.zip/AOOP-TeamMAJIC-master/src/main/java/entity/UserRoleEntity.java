/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "UserRole")
public class UserRoleEntity {

    @EmbeddedId
    private UserRoleId id;

    @ManyToOne
    @MapsId("userAccountId")
    @JoinColumn(name = "user_account_id")
    private UserAccountEntity userAccount;

    @ManyToOne
    @MapsId("systemRoleId")
    @JoinColumn(name = "system_role_id")
    private SystemRoleEntity systemRole;

    public UserRoleId getId() {
        return id;
    }

    public UserAccountEntity getUserAccount() {
        return userAccount;
    }

    public SystemRoleEntity getSystemRole() {
        return systemRole;
    }

    public void setId(UserRoleId id) {
        this.id = id;
    }

    public void setUserAccount(UserAccountEntity userAccount) {
        this.userAccount = userAccount;
    }

    public void setSystemRole(SystemRoleEntity systemRole) {
        this.systemRole = systemRole;
    }
}