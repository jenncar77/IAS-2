/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Mary
 */
import jakarta.persistence.*;

@Entity
@Table(name = "EmploymentStatus")
public class EmploymentStatusEntity {

    @Id
    @Column(name = "employment_status_id")
    private int employmentStatusId;

    @Column(name = "employment_status_name")
    private String employmentStatusName;

    public int getEmploymentStatusId() {
        return employmentStatusId;
    }

    public String getEmploymentStatusName() {
        return employmentStatusName;
    }
}