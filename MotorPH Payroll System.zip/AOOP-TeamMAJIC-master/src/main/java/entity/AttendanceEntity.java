/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "Attendance")
public class AttendanceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "attendance_id")
    private int attendanceId;

    @ManyToOne
    @JoinColumn(name = "employee_number")
    private EmployeeEntity employee;

    @Column(name = "attendance_date")
    private LocalDate attendanceDate;

    @Column(name = "login")
    private LocalTime login;

    @Column(name = "logout")
    private LocalTime logout;

    public int getAttendanceId() {
        return attendanceId;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public LocalDate getAttendanceDate() {
        return attendanceDate;
    }

    public LocalTime getLogin() {
        return login;
    }

    public LocalTime getLogout() {
        return logout;
    }

    public void setAttendanceId(int attendanceId) {
        this.attendanceId = attendanceId;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public void setAttendanceDate(LocalDate attendanceDate) {
        this.attendanceDate = attendanceDate;
    }

    public void setLogin(LocalTime login) {
        this.login = login;
    }

    public void setLogout(LocalTime logout) {
        this.logout = logout;
    }
}
