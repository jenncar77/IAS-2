/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "DeductionType")
public class DeductionTypeEntity {

    @Id
    @Column(name = "deduction_type_id")
    private int deductionTypeId;

    @Column(name = "deduction_type_name")
    private String deductionTypeName;

    public int getDeductionTypeId() {
        return deductionTypeId;
    }

    public String getDeductionTypeName() {
        return deductionTypeName;
    }
}
