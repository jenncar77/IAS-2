/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "RolePermission")
public class RolePermissionEntity {

    @EmbeddedId
    private RolePermissionId id;

    @ManyToOne
    @MapsId("systemRoleId")
    @JoinColumn(name = "system_role_id")
    private SystemRoleEntity systemRole;

    @ManyToOne
    @MapsId("permissionId")
    @JoinColumn(name = "permission_id")
    private PermissionEntity permission;

    public RolePermissionId getId() {
        return id;
    }

    public SystemRoleEntity getSystemRole() {
        return systemRole;
    }

    public PermissionEntity getPermission() {
        return permission;
    }
}
