/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "LeaveApprovalStatus")
public class LeaveApprovalStatusEntity {

    @Id
    @Column(name = "leave_approval_status_id")
    private int leaveApprovalStatusId;

    @Column(name = "leave_approval_status_name")
    private String leaveApprovalStatusName;

    public int getLeaveApprovalStatusId() {
        return leaveApprovalStatusId;
    }

    public String getLeaveApprovalStatusName() {
        return leaveApprovalStatusName;
    }

    public void setLeaveApprovalStatusId(int leaveApprovalStatusId) {
        this.leaveApprovalStatusId = leaveApprovalStatusId;
    }
}
