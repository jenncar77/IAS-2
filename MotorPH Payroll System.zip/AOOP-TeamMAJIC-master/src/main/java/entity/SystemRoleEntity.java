/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "SystemRole")
public class SystemRoleEntity {

    @Id
    @Column(name = "system_role_id")
    private int systemRoleId;

    @Column(name = "role_name")
    private String roleName;

    public int getSystemRoleId() {
        return systemRoleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setSystemRoleId(int systemRoleId) {
        this.systemRoleId = systemRoleId;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}