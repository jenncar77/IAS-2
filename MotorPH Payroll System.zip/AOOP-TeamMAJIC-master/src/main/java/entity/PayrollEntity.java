/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author Mary
 */

@Entity
@Table(name = "Payroll")
public class PayrollEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payroll_id")
    private int payrollId;

    @ManyToOne
    @JoinColumn(name = "employee_number")
    private EmployeeEntity employee;

    @ManyToOne
    @JoinColumn(name = "payroll_status_id")
    private PayrollStatusEntity payrollStatus;

    @ManyToOne
    @JoinColumn(name = "pay_period_id")
    private PayPeriodEntity payPeriod;

    @Column(name = "processed_by")
    private int processedBy;

    @Column(name = "processed_date")
    private LocalDateTime processedDate;

    @Column(name = "gross_pay")
    private BigDecimal grossPay;

    @Column(name = "total_allowances")
    private BigDecimal totalAllowances;

    @Column(name = "total_deductions")
    private BigDecimal totalDeductions;

    @Column(name = "net_pay")
    private BigDecimal netPay;

    @Column(name = "total_worked_hours")
    private BigDecimal totalWorkedHours;

    public int getPayrollId() {
        return payrollId;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public PayrollStatusEntity getPayrollStatus() {
        return payrollStatus;
    }

    public PayPeriodEntity getPayPeriod() {
        return payPeriod;
    }

    public int getProcessedBy() {
        return processedBy;
    }

    public LocalDateTime getProcessedDate() {
        return processedDate;
    }

    public BigDecimal getGrossPay() {
        return grossPay;
    }

    public BigDecimal getTotalAllowances() {
        return totalAllowances;
    }

    public BigDecimal getTotalDeductions() {
        return totalDeductions;
    }

    public BigDecimal getNetPay() {
        return netPay;
    }

    public BigDecimal getTotalWorkedHours() {
        return totalWorkedHours;
    }

    public void setPayrollId(int payrollId) {
        this.payrollId = payrollId;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public void setPayrollStatus(PayrollStatusEntity payrollStatus) {
        this.payrollStatus = payrollStatus;
    }

    public void setPayPeriod(PayPeriodEntity payPeriod) {
        this.payPeriod = payPeriod;
    }

    public void setProcessedBy(int processedBy) {
        this.processedBy = processedBy;
    }

    public void setProcessedDate(LocalDateTime processedDate) {
        this.processedDate = processedDate;
    }

    public void setGrossPay(BigDecimal grossPay) {
        this.grossPay = grossPay;
    }

    public void setTotalAllowances(BigDecimal totalAllowances) {
        this.totalAllowances = totalAllowances;
    }

    public void setTotalDeductions(BigDecimal totalDeductions) {
        this.totalDeductions = totalDeductions;
    }

    public void setNetPay(BigDecimal netPay) {
        this.netPay = netPay;
    }

    public void setTotalWorkedHours(BigDecimal totalWorkedHours) {
        this.totalWorkedHours = totalWorkedHours;
    }
}
