/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "Permission")
public class PermissionEntity {

    @Id
    @Column(name = "permission_id")
    private int permissionId;

    @Column(name = "access_level")
    private String accessLevel;

    @Column(name = "record_type")
    private String recordType;

    @Column(name = "description")
    private String description;

    public int getPermissionId() {
        return permissionId;
    }

    public String getAccessLevel() {
        return accessLevel;
    }

    public String getRecordType() {
        return recordType;
    }

    public String getDescription() {
        return description;
    }
}