/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "OvertimeApprovalStatus")
public class OvertimeApprovalStatusEntity {
    
    @Id
    @Column(name = "overtime_approval_status_id")
    private int overtimeApprovalStatusId;
    
    @Column(name = "overtime_approval_status_name")
    private String overtimeApprovalStatusName;

    public int getOvertimeApprovalStatusId() {
        return overtimeApprovalStatusId;
    }

    public String getOvertimeApprovalStatusName() {
        return overtimeApprovalStatusName;
    }
    
    
}
