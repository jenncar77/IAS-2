/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "PayrollDocument")
public class PayrollDocumentEntity {

    @Id
    @Column(name = "payroll_document_id")
    private int payrollDocumentId;

    @ManyToOne
    @JoinColumn(name = "payroll_id")
    private PayrollEntity payroll;

    @Column(name = "document_type")
    private String documentType;

    @Column(name = "file_reference")
    private String fileReference;

    @Column(name = "upload_date")
    private LocalDate uploadDate;

    public int getPayrollDocumentId() {
        return payrollDocumentId;
    }

    public PayrollEntity getPayroll() {
        return payroll;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getFileReference() {
        return fileReference;
    }

    public LocalDate getUploadDate() {
        return uploadDate;
    }
}
