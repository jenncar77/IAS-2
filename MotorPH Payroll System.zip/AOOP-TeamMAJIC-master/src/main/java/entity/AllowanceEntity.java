/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author Mary
 */

@Entity
@Table(name = "Allowance")
public class AllowanceEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "allowance_id")
    private int allowanceId;

    @ManyToOne
    @JoinColumn(name = "employee_number")
    private EmployeeEntity employee;

    @ManyToOne
    @JoinColumn(name = "allowance_type_id")
    private AllowanceTypeEntity allowanceType;

    @Column(name = "effective_date")
    private LocalDate effectiveDate;

    @Column(name = "amount")
    private BigDecimal amount;

    public int getAllowanceId() {
        return allowanceId;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public AllowanceTypeEntity getAllowanceType() {
        return allowanceType;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAllowanceId(int allowanceId) {
        this.allowanceId = allowanceId;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public void setAllowanceType(AllowanceTypeEntity allowanceType) {
        this.allowanceType = allowanceType;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}