/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "AllowanceType")
public class AllowanceTypeEntity {

    @Id
    @Column(name = "allowance_type_id")
    private int allowanceTypeId;

    @Column(name = "allowance_type_name")
    private String allowanceTypeName;

    public int getAllowanceTypeId() {
        return allowanceTypeId;
    }

    public String getAllowanceTypeName() {
        return allowanceTypeName;
    }
}
