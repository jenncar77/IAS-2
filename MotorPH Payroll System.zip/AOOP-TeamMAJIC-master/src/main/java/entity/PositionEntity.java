/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Mary
 */
import jakarta.persistence.*;

@Entity
@Table(name = "Position")
public class PositionEntity {

    @Id
    @Column(name = "position_id")
    private int positionId;

    @Column(name = "position_name")
    private String positionName;

    public int getPositionId() {
        return positionId;
    }

    public String getPositionName() {
        return positionName;
    }
}
