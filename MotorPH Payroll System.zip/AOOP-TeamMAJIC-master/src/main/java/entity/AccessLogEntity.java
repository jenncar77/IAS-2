/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "AccessLog")
public class AccessLogEntity {

    @Id
    @Column(name = "access_log_id")
    private int accessLogId;

    @ManyToOne
    @JoinColumn(name = "user_account_id")
    private UserAccountEntity userAccount;

    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private ActionType action;

    @Column(name = "access_time")
    private LocalDateTime accessTime;

    public int getAccessLogId() {
        return accessLogId;
    }

    public UserAccountEntity getUserAccount() {
        return userAccount;
    }

    public enum ActionType {
        Login,
        Logout,
        Create,
        Update,
        Delete
    }

    public LocalDateTime getAccessTime() {
        return accessTime;
    }
}