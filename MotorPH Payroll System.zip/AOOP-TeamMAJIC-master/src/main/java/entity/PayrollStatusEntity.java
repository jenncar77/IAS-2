/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */

@Entity
@Table(name = "PayrollStatus")
public class PayrollStatusEntity {

    @Id
    @Column(name = "payroll_status_id")
    private int payrollStatusId;

    @Column(name = "payroll_status_name")
    private String payrollStatusName;

    public int getPayrollStatusId() {
        return payrollStatusId;
    }

    public String getPayrollStatusName() {
        return payrollStatusName;
    }
}
