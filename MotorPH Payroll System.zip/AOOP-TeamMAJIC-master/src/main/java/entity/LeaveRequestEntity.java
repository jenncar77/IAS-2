/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "LeaveRequest")
public class LeaveRequestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "leave_request_id")
    private int leaveRequestId;

    @ManyToOne
    @JoinColumn(name = "employee_number")
    private EmployeeEntity employee;

    @ManyToOne
    @JoinColumn(name = "leave_type_id")
    private LeaveTypeEntity leaveType;

    @ManyToOne
    @JoinColumn(name = "leave_approval_status_id")
    private LeaveApprovalStatusEntity leaveApprovalStatus;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "approved_by")
    private Integer approvedBy;
    
    @Column(name = "approval_date")
    private LocalDate approvalDate;

    public int getLeaveRequestId() {
        return leaveRequestId;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public LeaveTypeEntity getLeaveType() {
        return leaveType;
    }

    public LeaveApprovalStatusEntity getApprovalStatus() {
        return leaveApprovalStatus;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }
    
    public LocalDate getApprovedDate() {
        return approvalDate;
    }

    public void setLeaveRequestId(int leaveRequestId) {
        this.leaveRequestId = leaveRequestId;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public void setLeaveType(LeaveTypeEntity leaveType) {
        this.leaveType = leaveType;
    }

    public void setLeaveApprovalStatus(LeaveApprovalStatusEntity leaveApprovalStatus) {
        this.leaveApprovalStatus = leaveApprovalStatus;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public void setApprovalDate(LocalDate approvalDate) {
        this.approvalDate = approvalDate;
    }
}