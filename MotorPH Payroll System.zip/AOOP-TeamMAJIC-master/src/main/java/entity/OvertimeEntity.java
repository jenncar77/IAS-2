/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "Overtime")
public class OvertimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "overtime_id")
    private int overtimeId;
    
    @ManyToOne
    @JoinColumn(name = "attendance_id")
    private AttendanceEntity attendance;

    @Column(name = "overtime_hours")
    private BigDecimal overtimeHours;

    @Column(name = "overtime_rate")
    private BigDecimal overtimeRate;

    @ManyToOne
    @JoinColumn(name = "overtime_approval_status_id")
    private OvertimeApprovalStatusEntity overtimeApprovalStatus;

    @Column(name = "approved_by")
    private Integer approvedBy;

    @Column(name = "approval_date")
    private LocalDate approvalDate;

    public int getOvertimeId() {
        return overtimeId;
    }

    public AttendanceEntity getAttendance() {
        return attendance;
    }

    public BigDecimal getOvertimeHours() {
        return overtimeHours;
    }

    public BigDecimal getOvertimeRate() {
        return overtimeRate;
    }

    public OvertimeApprovalStatusEntity getOvertimeApprovalStatus() {
        return overtimeApprovalStatus;
    }

    public Integer getApprovedBy() {
        return approvedBy;
    }

    public LocalDate getApprovalDate() {
        return approvalDate;
    }

    public void setOvertimeId(int overtimeId) {
        this.overtimeId = overtimeId;
    }

    public void setAttendance(AttendanceEntity attendance) {
        this.attendance = attendance;
    }

    public void setOvertimeHours(BigDecimal overtimeHours) {
        this.overtimeHours = overtimeHours;
    }

    public void setOvertimeRate(BigDecimal overtimeRate) {
        this.overtimeRate = overtimeRate;
    }

    public void setOvertimeApprovalStatus(OvertimeApprovalStatusEntity overtimeApprovalStatus) {
        this.overtimeApprovalStatus = overtimeApprovalStatus;
    }

    public void setApprovedBy(Integer approvedBy) {
        this.approvedBy = approvedBy;
    }

    public void setApprovalDate(LocalDate approvalDate) {
        this.approvalDate = approvalDate;
    }
}
