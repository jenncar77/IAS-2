/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Mary
 */
@Embeddable
public class RolePermissionId implements Serializable {

    @Column(name = "system_role_id")
    private int systemRoleId;

    @Column(name = "permission_id")
    private int permissionId;

    public RolePermissionId() {
    }

    public RolePermissionId(int systemRoleId, int permissionId) {
        this.systemRoleId = systemRoleId;
        this.permissionId = permissionId;
    }

    public int getSystemRoleId() {
        return systemRoleId;
    }

    public int getPermissionId() {
        return permissionId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RolePermissionId)) return false;
        RolePermissionId that = (RolePermissionId) o;
        return systemRoleId == that.systemRoleId
                && permissionId == that.permissionId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(systemRoleId, permissionId);
    }
}