/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "LeaveType")
public class LeaveTypeEntity {

    @Id
    @Column(name = "leave_type_id")
    private int leaveTypeId;

    @Column(name = "leave_name")
    private String leaveName;

    @Column(name = "is_paid")
    private boolean paid;

    public int getLeaveTypeId() {
        return leaveTypeId;
    }

    public String getLeaveTypeName() {
        return leaveName;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setLeaveTypeId(int leaveTypeId) {
        this.leaveTypeId = leaveTypeId;
    }
}