/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Mary
 */
@Embeddable
public class UserRoleId implements Serializable {

    @Column(name = "user_account_id")
    private int userAccountId;

    @Column(name = "system_role_id")
    private int systemRoleId;

    public UserRoleId() {
    }

    public UserRoleId(int userAccountId, int systemRoleId) {
        this.userAccountId = userAccountId;
        this.systemRoleId = systemRoleId;
    }

    public int getUserAccountId() {
        return userAccountId;
    }

    public int getSystemRoleId() {
        return systemRoleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserRoleId)) return false;
        UserRoleId that = (UserRoleId) o;
        return userAccountId == that.userAccountId
                && systemRoleId == that.systemRoleId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userAccountId, systemRoleId);
    }

    public void setUserAccountId(int userAccountId) {
        this.userAccountId = userAccountId;
    }

    public void setSystemRoleId(int systemRoleId) {
        this.systemRoleId = systemRoleId;
    }
}