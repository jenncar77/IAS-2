/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Mary
 */
import jakarta.persistence.*;

@Entity
@Table(name = "Employee")
public class EmployeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_number")
    private int employeeNumber;

    @Column(name = "sss_number")
    private String sssNumber;

    @Column(name = "philhealth_number")
    private String philhealthNumber;

    @Column(name = "tin_number")
    private String tinNumber;

    @Column(name = "pagibig_number")
    private String pagibigNumber;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private DepartmentEntity department;

    @ManyToOne
    @JoinColumn(name = "position_id")
    private PositionEntity position;

    @ManyToOne
    @JoinColumn(name = "employment_status_id")
    private EmploymentStatusEntity employmentStatus;
    
    @OneToOne(mappedBy = "employee")
    private EmployeeDetailsEntity employeeDetails;
    
    @ManyToOne
    @JoinColumn(name = "immediate_supervisor")
    private EmployeeEntity immediateSupervisor;

    public int getEmployeeNumber() {
        return employeeNumber;
    }

    public String getSssNumber() {
        return sssNumber;
    }

    public String getPhilhealthNumber() {
        return philhealthNumber;
    }

    public String getTinNumber() {
        return tinNumber;
    }

    public String getPagibigNumber() {
        return pagibigNumber;
    }

    public DepartmentEntity getDepartment() {
        return department;
    }

    public PositionEntity getPosition() {
        return position;
    }

    public EmploymentStatusEntity getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmployeeNumber(int employeeNumber) {
        this.employeeNumber = employeeNumber;
    }
    
    public EmployeeDetailsEntity getEmployeeDetails() {
        return employeeDetails;
    }

    public EmployeeEntity getImmediateSupervisor() {
        return immediateSupervisor;
    }

    public void setSssNumber(String sssNumber) {
        this.sssNumber = sssNumber;
    }

    public void setPhilhealthNumber(String philhealthNumber) {
        this.philhealthNumber = philhealthNumber;
    }

    public void setTinNumber(String tinNumber) {
        this.tinNumber = tinNumber;
    }

    public void setPagibigNumber(String pagibigNumber) {
        this.pagibigNumber = pagibigNumber;
    }

    public void setDepartment(DepartmentEntity department) {
        this.department = department;
    }

    public void setPosition(PositionEntity position) {
        this.position = position;
    }

    public void setEmploymentStatus(EmploymentStatusEntity employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    public void setEmployeeDetails(EmployeeDetailsEntity employeeDetails) {
        this.employeeDetails = employeeDetails;
    }

    public void setImmediateSupervisor(EmployeeEntity immediateSupervisor) {
        this.immediateSupervisor = immediateSupervisor;
    }
}