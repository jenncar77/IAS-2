/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 *
 * @author Mary
 */
@Entity
@Table(name = "Deduction")
public class DeductionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "deduction_id")
    private int deductionId;

    @ManyToOne
    @JoinColumn(name = "payroll_id")
    private PayrollEntity payroll;

    @ManyToOne
    @JoinColumn(name = "deduction_type_id")
    private DeductionTypeEntity deductionType;

    @Column(name = "amount")
    private BigDecimal amount;

    public int getDeductionId() {
        return deductionId;
    }

    public PayrollEntity getPayroll() {
        return payroll;
    }

    public DeductionTypeEntity getDeductionType() {
        return deductionType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setDeductionId(int deductionId) {
        this.deductionId = deductionId;
    }

    public void setPayroll(PayrollEntity payroll) {
        this.payroll = payroll;
    }

    public void setDeductionType(DeductionTypeEntity deductionType) {
        this.deductionType = deductionType;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
