/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.LeaveRequestEntity;
import repository.LeaveRepository;

/**
 *
 * @author Mary
 */
public class TestLeaveRepository {

    public static void main(String[] args) {

        LeaveRepository repo =
                new LeaveRepository();

        for (LeaveRequestEntity leave :
                repo.findByEmployeeNumber(10006)) {

            System.out.println(
                    leave.getLeaveRequestId()
                    + " | "
                    + leave.getLeaveType().getLeaveTypeName()
                    + " | "
                    + leave.getApprovalStatus().getLeaveApprovalStatusName()
                    + " | "
                    + leave.getStartDate()
                    + " to "
                    + leave.getEndDate()
            );
        }
    }
}