/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author Mary
 */
import entity.EmployeeDetailsEntity;
import java.util.List;
import repository.EmployeeRepository;

public class TestEmployeeRepository {

    public static void main(String[] args) {
        EmployeeRepository repo = new EmployeeRepository();

        List<EmployeeDetailsEntity> employees = repo.findAll();

        for (EmployeeDetailsEntity emp : employees) {
            System.out.println(
                emp.getEmployeeNumber() + " - " +
                emp.getLastName() + ", " +
                emp.getFirstName()
            );
        }
    }
}
