/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.DeductionEntity;
import repository.DeductionRepository;

/**
 *
 * @author Mary
 */
public class TestDeductionRepository {

    public static void main(String[] args) {

        DeductionRepository repo = new DeductionRepository();

        for (DeductionEntity deduction : repo.findByPayrollId(1)) {
            System.out.println(
                    deduction.getPayroll().getPayrollId()
                    + " - "
                    + deduction.getDeductionType().getDeductionTypeName()
                    + " - "
                    + deduction.getAmount()
            );
        }
    }
}
