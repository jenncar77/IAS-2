/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;
        
import entity.OvertimeEntity;
import repository.OvertimeRepository;        

/**
 *
 * @author Mary
 */
public class TestOvertimeRepository {

    public static void main(String[] args) {

        OvertimeRepository repo = new OvertimeRepository();

        for (OvertimeEntity overtime : repo.findByEmployeeNumber(10006)) {
            System.out.println(
                    overtime.getOvertimeId()
                    + " | Employee: "
                    + overtime.getAttendance().getEmployee().getEmployeeNumber()
                    + " | Hours: "
                    + overtime.getOvertimeHours()
                    + " | Rate: "
                    + overtime.getOvertimeRate()
                    + " | Status: "
                    + overtime.getOvertimeApprovalStatus()
                            .getOvertimeApprovalStatusName()
            );
        }
    }
}
