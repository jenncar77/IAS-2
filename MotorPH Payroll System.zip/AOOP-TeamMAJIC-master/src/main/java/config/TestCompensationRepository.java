/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.CompensationEntity;
import repository.CompensationRepository;

/**
 *
 * @author Mary
 */
public class TestCompensationRepository {

    public static void main(String[] args) {

        CompensationRepository repo =
                new CompensationRepository();

        CompensationEntity compensation =
                repo.findByEmployeeNumber(10001);

        if (compensation != null) {

            System.out.println(
                    compensation.getEmployeeNumber()
                    + " | "
                    + compensation.getMonthlySalary()
            );
        }
    }
}