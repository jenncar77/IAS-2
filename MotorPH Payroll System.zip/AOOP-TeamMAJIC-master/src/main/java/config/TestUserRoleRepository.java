/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.UserRoleEntity;
import repository.UserRoleRepository;

/**
 *
 * @author Mary
 */
public class TestUserRoleRepository {

    public static void main(String[] args) {

        UserRoleRepository repo = new UserRoleRepository();

        for (UserRoleEntity userRole : repo.findByUserAccountId(1)) {
            System.out.println(
                    userRole.getUserAccount().getUsername()
                    + " | Role: "
                    + userRole.getSystemRole().getRoleName()
            );
        }
    }
}