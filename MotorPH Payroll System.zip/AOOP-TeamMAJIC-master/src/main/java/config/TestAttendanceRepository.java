/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.AttendanceEntity;
import repository.AttendanceRepository;

/**
 *
 * @author Mary
 */
public class TestAttendanceRepository {

    public static void main(String[] args) {

        AttendanceRepository repo = new AttendanceRepository();

        for (AttendanceEntity attendance : repo.findByEmployeeNumber(10005)) {
            System.out.println(
                    attendance.getAttendanceId()
                    + " | "
                    + attendance.getEmployee().getEmployeeNumber()
                    + " | "
                    + attendance.getAttendanceDate()
                    + " | "
                    + attendance.getLogin()
                    + " - "
                    + attendance.getLogout()
            );
        }
    }
}