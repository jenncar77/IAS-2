/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.PayrollEntity;
import java.util.List;
import repository.PayrollRepository;

/**
 *
 * @author Mary
 */
public class TestPayrollRepository {

    public static void main(String[] args) {

        PayrollRepository repo = new PayrollRepository();

        List<PayrollEntity> payrolls = repo.findAll();

        for (PayrollEntity payroll : payrolls) {
            System.out.println(
                payroll.getPayrollId() + " - "
                + payroll.getEmployee().getEmployeeNumber()
                + " | Gross: " + payroll.getGrossPay()
                + " | Allowances: " + payroll.getTotalAllowances()
                + " | Deductions: " + payroll.getTotalDeductions()
                + " | Net Pay: " + payroll.getNetPay()
                );
            }
    }
}