/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.AllowanceEntity;
import repository.AllowanceRepository;

/**
 *
 * @author Mary
 */
public class TestAllowanceRepository {

    public static void main(String[] args) {

        AllowanceRepository repo = new AllowanceRepository();

        for (AllowanceEntity allowance : repo.findByEmployeeNumber(10005)) {
            System.out.println(
                    allowance.getEmployee().getEmployeeNumber()
                    + " - "
                    + allowance.getAllowanceType().getAllowanceTypeName()
                    + " - "
                    + allowance.getAmount()
            );
        }
    }
}