/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.RolePermissionEntity;
import repository.RolePermissionRepository;

/**
 *
 * @author Mary
 */
public class TestRolePermissionRepository {

    public static void main(String[] args) {

        RolePermissionRepository repo = new RolePermissionRepository();

        for (RolePermissionEntity rolePermission : repo.findByRoleId(1)) {
            System.out.println(
                    rolePermission.getSystemRole().getRoleName()
                    + " | "
                    + rolePermission.getPermission().getAccessLevel()
                    + " "
                    + rolePermission.getPermission().getRecordType()
            );
        }
    }
}