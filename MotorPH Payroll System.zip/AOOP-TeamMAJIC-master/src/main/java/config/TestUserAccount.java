/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.UserAccountEntity;
import org.hibernate.Session;

public class TestUserAccount {

    public static void main(String[] args) {

        try (Session session =
                HibernateUtil.getSessionFactory().openSession()) {

            UserAccountEntity user =
                    session.get(UserAccountEntity.class, 5);

            if (user != null) {

                System.out.println("User Found!");
                System.out.println(
                        "Username: " + user.getUsername()
                );
                System.out.println(
                        "Status: " + user.getAccountStatus()
                );

            } else {

                System.out.println("User not found.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
}