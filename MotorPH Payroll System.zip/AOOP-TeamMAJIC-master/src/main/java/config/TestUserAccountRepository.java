/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import entity.UserAccountEntity;
import repository.UserAccountRepository;

/**
 *
 * @author Mary
 */
public class TestUserAccountRepository {

    public static void main(String[] args) {

        UserAccountRepository repo = new UserAccountRepository();

        UserAccountEntity user =
                repo.findByUsername("antonio_lim@motorph.com");

        if (user != null) {
            System.out.println(
                    user.getUserAccountId()
                    + " | "
                    + user.getUsername()
                    + " | "
                    + user.getAccountStatus()
                    + " | Employee: "
                    + user.getEmployeeNumber()
            );
        } else {
            System.out.println("User not found.");
        }
    }
}
