/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author Mary
 */

import org.hibernate.Session;

public class TestHibernate {
    
 public static void main(String[] args) {

        try (Session session =
                HibernateUtil.getSessionFactory().openSession()) {

            System.out.println(
                    "SUCCESS! Hibernate connected to MySQL."
            );

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
}
