package model;

/**
 * Defines payroll-related values that can be computed or displayed.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public interface Payable {

    double getHoursWorked();
    double getOvertimeHours();
    double getOvertimePay();
    double getGrossIncome();
    double getNetIncome();
    double getSss();
    double getPhilHealth();
    double getPagibig();
    double getTax();
    double getTotalDeductions();

    default boolean hasOvertime() {
        return getOvertimeHours() > 0;
    }

    default boolean hasDeductions() {
        return getTotalDeductions() > 0;
    }
}
