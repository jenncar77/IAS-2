package model;

/**
 * Represents the login details associated with an employee account.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class EmployeeLogin {

    // Username entered by the employee during login
    private String userName;

    // Password entered by the employee during login
    private String password;

    /**
     * Default constructor.
     * Used when setting fields manually using setter methods.
     */
    public EmployeeLogin() {
        // Empty constructor for flexibility
    }

    /**
     * Constructor with username and password.
     * Useful for quickly creating an EmployeeLogin object.
     *
     * @param userName the employee's username
     * @param password the employee's password
     */
    public EmployeeLogin(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    /**
     * Gets the employee's username.
     *
     * @return the username entered by the employee
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the employee's username.
     *
     * @param userName the username to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Gets the employee's password.
     *
     * @return the password entered by the employee
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the employee's password.
     *
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Returns a masked version of the password for display/logging.
     * Each character is replaced with an asterisk for security.
     *
     * @return masked password string (e.g., "*******")
     */
    private String maskPassword() {
        // If password is empty or null, return a fixed mask
        if (password == null || password.isEmpty()) {
            return "********";
        }
        // Replace each character with an asterisk
        return "*".repeat(password.length());
    }

    /**
     * Returns a string representation of the EmployeeLogin object.
     * Password is masked for security.
     *
     * @return string with username and masked password
     */
    @Override
    public String toString() {
        return "EmployeeLogin{" +
               "userName='" + userName + '\'' +
               ", password='" + maskPassword() + '\'' +
               '}';
    }
}
