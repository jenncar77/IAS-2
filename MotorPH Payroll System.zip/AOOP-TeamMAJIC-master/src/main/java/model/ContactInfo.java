package model;

/**
 * Represents the contact information stored for an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class ContactInfo {

    private String address;  // Employee's home address
    private String phoneNo;  // Employee's phone number
    private String email;    // Employee's email address

    /**
     * Constructor that initializes ContactInfo
     * @param data A String array containing employee data
     */
    public ContactInfo(String[] data) {
        this.address = getValue(data, 4);  // Column E: Address
        this.phoneNo = getValue(data, 5);  // Column F: Phone Number
        this.email = hasEmailColumn(data) ? getValue(data, 6) : "";
    }

    private static boolean hasEmailColumn(String[] data) {
        return data != null && data.length >= 20;
    }

    private static String getValue(String[] data, int index) {
        if (data == null || index >= data.length || data[index] == null) {
            return "";
        }
        return data[index].trim();
    }

    // Getter for employee address
    public String getAddress() {
        return address;
    }

    // Getter for employee phone number
    public String getPhoneNo() {
        return phoneNo;
    }

    // Getter for employee email address
    public String getEmail() {
        return email;
    }

    /**
     * Returns a string representation of the contact info,
     * useful for debugging or display purposes.
     */
    @Override
    public String toString() {
        return "Address: " + address + ", Phone: " + phoneNo + ", Email: " + email;
    }
}
