package model;

import utils.EmployeePosition;

/**
 * Represents the job-related information assigned to an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class JobDetails {

    private String supervisorFullName;    // Name of the employee's direct supervisor
    private EmployeePosition position;    // Enumerated position value of the employee
    private String employeeStatus;        // Employment status (such as Regular, Probationary)

    /**
     * Constructor that initializes job details
     * @param data an array of employee data strings 
     */
    public JobDetails(String[] data) {
        int offset = hasEmailColumn(data) ? 1 : 0;
        this.supervisorFullName = getValue(data, 12 + offset);
        this.position = EmployeePosition.fromDisplayName(getValue(data, 11 + offset));
        this.employeeStatus = getValue(data, 10 + offset);
    }

    private static boolean hasEmailColumn(String[] data) {
        return data != null && data.length >= 20;
    }

    private static String getValue(String[] data, int index) {
        if (data == null || index >= data.length || data[index] == null) {
            return "";
        }
        return data[index].trim();
    }

    /**
     * Gets the full name of the employee's supervisor.
     * @return supervisor's full name
     */
    public String getSupervisorFullName() {
        return supervisorFullName;
    }

    /**
     * Gets the position (as an enum) of the employee.
     * @return EmployeePosition enum value
     */
    public EmployeePosition getPosition() {
        return position;
    }

    /**
     * Gets the employment status of the employee.
     * @return status string (e.g., Regular, Contractual)
     */
    public String getEmployeeStatus() {
        return employeeStatus;
    }
}
