package model;

import java.time.LocalDate;
import java.time.DayOfWeek;

/**
 * Represents a leave application filed by an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class LeaveRequest {

    // Private fields
    private String leaveId;
    private String employeeNumber;
    private LocalDate startDate;
    private LocalDate endDate;
    private String reason;
    private String status; // Pending, Approved, Rejected

    /*
     * Constructor
     */
    public LeaveRequest(String leaveId,
                        String employeeNumber,
                        LocalDate startDate,
                        LocalDate endDate,
                        String reason) {

        if (leaveId == null || employeeNumber == null) {
            throw new IllegalArgumentException("Leave ID and Employee Number cannot be null.");
        }

        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("End date cannot be before start date.");
        }

        this.leaveId = leaveId;
        this.employeeNumber = employeeNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = "Pending";
    }

    // =========================
    // Getters
    // =========================

    public String getLeaveId() {
        return leaveId;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public String getReason() {
        return reason;
    }

    public String getStatus() {
        return status;
    }

    // =========================
    // Calculate leave days
    // =========================

    public int calculateLeaveDays() {

        if (endDate.isBefore(startDate)) {
            throw new IllegalStateException("Invalid dates: end date before start date.");
        }

        int workingDays = 0;
        LocalDate date = startDate;

        while (!date.isAfter(endDate)) {
            DayOfWeek day = date.getDayOfWeek();

            if (day != DayOfWeek.SATURDAY && day != DayOfWeek.SUNDAY) {
                workingDays++;
            }

            date = date.plusDays(1);
        }

        return workingDays;
    }
    
    public int getLeaveDays() {
        return calculateLeaveDays();
    }

    // =========================
    // Status control
    // =========================

    public void approve() {

        if (!status.equals("Pending")) {
            throw new IllegalStateException("Leave already processed.");
        }

        status = "Approved";
    }

    public void reject() {

        if (!status.equals("Pending")) {
            throw new IllegalStateException("Leave already processed.");
        }

        status = "Rejected";
    }

    public boolean isApproved() {
        return status.equalsIgnoreCase("Approved");
    }

    // =========================
    // toString
    // =========================

    @Override
    public String toString() {

        return "Leave ID: " + leaveId +
               "\nEmployee #: " + employeeNumber +
               "\nStart Date: " + startDate +
               "\nEnd Date: " + endDate +
               "\nDays: " + calculateLeaveDays() +
               "\nStatus: " + status +
               "\nReason: " + reason;
    }
}
