package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Represents the computed payroll breakdown for an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class PayrollSummary implements Payable {

    private final double hoursWorked;
    private final double overtimeHours;
    private final double overtimePay;
    private final double grossIncome;
    private final double netIncome;
    private final double sss;
    private final double philHealth;
    private final double pagibig;
    private final double tax;
    private final double totalDeductions;
    private final double monthlySalary;
    private final double totalAllowances;

    public PayrollSummary(double hoursWorked, double overtimeHours, double overtimePay,
                          double grossIncome, double netIncome,
                          double sss, double philHealth, double pagibig,
                          double tax, double totalDeductions) {
        this(hoursWorked, overtimeHours, overtimePay,
                grossIncome, netIncome,
                sss, philHealth, pagibig,
                tax, totalDeductions,
                0.0, 0.0);
    }

    public PayrollSummary(double hoursWorked, double overtimeHours, double overtimePay,
                          double grossIncome, double netIncome,
                          double sss, double philHealth, double pagibig,
                          double tax, double totalDeductions,
                          double monthlySalary, double totalAllowances) {
        this.hoursWorked = hoursWorked;
        this.overtimeHours = overtimeHours;
        this.overtimePay = overtimePay;
        this.grossIncome = grossIncome;
        this.netIncome = netIncome;
        this.sss = sss;
        this.philHealth = philHealth;
        this.pagibig = pagibig;
        this.tax = tax;
        this.totalDeductions = totalDeductions;
        this.monthlySalary = monthlySalary;
        this.totalAllowances = totalAllowances;
    }

    public PayrollSummary(double hoursWorked, double hourlyRate) {
        this.hoursWorked = hoursWorked;
        this.overtimeHours = 0;
        this.overtimePay = 0;
        this.grossIncome = hoursWorked * hourlyRate;
        this.sss = 0;
        this.philHealth = 0;
        this.pagibig = 0;
        this.tax = 0;
        this.totalDeductions = 0;
        this.monthlySalary = 0;
        this.totalAllowances = 0;
        this.netIncome = grossIncome - totalDeductions;
    }

    public PayrollSummary(double hoursWorked, double overtimeHours, double hourlyRate, double overtimeMultiplier) {
        this.hoursWorked = hoursWorked;
        this.overtimeHours = overtimeHours;
        this.overtimePay = overtimeHours * hourlyRate * overtimeMultiplier;
        this.grossIncome = (hoursWorked * hourlyRate) + overtimePay;
        this.sss = 0;
        this.philHealth = 0;
        this.pagibig = 0;
        this.tax = 0;
        this.totalDeductions = 0;
        this.monthlySalary = 0;
        this.totalAllowances = 0;
        this.netIncome = grossIncome - totalDeductions;
    }

    @Override
    public double getHoursWorked() { return hoursWorked; }

    @Override
    public double getOvertimeHours() { return overtimeHours; }

    @Override
    public double getOvertimePay() { return overtimePay; }

    @Override
    public double getGrossIncome() { return grossIncome; }

    @Override
    public double getNetIncome() { return netIncome; }

    @Override
    public double getSss() { return sss; }

    @Override
    public double getPhilHealth() { return philHealth; }

    @Override
    public double getPagibig() { return pagibig; }

    @Override
    public double getTax() { return tax; }

    @Override
    public double getTotalDeductions() { return totalDeductions; }

    public double getMonthlySalary() { return monthlySalary; }

    public double getSemiMonthlyBasePay() { return monthlySalary / 2; }

    public double getRegularPay() {
        BigDecimal roundedDailyRate = BigDecimal.valueOf(getDailyRate())
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal roundedDaysWorked = BigDecimal.valueOf(getDaysWorked())
                .setScale(2, RoundingMode.HALF_UP);

        return roundedDailyRate
                .multiply(roundedDaysWorked)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
    }

    public double getTotalAllowances() { return totalAllowances; }

    public double getDailyRate() { return monthlySalary / 21; }

    public double getDaysWorked() { return hoursWorked / 8; }

    @Override
    public boolean hasOvertime() { return overtimeHours > 0; }

    @Override
    public boolean hasDeductions() { return totalDeductions > 0; }
}
