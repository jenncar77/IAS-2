package model;

/**
 * Defines password management operations for user-capable roles.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public interface PasswordOperations {
    void resetPassword(String employeeNumber, String newPassword);
}
