package model;

import service.EmployeeService;
import java.io.IOException;

/**
 * Represents a finance employee within the system.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class FinanceUser extends Employee implements ViewOperations {

    private final EmployeeService employeeService;

    public FinanceUser(String employeeNumber,
                       String firstName,
                       String lastName,
                       String position,
                       EmployeeService employeeService) {

        super(employeeNumber, firstName, lastName, position);
        this.employeeService = employeeService;
    }

    @Override
    public EmployeeDetails viewEmployee(String employeeNumber) {

        try {
            return employeeService.getEmployeeById(employeeNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public PayrollSummary viewPayroll(String employeeNumber) {

        try {

            EmployeeDetails emp =
                    employeeService.getEmployeeById(employeeNumber);

            if (emp != null) {
                return emp.getPayrollSummary();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public EmployeeDetails viewOwnInfo() {

        try {
            return employeeService.getEmployeeById(this.employeeNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public PayrollSummary viewOwnPayroll() {
        return payrollSummary;
    }

    @Override
    public PayrollSummary getPayrollSummary() {
        return payrollSummary;
    }
}
