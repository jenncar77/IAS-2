package model;

/**
 * Represents an employee under probationary status.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class ProbationaryEmployee extends Employee {

    private double hoursWorked;
    private double hourlyRate;

    public ProbationaryEmployee(String employeeNumber, String firstName, String lastName, String position,
                                double hoursWorked, double hourlyRate) {
        super(employeeNumber, firstName, lastName, position);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;

        // Probationary employees: no overtime by default
        PayrollSummary summary = new PayrollSummary(hoursWorked, hourlyRate);
        this.setPayrollSummary(summary);
    }

    // Overriding the abstract method
    @Override
    public PayrollSummary getPayrollSummary() {
        return payrollSummary;
    }

    // Optional: allow updating hours worked and recalculate payroll
    public void updateHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
        this.setPayrollSummary(new PayrollSummary(hoursWorked, hourlyRate));
    }

    public void updateHoursWorked(double hoursWorked, double hourlyRate) {
    this.hoursWorked = hoursWorked;
    this.hourlyRate = hourlyRate;
    this.setPayrollSummary(new PayrollSummary(hoursWorked, hourlyRate));
}

}
