package model;

/**
 * Represents the government identification numbers linked to an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class GovernmentID {

    private String sss;         // Social Security System number
    private String philHealth;  // PhilHealth number
    private String tin;         // Tax Identification Number
    private String pagibig;     // Pag-IBIG Fund number

    /**
     * Constructor to initialize government IDs
     * @param data the String array
     */
    public GovernmentID(String[] data) {
        int offset = hasEmailColumn(data) ? 1 : 0;
        this.sss = getValue(data, 6 + offset);
        this.philHealth = getValue(data, 7 + offset);
        this.tin = getValue(data, 8 + offset);
        this.pagibig = getValue(data, 9 + offset);
    }

    private static boolean hasEmailColumn(String[] data) {
        return data != null && data.length >= 20;
    }

    private static String getValue(String[] data, int index) {
        if (data == null || index >= data.length || data[index] == null) {
            return "";
        }
        return data[index].trim();
    }

    // Getter for SSS number
    public String getSSS() {
        return sss;
    }

    // Getter for PhilHealth number
    public String getPhilhealth() {
        return philHealth;
    }

    // Getter for TIN number
    public String getTIN() {
        return tin;
    }

    // Getter for Pag-IBIG number
    public String getPagibig() {
        return pagibig;
    }

    /**
     * Returns a readable string format of all government IDs.
     * Useful for logging or display purposes.
     *
     * @return formatted string of government IDs
     */
    @Override
    public String toString() {
        return "SSS: " + sss + ", PhilHealth: " + philHealth +
               ", TIN: " + tin + ", Pag-IBIG: " + pagibig;
    }
}
