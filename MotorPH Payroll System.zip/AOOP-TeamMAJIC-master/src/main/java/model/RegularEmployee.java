package model;

/**
 * Represents an employee under regular status.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class RegularEmployee extends Employee {

    private double hoursWorked;
    private double overtimeHours;
    private double hourlyRate;
    private double overtimeMultiplier;

    public RegularEmployee(String employeeNumber, String firstName, String lastName, String position,
                           double hoursWorked, double overtimeHours,
                           double hourlyRate, double overtimeMultiplier) {
        super(employeeNumber, firstName, lastName, position);
        this.hoursWorked = hoursWorked;
        this.overtimeHours = overtimeHours;
        this.hourlyRate = hourlyRate;
        this.overtimeMultiplier = overtimeMultiplier;

        // Regular employees: include overtime
        PayrollSummary summary = new PayrollSummary(hoursWorked, overtimeHours, hourlyRate, overtimeMultiplier);
        this.setPayrollSummary(summary);
    }

    // Overriding the abstract method
    @Override
    public PayrollSummary getPayrollSummary() {
        return payrollSummary;
    }

    // Optional: allow updating hours/overtime and recalculate payroll
    public void updateHoursWorked(double hoursWorked, double overtimeHours) {
        this.hoursWorked = hoursWorked;
        this.overtimeHours = overtimeHours;
        this.setPayrollSummary(new PayrollSummary(hoursWorked, overtimeHours, hourlyRate, overtimeMultiplier));
    }

    public void updateHoursWorked(double hoursWorked) {
    this.hoursWorked = hoursWorked;
    this.setPayrollSummary(new PayrollSummary(hoursWorked, overtimeHours, hourlyRate, overtimeMultiplier));
}

}
