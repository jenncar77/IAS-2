package model;

/**
 * Represents an HR employee within the system.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class HRUser extends Employee {

    public HRUser(String employeeNumber,
                  String firstName,
                  String lastName,
                  String position) {

        super(employeeNumber, firstName, lastName, position);
    }

    @Override
    public PayrollSummary getPayrollSummary() {
        return payrollSummary;
    }

}
