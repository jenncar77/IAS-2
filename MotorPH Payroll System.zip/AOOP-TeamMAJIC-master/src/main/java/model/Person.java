package model;

import utils.EmployeeFormatter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Represents the personal identity details of an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public final class Person {
    // Fields for storing basic personal information
    private final String lastName;
    private final String firstName;
    private final LocalDate birthday;

    // Constructor that initializes the person's data using a String array
    public Person(String[] data) {
        this.lastName = data[1]; // Index 1 = Last Name
        this.firstName = data[2]; // Index 2 = First Name
        this.birthday = EmployeeFormatter.parseBirthday(data[3]); // Index 3 = Birthday, parsed from String to LocalDate
    }

    // Getter for last name
    public String getLastName() { return lastName; }

    // Getter for first name
    public String getFirstName() { return firstName; }

    // Getter for birthday as LocalDate
    public LocalDate getBirthday() { return birthday; }

    // Returns the birthday in MM/dd/yyyy format as a String
    public String getFormattedBirthday() {
    if (birthday == null) return "";
    return birthday.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
}

    // Overrides the default toString method to show full name and formatted DOB
    @Override
    public String toString() {
        return String.format("%s %s (DOB: %s)", firstName, lastName, getFormattedBirthday());
    }
}
