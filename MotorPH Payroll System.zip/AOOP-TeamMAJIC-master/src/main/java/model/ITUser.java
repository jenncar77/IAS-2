package model;

import service.EmployeeService;
import service.LoginService;
import java.io.IOException;

/**
 * Represents an IT employee within the system.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class ITUser extends Employee implements ViewOperations, PasswordOperations {

    private final EmployeeService employeeService;

    public ITUser(String employeeNumber,
                  String firstName,
                  String lastName,
                  String position,
                  EmployeeService employeeService) {

        super(employeeNumber, firstName, lastName, position);
        this.employeeService = employeeService;
    }

    @Override

    public void resetPassword(String employeeNumber, String newPassword) {

        LoginService loginService = LoginService.getInstance();

        // Your system resets password to default
        loginService.resetPasswordToDefault(employeeNumber);

    }

    @Override
    public EmployeeDetails viewEmployee(String employeeNumber) {

        try {
            return employeeService.getEmployeeById(employeeNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public PayrollSummary viewPayroll(String employeeNumber) {
        return null;
    }

    @Override
    public EmployeeDetails viewOwnInfo() {

        try {
            return employeeService.getEmployeeById(this.employeeNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public PayrollSummary viewOwnPayroll() {
        return payrollSummary;
    }

    @Override
    public PayrollSummary getPayrollSummary() {
        return payrollSummary;
    }
}
