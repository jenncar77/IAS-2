package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Defines the shared state and behavior for all employee types.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public abstract class Employee implements Payable {
    String employeeNumber;
    private String firstName;
    private String lastName;
    private String position;
    PayrollSummary payrollSummary; // store computed payroll

    // =============================
    // NEW: Leave tracking list
    // =============================
    private List<LeaveRequest> leaveRequests = new ArrayList<>();

    public Employee(String employeeNumber, String firstName, String lastName, String position) {
        this.employeeNumber = employeeNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public void setPayrollSummary(PayrollSummary summary) {
        this.payrollSummary = summary;
    }

    // =========================================================
    // LEAVE REQUEST FUNCTIONALITY (ALL EMPLOYEES CAN REQUEST)
    // =========================================================

    /*
     * Employee files a leave request
     * Status automatically = Pending
     */
    public LeaveRequest requestLeave(
            String leaveId,
            LocalDate startDate,
            LocalDate endDate,
            String reason
    ) {

        LeaveRequest leave = new LeaveRequest(
                leaveId,
                this.employeeNumber,
                startDate,
                endDate,
                reason
        );

        leaveRequests.add(leave);
        return leave;
    }

    /*
     * View all leave requests of employee
     */
    public List<LeaveRequest> getLeaveRequests() {
        return leaveRequests;
    }

    /*
     * Get approved leaves only (useful for payroll deduction)
     */
    public List<LeaveRequest> getApprovedLeaves() {
        List<LeaveRequest> approved = new ArrayList<>();

        for (LeaveRequest lr : leaveRequests) {
            if (lr.isApproved()) {
                approved.add(lr);
            }
        }
        return approved;
    }

    /*
     * OPTIONAL: compute total unpaid leave deduction
     * for payroll integration
     */
    public double computeTotalLeaveDeduction(double dailyRate) {

        double total = 0;

        for (LeaveRequest lr : leaveRequests) {

            if (lr.isApproved()) {

                total += lr.getLeaveDays() * dailyRate;

            }
        }

        return total;
    }

    // =========================================================
    // EXISTING PAYROLL METHODS
    // =========================================================
    @Override
    public double getHoursWorked() {
        return payrollSummary.getHoursWorked();
    }

    @Override
    public double getOvertimeHours() {
        return payrollSummary.getOvertimeHours();
    }

    @Override
    public double getOvertimePay() {
        return payrollSummary.getOvertimePay();
    }

    @Override
    public double getGrossIncome() {
        return payrollSummary.getGrossIncome();
    }

    @Override
    public double getNetIncome() {
        return payrollSummary.getNetIncome();
    }

    @Override
    public double getSss() {
        return payrollSummary.getSss();
    }

    @Override
    public double getPhilHealth() {
        return payrollSummary.getPhilHealth();
    }

    @Override
    public double getPagibig() {
        return payrollSummary.getPagibig();
    }

    @Override
    public double getTax() {
        return payrollSummary.getTax();
    }

    @Override
    public double getTotalDeductions() {
        return payrollSummary.getTotalDeductions();
    }

    @Override
    public boolean hasOvertime() {
        return payrollSummary.hasOvertime();
    }

    @Override
    public boolean hasDeductions() {
        return payrollSummary.hasDeductions();
    }

    public abstract PayrollSummary getPayrollSummary();
}
