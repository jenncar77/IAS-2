package model;

/**
 * Represents the full employee profile
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class EmployeeDetails extends Employee {

    private final Person name;
    private final ContactInfo contact;
    private final GovernmentID govID;
    private final JobDetails jobDetails;
    private final Compensation compensation;

    public EmployeeDetails(String[] data) {
        super(
                getValue(data, 0),
                getValue(data, 2),
                getValue(data, 1),
                getValue(data, hasEmailColumn(data) ? 12 : 11)
        );

        this.employeeNumber = getValue(data, 0);
        this.name = new Person(data);
        this.contact = new ContactInfo(data);
        this.govID = new GovernmentID(data);
        this.jobDetails = new JobDetails(data);

        this.compensation = new Compensation(data);
    }

    private static boolean hasEmailColumn(String[] data) {
        return data != null && data.length >= 20;
    }

    private static String getValue(String[] data, int index) {
        if (data == null || index >= data.length || data[index] == null) {
            return "";
        }
        return data[index].trim();
    }

    // Getters

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public Person getPerson() {
        return name;
    }

    public ContactInfo getContact() {
        return contact;
    }

    public GovernmentID getGovID() {
        return govID;
    }

    public JobDetails getJobDetails() {
        return jobDetails;
    }

    public Compensation getCompensation() {
        return compensation;
    }

    /**
     * Returns the full name in "First Last" format.
     * @return
     */
    @Override
    public String getFullName() {
        return name.getFirstName() + " " + name.getLastName();
    }

    /**
     * Associates a computed payroll summary to this employee.
     *
     * @param payrollSummary the computed payroll summary
     */
    @Override
    public void setPayrollSummary(PayrollSummary payrollSummary) {
        this.payrollSummary = payrollSummary;
    }

    /**
     * Retrieves the payroll summary for this employee.
     *
     * @return the payroll summary object
     */
    @Override
    public PayrollSummary getPayrollSummary() {
        return this.payrollSummary;
    }

    /**
     * Converts the employee's full data
     *
     * @return an array of string values representing the employee's data
     */
    public String[] toCSVArray() {
        return new String[] {
            employeeNumber,
            name.getLastName(),
            name.getFirstName(),
            name.getBirthday().toString(),
            contact.getAddress(),
            contact.getPhoneNo(),
            contact.getEmail(),
            govID.getSSS(),
            govID.getPhilhealth(),
            govID.getTIN(),
            govID.getPagibig(),
            jobDetails.getEmployeeStatus(),
            jobDetails.getPosition().getDisplayName(),
            jobDetails.getSupervisorFullName(),
            String.valueOf(compensation.getBasicSalary()),
            String.valueOf(compensation.getRiceSubsidy()),
            String.valueOf(compensation.getPhoneAllowance()),
            String.valueOf(compensation.getClothingAllowance()),
            String.valueOf(compensation.getGrossSemiMonthly()),
            String.valueOf(compensation.getHourlyRate())
        };
    }
}
