package model;

/**
 * Defines dashboard and view capabilities exposed to authorized roles.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public interface ViewOperations {
    EmployeeDetails viewEmployee(String employeeNumber);
    PayrollSummary viewPayroll(String employeeNumber);

    // For roles that can view their own info/payroll
    EmployeeDetails viewOwnInfo();
    PayrollSummary viewOwnPayroll();
}
