package model;

/**
 * Represents the compensation details assigned to an employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class Compensation {

    // Fields for various components of employee compensation
    private double basicSalary;
    private double riceSubsidy;
    private double phoneAllowance;
    private double clothingAllowance;
    private double grossSemiMonthly;
    private double hourlyRate;

    // Constructor that accepts direct numeric values for all compensation fields
    public Compensation(double basicSalary, double riceSubsidy, double phoneAllowance,
                        double clothingAllowance, double grossSemiMonthly, double hourlyRate) {
        this.basicSalary = basicSalary;
        this.riceSubsidy = riceSubsidy;
        this.phoneAllowance = phoneAllowance;
        this.clothingAllowance = clothingAllowance;
        this.grossSemiMonthly = grossSemiMonthly;
        this.hourlyRate = hourlyRate;
    }

    // Constructor that parses and assigns compensation values
    public Compensation(String[] data) {
        int offset = hasEmailColumn(data) ? 1 : 0;
        this.basicSalary = parseDouble(getValue(data, 13 + offset));
        this.riceSubsidy = parseDouble(getValue(data, 14 + offset));
        this.phoneAllowance = parseDouble(getValue(data, 15 + offset));
        this.clothingAllowance = parseDouble(getValue(data, 16 + offset));
        this.grossSemiMonthly = parseDouble(getValue(data, 17 + offset));
        this.hourlyRate = parseDouble(getValue(data, 18 + offset));
    }

    private static boolean hasEmailColumn(String[] data) {
        return data != null && data.length >= 20;
    }

    private static String getValue(String[] data, int index) {
        if (data == null || index >= data.length || data[index] == null) {
            return "";
        }
        return data[index].trim();
    }

    // Getters for each compensation component
    public double getBasicSalary() {
        return basicSalary;
    }

    public double getRiceSubsidy() {
        return riceSubsidy;
    }

    public double getPhoneAllowance() {
        return phoneAllowance;
    }

    public double getClothingAllowance() {
        return clothingAllowance;
    }

    public double getGrossSemiMonthly() {
        return grossSemiMonthly;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    // Utility method to clean and safely convert a string to a double value
    private double parseDouble(String value) {
        // Remove commas, quotes, and whitespace
        String cleanValue = value.replace(",", "").replace("\"", "").trim();

        // If value is empty or marked as "N/A", return 0.0
        if (cleanValue.isEmpty() || cleanValue.equalsIgnoreCase("N/A")) {
            return 0.0;
        }

        try {
            // Try converting cleaned value to a double
            return Double.parseDouble(cleanValue);
        } catch (NumberFormatException e) {
            // Return 0.0 if conversion fails
            return 0.0;
        }
    }
}
