package ui;

import entity.EmployeeDetailsEntity;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import service.AttendanceService;
import service.EmployeeService;
import service.LoginService;
import service.PayrollService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import utils.CutoffDateUtils;
import utils.JasperTimeCardExporter;

/**
 * Displays the timesheet viewing screen.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class Timesheet extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(Timesheet.class.getName());

    /**
     * Service Layer
     */
    private final AttendanceService attendanceService =
        new AttendanceService();
    
    private final PayrollService payrollService =
        new PayrollService();

    private final EmployeeService employeeService =
        new EmployeeService();

    public Timesheet() {

        initComponents();
        lblTimesheet.setEnabled(false);

        WindowUtils.applyStandardWindowConfig(this, "Timesheet");

        tblTimesheet.setRowHeight(33);

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                logger.severe(ex.getMessage());
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(Timesheet.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

        // Open logout confirmation ONLY (no logout yet)
        LogOutFrame.showLogoutFrame(this);
        });

        loadMonthDropdown();

        cmbSelectMonthYear.addActionListener(e -> {
            updateCutoffDropdown();
            loadTimesheet();
        });

        cmbChoosePayPeriod.addActionListener(e -> loadTimesheet());

        btnDownloadTimeCard.addActionListener(e -> downloadTimeCardReport());

        setLatestSelections();

        loadTimesheet();
    }

    private void loadMonthDropdown() {

        try {

            cmbSelectMonthYear.removeAllItems();

            List<String> months =
                    payrollService.getAvailablePayrollMonths();

            for (String month : months) {
                cmbSelectMonthYear.addItem(month);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   private void setLatestSelections() {

        try {

            List<String[]> rows =
                    attendanceService.getAllAttendance();

            DateTimeFormatter formatter =
                    DateTimeFormatter.ISO_LOCAL_DATE;

            LocalDate latestDate = null;

            for (String[] row : rows) {

                if (row.length < 4) continue;

                LocalDate date = LocalDate.parse(row[3], formatter);

                if (latestDate == null || date.isAfter(latestDate)) {
                    latestDate = date;
                }
            }

            if (latestDate == null) return;

            String latestMonth =
                    latestDate.getMonth()
                            .getDisplayName(TextStyle.FULL, Locale.ENGLISH)
                    + " "
                    + latestDate.getYear();

            cmbSelectMonthYear.setSelectedItem(latestMonth);

            updateCutoffDropdown();

            if (latestDate.getDayOfMonth() <= 15) {
                cmbChoosePayPeriod.setSelectedItem("1st-15th");
            } else {
                int lastDay =
                        latestDate.lengthOfMonth();

                cmbChoosePayPeriod.setSelectedItem(
                    "16th-" + CutoffDateUtils.getDayWithSuffix(lastDay)
            );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateCutoffDropdown() {

        String selectedMonthYear =
                (String) cmbSelectMonthYear.getSelectedItem();

        if (selectedMonthYear == null) {
            return;
        }

        java.time.YearMonth yearMonth =
                java.time.YearMonth.parse(
                        selectedMonthYear,
                        java.time.format.DateTimeFormatter.ofPattern("MMMM yyyy")
                );

        int lastDay = yearMonth.lengthOfMonth();

        cmbChoosePayPeriod.setModel(
                new javax.swing.DefaultComboBoxModel<>(
                        new String[]{
                            "1st-15th",
                            "16th-" + CutoffDateUtils.getDayWithSuffix(lastDay)
                        }
                )
        );
    }

    private void loadTimesheet() {

        try {

            String employeeNumber =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            String selectedMonthYear =
                    (String) cmbSelectMonthYear.getSelectedItem();

            String selectedCutoff =
                    (String) cmbChoosePayPeriod.getSelectedItem();

            if (selectedMonthYear == null || selectedCutoff == null) return;

            LocalDate[] range =
                    CutoffDateUtils.getCutoffDateRange(selectedMonthYear, selectedCutoff);

            if (range == null) return;

            LocalDate startDate = range[0];
            LocalDate endDate = range[1];

            List<String[]> records =
                    attendanceService.getAttendanceByEmployee(employeeNumber);
            
            DefaultTableModel model =
                    (DefaultTableModel) tblTimesheet.getModel();

            model.setRowCount(0);

            DateTimeFormatter formatter =
                DateTimeFormatter.ISO_LOCAL_DATE;

            for (String[] row : records) {

                LocalDate date =
                        LocalDate.parse(row[3], formatter);

                if (!date.isBefore(startDate) && !date.isAfter(endDate)) {

                    String clockIn = row[4];
                    String clockOut = row[5];

                    String hours =
                            attendanceService.calculateWorkingHours(clockIn, clockOut);

                    model.addRow(new Object[]{
                            row[3],
                            clockIn,
                            clockOut,
                            hours
                    });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void downloadTimeCardReport() {

        try {
            String employeeNumber =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            String selectedMonthYear =
                    (String) cmbSelectMonthYear.getSelectedItem();

            String selectedCutoff =
                    (String) cmbChoosePayPeriod.getSelectedItem();

            if (selectedMonthYear == null || selectedCutoff == null) {
                JOptionPane.showMessageDialog(this, "Please select a pay period first.");
                return;
            }

            LocalDate[] range =
                    CutoffDateUtils.getCutoffDateRange(selectedMonthYear, selectedCutoff);

            if (range == null) {
                JOptionPane.showMessageDialog(this, "Invalid pay period selected.");
                return;
            }

            List<String[]> attendanceRows =
                    attendanceService.getAttendanceByEmployee(
                            employeeNumber,
                            range[0],
                            range[1]
                    );

            if (attendanceRows.isEmpty()) {
                JOptionPane.showMessageDialog(
                        this,
                        "No attendance records found for the selected pay period."
                );
                return;
            }

            EmployeeDetailsEntity employee =
                    employeeService.getEmployeeEntityByNumber(employeeNumber);

            if (employee == null || employee.getEmployee() == null) {
                JOptionPane.showMessageDialog(this, "Employee record not found.");
                return;
            }

            String outputPath =
                    promptForTimeCardLocation(employeeNumber, selectedMonthYear, selectedCutoff);

            if (outputPath == null) {
                return;
            }

            JasperTimeCardExporter.exportTimeCard(
                    employeeNumber,
                    safe(employee.getFirstName()) + " " + safe(employee.getLastName()),
                    employee.getEmployee().getPosition() != null
                            ? safe(employee.getEmployee().getPosition().getPositionName())
                            : "",
                    employee.getEmployee().getDepartment() != null
                            ? safe(employee.getEmployee().getDepartment().getDepartmentName())
                            : "",
                    selectedMonthYear + " " + selectedCutoff,
                    range[0].format(DateTimeFormatter.ofPattern("MMMM d, yyyy")),
                    range[1].format(DateTimeFormatter.ofPattern("MMMM d, yyyy")),
                    attendanceRows,
                    outputPath
            );

            JOptionPane.showMessageDialog(
                    this,
                    "Employee time card report saved successfully:\n" + outputPath
            );

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error generating time card report: " + e.getMessage(),
                    "Report Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private String promptForTimeCardLocation(
            String employeeNumber,
            String selectedMonthYear,
            String selectedCutoff) {

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Employee Time Card PDF");

        String filename = "TimeCard_"
                + employeeNumber
                + "_"
                + selectedMonthYear.replaceAll("[^a-zA-Z0-9-_]", "_")
                + "_"
                + selectedCutoff.replaceAll("[^a-zA-Z0-9-_]", "_")
                + ".pdf";

        fileChooser.setSelectedFile(
                new File(System.getProperty("user.home") + "/Downloads/" + filename)
        );
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents", "pdf"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection != JFileChooser.APPROVE_OPTION) {
            return null;
        }

        String path = fileChooser.getSelectedFile().getAbsolutePath();

        return path.toLowerCase().endsWith(".pdf") ? path : path + ".pdf";
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlTimesheet = new javax.swing.JPanel();
        pnlTimesheetHeader = new javax.swing.JPanel();
        lblTimesheetLogo = new javax.swing.JLabel();
        scrollPaneTimesheet = new javax.swing.JScrollPane();
        pnlTimesheetBody = new javax.swing.JPanel();
        lblChoosePayPeriod = new javax.swing.JLabel();
        cmbChoosePayPeriod = new javax.swing.JComboBox<>();
        scrlPaneTimeSheet = new javax.swing.JScrollPane();
        tblTimesheet = new javax.swing.JTable();
        lblSelectYear = new javax.swing.JLabel();
        cmbSelectMonthYear = new javax.swing.JComboBox<>();
        btnDownloadTimeCard = new javax.swing.JButton();
        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlTimesheet.setBackground(new java.awt.Color(238, 238, 238));

        pnlTimesheetHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlTimesheetHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblTimesheetLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblTimesheetLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheetLogo.setText("Timesheet");

        javax.swing.GroupLayout pnlTimesheetHeaderLayout = new javax.swing.GroupLayout(pnlTimesheetHeader);
        pnlTimesheetHeader.setLayout(pnlTimesheetHeaderLayout);
        pnlTimesheetHeaderLayout.setHorizontalGroup(
            pnlTimesheetHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTimesheetHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblTimesheetLogo)
                .addContainerGap(681, Short.MAX_VALUE))
        );
        pnlTimesheetHeaderLayout.setVerticalGroup(
            pnlTimesheetHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTimesheetHeaderLayout.createSequentialGroup()
                .addContainerGap(91, Short.MAX_VALUE)
                .addComponent(lblTimesheetLogo)
                .addGap(22, 22, 22))
        );

        scrollPaneTimesheet.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneTimesheet.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnlTimesheetBody.setMaximumSize(null);

        lblChoosePayPeriod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChoosePayPeriod.setText("Choose Pay Period:");

        cmbChoosePayPeriod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        tblTimesheet.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 153), 1, true));
        tblTimesheet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Date", "Clock In", "Clock Out", "Total Hours"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTimesheet.setGridColor(new java.awt.Color(255, 204, 153));
        tblTimesheet.getTableHeader().setReorderingAllowed(false);
        scrlPaneTimeSheet.setViewportView(tblTimesheet);
        if (tblTimesheet.getColumnModel().getColumnCount() > 0) {
            tblTimesheet.getColumnModel().getColumn(0).setResizable(false);
            tblTimesheet.getColumnModel().getColumn(0).setPreferredWidth(30);
            tblTimesheet.getColumnModel().getColumn(1).setResizable(false);
            tblTimesheet.getColumnModel().getColumn(1).setPreferredWidth(30);
            tblTimesheet.getColumnModel().getColumn(2).setResizable(false);
            tblTimesheet.getColumnModel().getColumn(2).setPreferredWidth(30);
            tblTimesheet.getColumnModel().getColumn(3).setResizable(false);
            tblTimesheet.getColumnModel().getColumn(3).setPreferredWidth(30);
        }

        javax.swing.GroupLayout pnlTimesheetBodyLayout = new javax.swing.GroupLayout(pnlTimesheetBody);
        pnlTimesheetBody.setLayout(pnlTimesheetBodyLayout);
        pnlTimesheetBodyLayout.setHorizontalGroup(
            pnlTimesheetBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimesheetBodyLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(scrlPaneTimeSheet, javax.swing.GroupLayout.PREFERRED_SIZE, 821, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(pnlTimesheetBodyLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(lblSelectYear)
                .addGap(10, 10, 10)
                .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(lblChoosePayPeriod)
                .addGap(10, 10, 10)
                .addComponent(cmbChoosePayPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(btnDownloadTimeCard, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );
        pnlTimesheetBodyLayout.setVerticalGroup(
            pnlTimesheetBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimesheetBodyLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(pnlTimesheetBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectYear)
                    .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbChoosePayPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblChoosePayPeriod)
                    .addComponent(btnDownloadTimeCard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(scrlPaneTimeSheet, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        scrollPaneTimesheet.setViewportView(pnlTimesheetBody);

        lblSelectYear.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblSelectYear.setText("Select Month & Year:");

        cmbSelectMonthYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnDownloadTimeCard.setBackground(new java.awt.Color(101, 148, 177));
        btnDownloadTimeCard.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDownloadTimeCard.setForeground(new java.awt.Color(255, 255, 255));
        btnDownloadTimeCard.setText("Download Time Card");

        javax.swing.GroupLayout pnlTimesheetLayout = new javax.swing.GroupLayout(pnlTimesheet);
        pnlTimesheet.setLayout(pnlTimesheetLayout);
        pnlTimesheetLayout.setHorizontalGroup(
            pnlTimesheetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimesheetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlTimesheetLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(pnlTimesheetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(pnlTimesheetHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 895, Short.MAX_VALUE)
                        .addComponent(scrollPaneTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, 895, Short.MAX_VALUE))
                    .addContainerGap(26, Short.MAX_VALUE)))
        );
        pnlTimesheetLayout.setVerticalGroup(
            pnlTimesheetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimesheetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlTimesheetLayout.createSequentialGroup()
                    .addComponent(pnlTimesheetHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(scrollPaneTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Timesheet().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDownloadTimeCard;
    private javax.swing.JComboBox<String> cmbChoosePayPeriod;
    private javax.swing.JComboBox<String> cmbSelectMonthYear;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblChoosePayPeriod;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblSelectYear;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblTimesheetLogo;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlTimesheet;
    private javax.swing.JPanel pnlTimesheetBody;
    private javax.swing.JPanel pnlTimesheetHeader;
    private javax.swing.JScrollPane scrlPaneTimeSheet;
    private javax.swing.JScrollPane scrollPaneTimesheet;
    private javax.swing.JTable tblTimesheet;
    // End of variables declaration//GEN-END:variables
}
