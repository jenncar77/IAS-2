package ui;

import java.awt.Component;
import java.awt.FlowLayout;
import java.io.IOException;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import service.LoginService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import javax.swing.table.DefaultTableModel;

/**
 * Displays the user management screen for credential and role maintenance.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class UserManagement extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(UserManagement.class.getName());

    public UserManagement() {
        initComponents();

        // LOAD USERS INTO TABLE
        loadUsers();

        tblUserManagement.setRowHeight(50);
        tblUserManagement.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblUserManagement.setFillsViewportHeight(true);

        scrlPaneUserManagement.setPreferredSize(new java.awt.Dimension(900, 420));

        // Center column headers
        ((javax.swing.table.DefaultTableCellRenderer)
                tblUserManagement.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        // Center table cell contents
        javax.swing.table.DefaultTableCellRenderer centerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        tblUserManagement.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblUserManagement.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tblUserManagement.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tblUserManagement.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        tblUserManagement.getColumnModel().getColumn(0).setPreferredWidth(100); // Employee No.
        tblUserManagement.getColumnModel().getColumn(1).setPreferredWidth(200); // Email
        tblUserManagement.getColumnModel().getColumn(2).setPreferredWidth(150); // Permission
        tblUserManagement.getColumnModel().getColumn(3).setPreferredWidth(100); // Status
        tblUserManagement.getColumnModel().getColumn(4).setPreferredWidth(250); // Action

        lblUserManagement.setEnabled(false);

        WindowUtils.applyStandardWindowConfig(this, "User Management");

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(MainDashboard.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(UserManagement.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

        // Open logout confirmation ONLY (no logout yet)
        LogOutFrame.showLogoutFrame(this);
        });
    }

    // ================= LOAD USERS =================

    private void loadUsers() {

        try {

            String[][] users = LoginService.getInstance().getAllUsers();

            DefaultTableModel model =
                    (DefaultTableModel) tblUserManagement.getModel();

            model.setRowCount(0);

            int totalUsers = 0;
            int activeUsers = 0;
            int lockedUsers = 0;

            for (int i = 1; i < users.length; i++) {
                totalUsers++;

                String empNo = users[i][0];
                String email = users[i][1];
                String permission = users[i][3];
                String status = users[i][4];

                if ("Active".equalsIgnoreCase(status)) {
                    activeUsers++;
                }

                if ("Locked".equalsIgnoreCase(status)) {
                    lockedUsers++;
                }

                model.addRow(new Object[]{
                        empNo,
                        email,
                        permission,
                        status,
                        "Action"
                });
            }

            txtfldTotalUsers.setText(String.valueOf(totalUsers));
            txtfldActiveUsers.setText(String.valueOf(activeUsers));
            txtfldLockedUsers.setText(String.valueOf(lockedUsers));

            applyActionButtons();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= BUTTONS =================

    private void applyActionButtons() {

        tblUserManagement.getColumn("Action")
                .setCellRenderer(new ActionButtonRenderer());

        tblUserManagement.getColumn("Action")
                .setCellEditor(new ActionButtonEditor(new JCheckBox()));
    }

    class ActionButtonRenderer extends JPanel
            implements javax.swing.table.TableCellRenderer {

        JButton editBtn = new JButton("Edit Permission");
        JButton resetBtn = new JButton("Reset Password");

        public ActionButtonRenderer() {

            setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));

            add(editBtn);
            add(resetBtn);
        }

        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            return this;
        }
    }

    class ActionButtonEditor extends DefaultCellEditor {

        JPanel panel = new JPanel();
        JButton editBtn = new JButton("Edit Permission");
        JButton resetBtn = new JButton("Reset Password");

        int selectedRow;

        public ActionButtonEditor(JCheckBox checkBox) {

            super(checkBox);

            panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));

            panel.add(editBtn);
            panel.add(resetBtn);

            editBtn.addActionListener(e -> editPermission());
            resetBtn.addActionListener(e -> resetPassword());
        }

        public Component getTableCellEditorComponent(
                JTable table, Object value, boolean isSelected,
                int row, int column) {

            selectedRow = row;
            return panel;
        }

        public Object getCellEditorValue() {
            return "Action";
        }

        private void editPermission() {
            String empNo = tblUserManagement.getValueAt(selectedRow, 0).toString();
            String currentPermission = tblUserManagement.getValueAt(selectedRow, 2).toString();

            String newPermission = (String) JOptionPane.showInputDialog(
                    null,
                    "Select the new permission.",
                    "Edit Permission",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    LoginService.getSupportedPermissions(),
                    currentPermission
            );

            if (newPermission == null) {
                fireEditingStopped();
                return;
            }

            try {
                LoginService.getInstance().updateUserPermission(empNo, newPermission);
                loadUsers();
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(
                        null,
                        ex.getMessage(),
                        "Invalid Permission",
                        JOptionPane.ERROR_MESSAGE
                );
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        null,
                        "Failed to update permission: " + ex.getMessage(),
                        "System Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

            fireEditingStopped();
        }

        private void resetPassword() {
            String empNo = tblUserManagement.getValueAt(selectedRow, 0).toString();

            int confirm = JOptionPane.showConfirmDialog(
                    null,
                    "Reset password to default 'password123'?",
                    "Confirm Reset",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm != JOptionPane.YES_OPTION) {
                fireEditingStopped();
                return;
            }

            try {
                LoginService.getInstance().resetPasswordToDefault(empNo);
                JOptionPane.showMessageDialog(null, "Password reset successful");
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            fireEditingStopped();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMyPayslip = new javax.swing.JPanel();
        pnlMyPayslipHeader = new javax.swing.JPanel();
        lblUserManagementLogo = new javax.swing.JLabel();
        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlUserManagementDashboard = new javax.swing.JPanel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        lblTotalUsers = new javax.swing.JLabel();
        lblActiveUsers = new javax.swing.JLabel();
        lblLockedUsers = new javax.swing.JLabel();
        txtfldLockedUsers = new javax.swing.JTextField();
        txtfldTotalUsers = new javax.swing.JTextField();
        txtfldActiveUsers = new javax.swing.JTextField();
        scrlPaneUserManagement = new javax.swing.JScrollPane();
        tblUserManagement = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMyPayslip.setBackground(new java.awt.Color(238, 238, 238));

        pnlMyPayslipHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlMyPayslipHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblUserManagementLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblUserManagementLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagementLogo.setText("User Management");

        javax.swing.GroupLayout pnlMyPayslipHeaderLayout = new javax.swing.GroupLayout(pnlMyPayslipHeader);
        pnlMyPayslipHeader.setLayout(pnlMyPayslipHeaderLayout);
        pnlMyPayslipHeaderLayout.setHorizontalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblUserManagementLogo)
                .addContainerGap(567, Short.MAX_VALUE))
        );
        pnlMyPayslipHeaderLayout.setVerticalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblUserManagementLogo)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout pnlMyPayslipLayout = new javax.swing.GroupLayout(pnlMyPayslip);
        pnlMyPayslip.setLayout(pnlMyPayslipLayout);
        pnlMyPayslipLayout.setHorizontalGroup(
            pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlMyPayslipLayout.setVerticalGroup(
            pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
        );

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        pnlUserManagementDashboard.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserManagementDashboard.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator4.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator5.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblTotalUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblTotalUsers.setText("Total Users");

        lblActiveUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblActiveUsers.setText("Active Users");

        lblLockedUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblLockedUsers.setText("Locked Users");

        txtfldLockedUsers.setEditable(false);
        txtfldLockedUsers.setBackground(new java.awt.Color(255, 255, 255));
        txtfldLockedUsers.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldLockedUsers.setForeground(new java.awt.Color(33, 60, 81));
        txtfldLockedUsers.setAutoscrolls(false);
        txtfldLockedUsers.setBorder(null);
        txtfldLockedUsers.setFocusable(false);
        txtfldLockedUsers.setRequestFocusEnabled(false);
        txtfldLockedUsers.setVerifyInputWhenFocusTarget(false);

        txtfldTotalUsers.setEditable(false);
        txtfldTotalUsers.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTotalUsers.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldTotalUsers.setForeground(new java.awt.Color(33, 60, 81));
        txtfldTotalUsers.setAutoscrolls(false);
        txtfldTotalUsers.setBorder(null);
        txtfldTotalUsers.setFocusable(false);
        txtfldTotalUsers.setRequestFocusEnabled(false);
        txtfldTotalUsers.setVerifyInputWhenFocusTarget(false);

        txtfldActiveUsers.setEditable(false);
        txtfldActiveUsers.setBackground(new java.awt.Color(255, 255, 255));
        txtfldActiveUsers.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldActiveUsers.setForeground(new java.awt.Color(33, 60, 81));
        txtfldActiveUsers.setAutoscrolls(false);
        txtfldActiveUsers.setBorder(null);
        txtfldActiveUsers.setFocusable(false);
        txtfldActiveUsers.setRequestFocusEnabled(false);
        txtfldActiveUsers.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlUserManagementDashboardLayout = new javax.swing.GroupLayout(pnlUserManagementDashboard);
        pnlUserManagementDashboard.setLayout(pnlUserManagementDashboardLayout);
        pnlUserManagementDashboardLayout.setHorizontalGroup(
            pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotalUsers)
                    .addComponent(txtfldTotalUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(135, 135, 135)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblActiveUsers)
                    .addComponent(txtfldActiveUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(137, 137, 137)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLockedUsers)
                    .addComponent(txtfldLockedUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlUserManagementDashboardLayout.setVerticalGroup(
            pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblLockedUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldLockedUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblTotalUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldTotalUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblActiveUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldActiveUsers, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblUserManagement.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 153), 1, true));
        tblUserManagement.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Employee No.", "Email", "Permission", "Status", "Action"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                true, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblUserManagement.setGridColor(new java.awt.Color(255, 204, 153));
        tblUserManagement.getTableHeader().setReorderingAllowed(false);
        scrlPaneUserManagement.setViewportView(tblUserManagement);
        if (tblUserManagement.getColumnModel().getColumnCount() > 0) {
            tblUserManagement.getColumnModel().getColumn(0).setResizable(false);
            tblUserManagement.getColumnModel().getColumn(1).setResizable(false);
            tblUserManagement.getColumnModel().getColumn(2).setResizable(false);
            tblUserManagement.getColumnModel().getColumn(3).setResizable(false);
            tblUserManagement.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(scrlPaneUserManagement, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pnlUserManagementDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(pnlUserManagementDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(scrlPaneUserManagement, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new UserManagement().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel lblActiveUsers;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLockedUsers;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblTotalUsers;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JLabel lblUserManagementLogo;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlMyPayslip;
    private javax.swing.JPanel pnlMyPayslipHeader;
    private javax.swing.JPanel pnlUserManagementDashboard;
    private javax.swing.JScrollPane scrlPaneUserManagement;
    private javax.swing.JTable tblUserManagement;
    private javax.swing.JTextField txtfldActiveUsers;
    private javax.swing.JTextField txtfldLockedUsers;
    private javax.swing.JTextField txtfldTotalUsers;
    // End of variables declaration//GEN-END:variables
}
