/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import entity.LeaveTypeEntity;
import service.LoginService;
import service.LeaveService;
import model.LeaveRequest;
import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import utils.WindowUtils;


/**
 *
 * @author Mary
 */
public class LeaveRequestForm extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(LeaveRequestForm.class.getName());

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    private final LeaveService leaveService =
            new LeaveService();

    public LeaveRequestForm() {
        initComponents();

        WindowUtils.applyStandardWindowConfig(this, "New Leave Request Form");
        setLocationRelativeTo(null);

        txtfldLeaveID.setText("Auto Generated");
        txtfldLeaveID.setEditable(false);

        txtfldDurationDays.setHorizontalAlignment(JTextField.CENTER);
        
        jDateChooserStartDate.setDateFormatString("MM/dd/yyyy");
        jDateChooserEndDate.setDateFormatString("MM/dd/yyyy");

        jDateChooserStartDate.addPropertyChangeListener(
                "date",
                evt -> calculateDuration()
        );

        jDateChooserEndDate.addPropertyChangeListener(
                "date",
                evt -> calculateDuration()
        );

        btnSubmit.addActionListener(e -> submitLeaveRequest());
        btnCancel.addActionListener(e -> cancelRequest());

        loadLeaveTypes();
    }

    private void loadLeaveTypes() {
        try {
            cmbLeaveType.removeAllItems();

            for (LeaveTypeEntity leaveType : leaveService.getAllLeaveTypes()) {
                cmbLeaveType.addItem(leaveType.getLeaveTypeName());
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load leave types:\n" + e.getMessage()
            );
        }
    }

   private int calculateDuration() {
        try {
            if (jDateChooserStartDate.getDate() == null
                    || jDateChooserEndDate.getDate() == null) {
                txtfldDurationDays.setText("");
                return -1;
            }

            LocalDate start =
                    jDateChooserStartDate.getDate()
                            .toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

            LocalDate end =
                    jDateChooserEndDate.getDate()
                            .toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

            LocalDate today = LocalDate.now();

            if (!start.isAfter(today)) {
                JOptionPane.showMessageDialog(
                        this,
                        "Start Date must be later than today."
                );
                txtfldDurationDays.setText("");
                return -1;
            }

            if (end.isBefore(start)) {
                JOptionPane.showMessageDialog(
                        this,
                        "End Date cannot be earlier than Start Date."
                );
                txtfldDurationDays.setText("");
                return -1;
            }

            int workingDays = leaveService.calculateLeaveDays(start, end);
            txtfldDurationDays.setText(String.valueOf(workingDays));

            return workingDays;

        } catch (Exception e) {
            txtfldDurationDays.setText("");
            return -1;
        }
    }

    private void submitLeaveRequest() {
        try {
            int duration = calculateDuration();

            if (duration <= 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Please enter valid Start and End dates."
                );
                return;
            }

            if (cmbLeaveType.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Please select a leave type."
                );
                return;
            }

            String leaveID = txtfldLeaveID.getText();

            String employeeNo =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            LocalDate start =
                    jDateChooserStartDate.getDate()
                            .toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

            LocalDate end =
                    jDateChooserEndDate.getDate()
                            .toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

            LeaveRequest leave = new LeaveRequest(
                leaveID,
                employeeNo,
                start,
                end,
                cmbLeaveType.getSelectedItem().toString()
        );

            leaveService.fileLeave(leave);

            JOptionPane.showMessageDialog(
                    this,
                    "Leave request submitted successfully."
            );

            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error submitting leave request:\n" + e.getMessage()
            );
        }
    }

    private void cancelRequest() {
        dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMyPayslipHeader1 = new javax.swing.JPanel();
        lblAddEmployeeLogo1 = new javax.swing.JLabel();
        lblQuickActions = new javax.swing.JLabel();
        btnSubmit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        txtfldDurationDays = new javax.swing.JTextField();
        lblEndDate = new javax.swing.JLabel();
        lblAsterisk3 = new javax.swing.JLabel();
        lblAsterisk2 = new javax.swing.JLabel();
        lblDuration = new javax.swing.JLabel();
        lblAsterisk1 = new javax.swing.JLabel();
        txtfldLeaveID = new javax.swing.JTextField();
        lblStartDate = new javax.swing.JLabel();
        lblLeaveID = new javax.swing.JLabel();
        cmbLeaveType = new javax.swing.JComboBox<>();
        lblDuration1 = new javax.swing.JLabel();
        lblAsterisk4 = new javax.swing.JLabel();
        jDateChooserStartDate = new com.toedter.calendar.JDateChooser();
        jDateChooserEndDate = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMyPayslipHeader1.setBackground(new java.awt.Color(33, 60, 81));

        lblAddEmployeeLogo1.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblAddEmployeeLogo1.setForeground(new java.awt.Color(255, 255, 255));
        lblAddEmployeeLogo1.setText("New Leave Request");

        javax.swing.GroupLayout pnlMyPayslipHeader1Layout = new javax.swing.GroupLayout(pnlMyPayslipHeader1);
        pnlMyPayslipHeader1.setLayout(pnlMyPayslipHeader1Layout);
        pnlMyPayslipHeader1Layout.setHorizontalGroup(
            pnlMyPayslipHeader1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeader1Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblAddEmployeeLogo1)
                .addContainerGap(161, Short.MAX_VALUE))
        );
        pnlMyPayslipHeader1Layout.setVerticalGroup(
            pnlMyPayslipHeader1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeader1Layout.createSequentialGroup()
                .addContainerGap(82, Short.MAX_VALUE)
                .addComponent(lblAddEmployeeLogo1)
                .addGap(22, 22, 22))
        );

        lblQuickActions.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblQuickActions.setText("Quick Actions");

        btnSubmit.setBackground(new java.awt.Color(0, 102, 0));
        btnSubmit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSubmit.setForeground(new java.awt.Color(255, 255, 255));
        btnSubmit.setText("Submit");

        btnCancel.setBackground(new java.awt.Color(153, 0, 0));
        btnCancel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("Cancel");

        txtfldDurationDays.setEditable(false);
        txtfldDurationDays.setBackground(new java.awt.Color(204, 204, 204));
        txtfldDurationDays.setEnabled(false);
        txtfldDurationDays.setFocusable(false);

        lblEndDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEndDate.setText("End Date");

        lblAsterisk3.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk3.setText("*");

        lblAsterisk2.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk2.setText("*");

        lblDuration.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDuration.setText("Duration (Days)");

        lblAsterisk1.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk1.setText("*");

        txtfldLeaveID.setBackground(new java.awt.Color(204, 204, 204));

        lblStartDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStartDate.setText("Start Date");

        lblLeaveID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLeaveID.setText("Leave ID");

        cmbLeaveType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblDuration1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDuration1.setText("Leave Type");

        lblAsterisk4.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk4.setText("*");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMyPayslipHeader1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblStartDate)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblLeaveID)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblEndDate)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblDuration)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblDuration1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtfldDurationDays, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbLeaveType, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jDateChooserStartDate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtfldLeaveID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                                .addComponent(jDateChooserEndDate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblQuickActions))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMyPayslipHeader1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblQuickActions)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubmit)
                    .addComponent(btnCancel))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLeaveID)
                    .addComponent(txtfldLeaveID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblStartDate)
                        .addComponent(lblAsterisk1))
                    .addComponent(jDateChooserStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEndDate)
                            .addComponent(lblAsterisk2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDuration)
                            .addComponent(txtfldDurationDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbLeaveType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDuration1)
                            .addComponent(lblAsterisk4)))
                    .addComponent(jDateChooserEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 28, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LeaveRequestForm().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JComboBox<String> cmbLeaveType;
    private com.toedter.calendar.JDateChooser jDateChooserEndDate;
    private com.toedter.calendar.JDateChooser jDateChooserStartDate;
    private javax.swing.JLabel lblAddEmployeeLogo1;
    private javax.swing.JLabel lblAsterisk1;
    private javax.swing.JLabel lblAsterisk2;
    private javax.swing.JLabel lblAsterisk3;
    private javax.swing.JLabel lblAsterisk4;
    private javax.swing.JLabel lblDuration;
    private javax.swing.JLabel lblDuration1;
    private javax.swing.JLabel lblEndDate;
    private javax.swing.JLabel lblLeaveID;
    private javax.swing.JLabel lblQuickActions;
    private javax.swing.JLabel lblStartDate;
    private javax.swing.JPanel pnlMyPayslipHeader1;
    private javax.swing.JTextField txtfldDurationDays;
    private javax.swing.JTextField txtfldLeaveID;
    // End of variables declaration//GEN-END:variables
}
