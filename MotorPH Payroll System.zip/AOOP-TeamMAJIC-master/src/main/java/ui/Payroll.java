package ui;

import java.io.IOException;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import service.LoginService;
import service.EmployeeService;
import service.PayrollService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import entity.PayrollEntity;
import java.math.BigDecimal;
import javax.swing.JOptionPane;
import static utils.CutoffDateUtils.getDayWithSuffix;
import utils.JasperPayrollReportExporter;

/**
 * Displays the payroll dashboard and summary screen.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class Payroll extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(Payroll.class.getName());

    private final PayrollService payrollService =
        new PayrollService();

    private final EmployeeService employeeService =
            new EmployeeService();

    private BigDecimal safe(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    public Payroll() {
        initComponents();

        lblPayroll.setEnabled(false);

        WindowUtils.applyStandardWindowConfig(this, "Payroll");

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        setupNavigation();

        initializeFilters();

        cmbSelectMonthYear.addActionListener(e -> {
            String selectedMonth =
                    (String) cmbSelectMonthYear.getSelectedItem();

            if (selectedMonth != null) {
                updateCutoffDropdown(selectedMonth);
                loadPayrollDashboard();
            }
        });

        cmbChooseAPayslip.addActionListener(e -> loadPayrollDashboard());

        loadPayrollDashboard();
    }

    private void initializeFilters() {
        try {
            List<String> months =
                    payrollService.getAvailablePayrollMonths();

            cmbSelectMonthYear.removeAllItems();

            for (String month : months) {
                cmbSelectMonthYear.addItem(month);
            }

            if (!months.isEmpty()) {
                String latestMonth = months.get(months.size() - 1);
                cmbSelectMonthYear.setSelectedItem(latestMonth);
                updateCutoffDropdown(latestMonth);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateCutoffDropdown(String selectedMonth) {
        try {
            cmbChooseAPayslip.removeAllItems();

            List<Integer> cutoffs =
                    payrollService.getCutoffsForMonth(selectedMonth);

            if (cutoffs == null || cutoffs.isEmpty()) {
                return;
            }

            String[] parts = selectedMonth.split(" ");
            String monthName = parts[0];
            int year = Integer.parseInt(parts[1]);

            java.time.Month month =
                    java.time.Month.valueOf(monthName.toUpperCase());

            int lastDay = month.length(java.time.Year.isLeap(year));

            if (cutoffs.contains(15)) {
                cmbChooseAPayslip.addItem("1st-15th");
            }

            if (cutoffs.contains(lastDay)
                    || cutoffs.contains(30)
                    || cutoffs.contains(31)) {
                cmbChooseAPayslip.addItem(
                        "16th-" + lastDay + getDayWithSuffix(lastDay)
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadPayrollDashboard() {
        try {
            String monthYear =
                    (String) cmbSelectMonthYear.getSelectedItem();

            String cutoff =
                    (String) cmbChooseAPayslip.getSelectedItem();

            if (monthYear == null || cutoff == null) {
                return;
            }

            List<PayrollEntity> payrolls =
                    payrollService.getPayrollBySelectedPeriod(
                            monthYear,
                            cutoff
                    );

            DefaultTableModel model =
                    (DefaultTableModel) tblPayroll.getModel();

            model.setRowCount(0);

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDeductions = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            for (PayrollEntity payroll : payrolls) {
                String empNo = "";
                String lastName = "";
                String firstName = "";

                if (payroll.getEmployee() != null) {
                    empNo = String.valueOf(
                            payroll.getEmployee().getEmployeeNumber()
                    );
                }

                try {
                    entity.EmployeeDetailsEntity details =
                            employeeService.getEmployeeEntityByNumber(empNo);

                    if (details != null) {
                        lastName = safe(details.getLastName());
                        firstName = safe(details.getFirstName());
                    }

                } catch (Exception ex) {
                    lastName = "";
                    firstName = "";
                }

                BigDecimal grossPay = safe(payroll.getGrossPay());
                BigDecimal deductions = safe(payroll.getTotalDeductions());
                BigDecimal netPay = safe(payroll.getNetPay());

                model.addRow(new Object[]{
                    empNo,
                    lastName,
                    firstName,
                    utils.NumberFormattingUtils.formatCurrency(grossPay.doubleValue()),
                    utils.NumberFormattingUtils.formatCurrency(deductions.doubleValue()),
                    utils.NumberFormattingUtils.formatCurrency(netPay.doubleValue())
                });

                totalGross = totalGross.add(grossPay);
                totalDeductions = totalDeductions.add(deductions);
                totalNet = totalNet.add(netPay);
            }

            txtfldTotalGrossPay.setText(
                    utils.NumberFormattingUtils.formatCurrency(totalGross.doubleValue())
            );

            txtfldDeductions.setText(
                    utils.NumberFormattingUtils.formatCurrency(totalDeductions.doubleValue())
            );

            txtfldTotalNetPay.setText(
                    utils.NumberFormattingUtils.formatCurrency(totalNet.doubleValue())
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupNavigation() {
        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(MainDashboard.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(Payroll.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {
            LogOutFrame.showLogoutFrame(this);
        });
                
    }   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlPayroll = new javax.swing.JPanel();
        pnlPayrollHeader = new javax.swing.JPanel();
        lblPayrollLogo = new javax.swing.JLabel();
        pnlUserManagementDashboard = new javax.swing.JPanel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        lblTotalUsers = new javax.swing.JLabel();
        lblActiveUsers = new javax.swing.JLabel();
        lblLockedUsers = new javax.swing.JLabel();
        txtfldTotalNetPay = new javax.swing.JTextField();
        txtfldTotalGrossPay = new javax.swing.JTextField();
        txtfldDeductions = new javax.swing.JTextField();
        lblPayPeriod = new javax.swing.JLabel();
        lblAsterisk = new javax.swing.JLabel();
        lblSelectYear = new javax.swing.JLabel();
        cmbSelectMonthYear = new javax.swing.JComboBox<>();
        lblChooseAPayslip = new javax.swing.JLabel();
        cmbChooseAPayslip = new javax.swing.JComboBox<>();
        scrlPaneLeaveRequest = new javax.swing.JScrollPane();
        tblPayroll = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlPayroll.setBackground(new java.awt.Color(238, 238, 238));

        pnlPayrollHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlPayrollHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblPayrollLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblPayrollLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblPayrollLogo.setText("Payroll");

        javax.swing.GroupLayout pnlPayrollHeaderLayout = new javax.swing.GroupLayout(pnlPayrollHeader);
        pnlPayrollHeader.setLayout(pnlPayrollHeaderLayout);
        pnlPayrollHeaderLayout.setHorizontalGroup(
            pnlPayrollHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPayrollHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblPayrollLogo)
                .addContainerGap(731, Short.MAX_VALUE))
        );
        pnlPayrollHeaderLayout.setVerticalGroup(
            pnlPayrollHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPayrollHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblPayrollLogo)
                .addGap(22, 22, 22))
        );

        pnlUserManagementDashboard.setBackground(new java.awt.Color(255, 255, 255));
        pnlUserManagementDashboard.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator4.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator5.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblTotalUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblTotalUsers.setText("Total Gross Pay");

        lblActiveUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblActiveUsers.setText("Total Deductions");

        lblLockedUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblLockedUsers.setText("Total Net Pay");

        txtfldTotalNetPay.setEditable(false);
        txtfldTotalNetPay.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTotalNetPay.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtfldTotalNetPay.setForeground(new java.awt.Color(33, 60, 81));
        txtfldTotalNetPay.setAutoscrolls(false);
        txtfldTotalNetPay.setBorder(null);
        txtfldTotalNetPay.setFocusable(false);
        txtfldTotalNetPay.setRequestFocusEnabled(false);
        txtfldTotalNetPay.setVerifyInputWhenFocusTarget(false);

        txtfldTotalGrossPay.setEditable(false);
        txtfldTotalGrossPay.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTotalGrossPay.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtfldTotalGrossPay.setForeground(new java.awt.Color(33, 60, 81));
        txtfldTotalGrossPay.setAutoscrolls(false);
        txtfldTotalGrossPay.setBorder(null);
        txtfldTotalGrossPay.setFocusable(false);
        txtfldTotalGrossPay.setRequestFocusEnabled(false);
        txtfldTotalGrossPay.setVerifyInputWhenFocusTarget(false);

        txtfldDeductions.setEditable(false);
        txtfldDeductions.setBackground(new java.awt.Color(255, 255, 255));
        txtfldDeductions.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtfldDeductions.setForeground(new java.awt.Color(33, 60, 81));
        txtfldDeductions.setAutoscrolls(false);
        txtfldDeductions.setBorder(null);
        txtfldDeductions.setFocusable(false);
        txtfldDeductions.setRequestFocusEnabled(false);
        txtfldDeductions.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlUserManagementDashboardLayout = new javax.swing.GroupLayout(pnlUserManagementDashboard);
        pnlUserManagementDashboard.setLayout(pnlUserManagementDashboardLayout);
        pnlUserManagementDashboardLayout.setHorizontalGroup(
            pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotalUsers)
                    .addComponent(txtfldTotalGrossPay, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblActiveUsers)
                    .addComponent(txtfldDeductions, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLockedUsers)
                    .addComponent(txtfldTotalNetPay, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlUserManagementDashboardLayout.setVerticalGroup(
            pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlUserManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblLockedUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldTotalNetPay, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblTotalUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldTotalGrossPay, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlUserManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblActiveUsers)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldDeductions, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblPayPeriod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblPayPeriod.setText("Pay Period");

        lblAsterisk.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblAsterisk.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk.setText("*");

        lblSelectYear.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblSelectYear.setText("Select Month & Year");

        cmbSelectMonthYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblChooseAPayslip.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChooseAPayslip.setText("Choose a Cutoff");

        cmbChooseAPayslip.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        tblPayroll.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Employee No.", "Last Name", "First Name", "Gross Pay", "Total Deductions", "Net Pay"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrlPaneLeaveRequest.setViewportView(tblPayroll);
        if (tblPayroll.getColumnModel().getColumnCount() > 0) {
            tblPayroll.getColumnModel().getColumn(0).setResizable(false);
            tblPayroll.getColumnModel().getColumn(1).setResizable(false);
            tblPayroll.getColumnModel().getColumn(2).setResizable(false);
            tblPayroll.getColumnModel().getColumn(3).setResizable(false);
            tblPayroll.getColumnModel().getColumn(4).setResizable(false);
            tblPayroll.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout pnlPayrollLayout = new javax.swing.GroupLayout(pnlPayroll);
        pnlPayroll.setLayout(pnlPayrollLayout);
        pnlPayrollLayout.setHorizontalGroup(
            pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPayrollLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(scrlPaneLeaveRequest)
                    .addComponent(pnlUserManagementDashboard, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlPayrollLayout.createSequentialGroup()
                        .addGroup(pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlPayrollHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlPayrollLayout.createSequentialGroup()
                                .addComponent(lblPayPeriod)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnlPayrollLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(lblSelectYear)
                .addGap(18, 18, 18)
                .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblChooseAPayslip)
                .addGap(18, 18, 18)
                .addComponent(cmbChooseAPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPayrollLayout.setVerticalGroup(
            pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPayrollLayout.createSequentialGroup()
                .addComponent(pnlPayrollHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlUserManagementDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAsterisk)
                    .addComponent(lblPayPeriod))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlPayrollLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectYear)
                    .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblChooseAPayslip)
                    .addComponent(cmbChooseAPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(scrlPaneLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Payroll().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbChooseAPayslip;
    private javax.swing.JComboBox<String> cmbSelectMonthYear;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel lblActiveUsers;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblAsterisk;
    private javax.swing.JLabel lblChooseAPayslip;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLockedUsers;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayPeriod;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblPayrollLogo;
    private javax.swing.JLabel lblSelectYear;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblTotalUsers;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlPayroll;
    private javax.swing.JPanel pnlPayrollHeader;
    private javax.swing.JPanel pnlUserManagementDashboard;
    private javax.swing.JScrollPane scrlPaneLeaveRequest;
    private javax.swing.JTable tblPayroll;
    private javax.swing.JTextField txtfldDeductions;
    private javax.swing.JTextField txtfldTotalGrossPay;
    private javax.swing.JTextField txtfldTotalNetPay;
    // End of variables declaration//GEN-END:variables
}
