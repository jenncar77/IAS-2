package ui.helpers;

import javax.swing.JLabel;
import service.LoginService;

/**
 * Applies role-based access rules to shared navigation components.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class RBACController {

    /**
     * Applies role-based permissions to sidebar labels.
     *
     * Each label represents a module in the system. The visibility
     * of these labels is controlled based on the logged-in user's role.
     *
     * @param lblUserManagement label for the User Management module (IT, Admin)
     * @param lblPayroll label for the Payroll module (Finance, Admin)
     * @param lblEmployeeList label for the Employee List module (HR, Admin)
     * @param lblLeaveManagement label for the Leave Management module (HR, Admin)
     * @param lblReports label for the Reports module (Admin)
     */
    public static void applyPermissions(
            JLabel lblUserManagement,
            JLabel lblPayroll,
            JLabel lblEmployeeList,
            JLabel lblLeaveManagement,
            JLabel lblAnalytics) {

        // Retrieve the current user's role from the LoginService session
        String role = LoginService.getInstance().getPermissionLevel();

        // Hide all management modules by default
        // Only roles with permission will have these shown
        lblUserManagement.setVisible(false);
        lblPayroll.setVisible(false);
        lblEmployeeList.setVisible(false);
        lblLeaveManagement.setVisible(false);

        // Enable modules depending on the user's role
        switch (role) {

            case "IT":
                // IT staff can manage system users
                lblUserManagement.setVisible(true);
                break;

            case "Finance":
                // Finance staff can access payroll processing
                lblPayroll.setVisible(true);
                lblAnalytics.setVisible(true);
                break;

            case "HR":
                // HR staff manage employees and leave requests
                lblEmployeeList.setVisible(true);
                lblLeaveManagement.setVisible(true);
                break;

            case "Admin":
                // Admin has access to everything
                lblUserManagement.setVisible(true);
                lblPayroll.setVisible(true);
                lblEmployeeList.setVisible(true);
                lblLeaveManagement.setVisible(true);
                lblAnalytics.setVisible(true);

                break;
        }

    }

}
