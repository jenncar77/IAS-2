package ui;

import java.io.IOException;
import model.Compensation;
import model.ContactInfo;
import model.EmployeeDetails;
import model.GovernmentID;
import model.JobDetails;
import service.EmployeeService;
import service.LoginService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import entity.EmployeeDetailsEntity;
import entity.UserAccountEntity;
import repository.UserAccountRepository;

/**
 * Displays the main dashboard after a successful login.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class MainDashboard extends javax.swing.JFrame {

    /**
     * Creates new form MainDashboard
     */

    public MainDashboard() {
    initComponents();

    lblDashboard.setEnabled(false);

    // Apply standard window configuration
    WindowUtils.applyStandardWindowConfig(this, "Your Dashboard");

    // Apply Role-Based Access Control (RBAC)
    RBACController.applyPermissions(
        lblUserManagement,
        lblPayroll,
        lblEmployeeList,
        lblLeaveManagement,
        lblAnalytics
    );

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
        try {
            new DailyTimeRecord().setVisible(true);
        } catch (IOException ex) {
            System.getLogger(MainDashboard.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
        try {
            new MyPayslip().setVisible(true);
        } catch (Exception ex) {
            System.getLogger(MainDashboard.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

        // Open logout confirmation ONLY (no logout yet)
        LogOutFrame.showLogoutFrame(this);
        });
        
    // Load logged-in employee information
    loadLoggedInUser();

}

/**
 * Displays information about the currently logged-in employee.
 * Currently it shows the Employee Number in the dashboard header.
 */
private void loadLoggedInUser() {

    String empNo = LoginService.getInstance().getLoggedInEmployeeNumber();

    EmployeeService employeeService = new EmployeeService();

    try {
        EmployeeDetailsEntity emp =
                employeeService.getEmployeeEntityByNumber(empNo);

        if (emp == null) {
            return;
        }

        txtfldEmpNo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtfldEmpNo.setText("EMPLOYEE NO. " + emp.getEmployeeNumber());

        txtfldFullName.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtfldFullName.setText(emp.getFirstName() + " " + emp.getLastName());

        txtfldWelcomeMessage.setText(
                "Hey " + emp.getFirstName() + ", good to see you!"
        );

        txtfldPhoneNo.setText(emp.getPhoneNumber());

        if (emp.getBirthday() != null) {
            txtfldBirthday.setText(emp.getBirthday().toString());
        }

        if (emp.getEmployee() != null) {
            txtfldSSS.setText(emp.getEmployee().getSssNumber());
            txtfldPhilhealth.setText(emp.getEmployee().getPhilhealthNumber());
            txtfldPagibig.setText(emp.getEmployee().getPagibigNumber());
            txtfldTIN.setText(emp.getEmployee().getTinNumber());

            if (emp.getEmployee().getEmploymentStatus() != null) {
                txtfldStatus.setText(
                        emp.getEmployee()
                                .getEmploymentStatus()
                                .getEmploymentStatusName()
                );
            }

            if (emp.getEmployee().getPosition() != null) {
                txtfldPosition.setText(
                        emp.getEmployee()
                                .getPosition()
                                .getPositionName()
                );
            }
        }

        UserAccountRepository userAccountRepository =
                new UserAccountRepository();

        UserAccountEntity account =
                userAccountRepository.findByEmployeeNumber(emp.getEmployeeNumber());

        if (account != null) {
            txtfldEmail.setText(account.getUsername());
        } else {
            txtfldEmail.setText("");
        }

        if (emp.getAddress() != null) {
            txtfldAddress.setText(emp.getAddress().getFullAddress());
        } else {
            txtfldAddress.setText("");
        }

        if (emp.getEmployee() != null
                && emp.getEmployee().getImmediateSupervisor() != null
                && emp.getEmployee().getImmediateSupervisor().getEmployeeDetails() != null) {

            txtfldSupervisor.setText(
                    emp.getEmployee()
                            .getImmediateSupervisor()
                            .getEmployeeDetails()
                            .getFirstName()
                    + " "
                    + emp.getEmployee()
                            .getImmediateSupervisor()
                            .getEmployeeDetails()
                            .getLastName()
            );
        } else {
            txtfldSupervisor.setText("");
        }

    } catch (IOException ex) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Failed to load employee data from database: "
                        + ex.getMessage(),
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
}
/**
 * Improves user experience by changing the cursor to a hand pointer
 * when hovering over sidebar labels so they behave like clickable menu items.
 */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlEmpDetails = new javax.swing.JPanel();
        pnlEmployeeDetails = new javax.swing.JPanel();
        txtfldFullName = new javax.swing.JTextField();
        txtfldWelcomeMessage = new javax.swing.JTextField();
        lblDashboardLogo = new javax.swing.JLabel();
        txtfldEmpNo = new javax.swing.JTextField();
        scrollPaneFullEmpDetails = new javax.swing.JScrollPane();
        pnlFullEmpDetails = new javax.swing.JPanel();
        pnlContactInformation = new javax.swing.JPanel();
        lblContactInformation = new javax.swing.JLabel();
        lblPhoneNo = new javax.swing.JLabel();
        txtfldPhoneNo = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtfldEmail = new javax.swing.JTextField();
        lblAddress = new javax.swing.JLabel();
        lblBirthday = new javax.swing.JLabel();
        txtfldBirthday = new javax.swing.JTextField();
        txtfldAddress = new javax.swing.JTextField();
        pnlEmploymentDetails = new javax.swing.JPanel();
        lblEmploymentDetails = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        txtfldStatus = new javax.swing.JTextField();
        lblPosition = new javax.swing.JLabel();
        txtfldPosition = new javax.swing.JTextField();
        lblSupervisor = new javax.swing.JLabel();
        txtfldSupervisor = new javax.swing.JTextField();
        pnlBenefits = new javax.swing.JPanel();
        lblBenefits = new javax.swing.JLabel();
        lblSSS = new javax.swing.JLabel();
        txtfldSSS = new javax.swing.JTextField();
        lblPhilhealth = new javax.swing.JLabel();
        txtfldPhilhealth = new javax.swing.JTextField();
        txtfldTIN = new javax.swing.JTextField();
        lblTIN = new javax.swing.JLabel();
        lblPagibig = new javax.swing.JLabel();
        txtfldPagibig = new javax.swing.JTextField();
        pnlCompensationDetails = new javax.swing.JPanel();
        lblCompensationDetails = new javax.swing.JLabel();
        txtfldCompanyContactNumbers = new javax.swing.JTextField();
        txtfldCompanyEmail = new javax.swing.JTextField();
        txtfldOfficeAddress = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEmpDetails.setBackground(new java.awt.Color(238, 238, 238));

        pnlEmployeeDetails.setBackground(new java.awt.Color(33, 60, 81));
        pnlEmployeeDetails.setPreferredSize(new java.awt.Dimension(884, 142));

        txtfldFullName.setEditable(false);
        txtfldFullName.setBackground(new java.awt.Color(33, 60, 81));
        txtfldFullName.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        txtfldFullName.setForeground(new java.awt.Color(255, 255, 255));
        txtfldFullName.setBorder(null);
        txtfldFullName.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtfldFullName.setFocusable(false);
        txtfldFullName.setRequestFocusEnabled(false);
        txtfldFullName.setVerifyInputWhenFocusTarget(false);

        txtfldWelcomeMessage.setEditable(false);
        txtfldWelcomeMessage.setBackground(new java.awt.Color(33, 60, 81));
        txtfldWelcomeMessage.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txtfldWelcomeMessage.setForeground(new java.awt.Color(255, 255, 255));
        txtfldWelcomeMessage.setBorder(null);
        txtfldWelcomeMessage.setFocusable(false);
        txtfldWelcomeMessage.setRequestFocusEnabled(false);
        txtfldWelcomeMessage.setVerifyInputWhenFocusTarget(false);

        lblDashboardLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblDashboardLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboardLogo.setText("Dashboard");

        txtfldEmpNo.setEditable(false);
        txtfldEmpNo.setBackground(new java.awt.Color(33, 60, 81));
        txtfldEmpNo.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        txtfldEmpNo.setForeground(new java.awt.Color(255, 255, 255));
        txtfldEmpNo.setBorder(null);
        txtfldEmpNo.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtfldEmpNo.setFocusable(false);
        txtfldEmpNo.setRequestFocusEnabled(false);
        txtfldEmpNo.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlEmployeeDetailsLayout = new javax.swing.GroupLayout(pnlEmployeeDetails);
        pnlEmployeeDetails.setLayout(pnlEmployeeDetailsLayout);
        pnlEmployeeDetailsLayout.setHorizontalGroup(
            pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                        .addComponent(lblDashboardLogo)
                        .addContainerGap(678, Short.MAX_VALUE))
                    .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                        .addComponent(txtfldWelcomeMessage)
                        .addGap(154, 154, 154)
                        .addGroup(pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtfldFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44))))
        );
        pnlEmployeeDetailsLayout.setVerticalGroup(
            pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                .addGroup(pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(txtfldFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEmployeeDetailsLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtfldWelcomeMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)))
                .addComponent(lblDashboardLogo)
                .addGap(22, 22, 22))
        );

        scrollPaneFullEmpDetails.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneFullEmpDetails.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnlFullEmpDetails.setMaximumSize(null);

        pnlContactInformation.setBackground(new java.awt.Color(255, 255, 255));
        pnlContactInformation.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));
        pnlContactInformation.setPreferredSize(new java.awt.Dimension(887, 194));
        pnlContactInformation.setRequestFocusEnabled(false);

        lblContactInformation.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblContactInformation.setText("Contact Information");
        lblContactInformation.setAutoscrolls(true);
        lblContactInformation.setFocusable(false);
        lblContactInformation.setInheritsPopupMenu(false);
        lblContactInformation.setRequestFocusEnabled(false);
        lblContactInformation.setVerifyInputWhenFocusTarget(false);

        lblPhoneNo.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblPhoneNo.setText("Phone Number");
        lblPhoneNo.setAutoscrolls(true);
        lblPhoneNo.setFocusable(false);
        lblPhoneNo.setInheritsPopupMenu(false);
        lblPhoneNo.setRequestFocusEnabled(false);
        lblPhoneNo.setVerifyInputWhenFocusTarget(false);

        txtfldPhoneNo.setEditable(false);
        txtfldPhoneNo.setBackground(new java.awt.Color(255, 255, 255));
        txtfldPhoneNo.setBorder(null);
        txtfldPhoneNo.setDisabledTextColor(new java.awt.Color(242, 242, 242));
        txtfldPhoneNo.setFocusable(false);

        lblEmail.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblEmail.setText("Email Address");
        lblEmail.setAutoscrolls(true);
        lblEmail.setFocusable(false);
        lblEmail.setInheritsPopupMenu(false);
        lblEmail.setRequestFocusEnabled(false);
        lblEmail.setVerifyInputWhenFocusTarget(false);

        txtfldEmail.setEditable(false);
        txtfldEmail.setBackground(new java.awt.Color(255, 255, 255));
        txtfldEmail.setBorder(null);
        txtfldEmail.setFocusable(false);

        lblAddress.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblAddress.setText("Full Address");
        lblAddress.setAutoscrolls(true);
        lblAddress.setFocusable(false);
        lblAddress.setInheritsPopupMenu(false);
        lblAddress.setRequestFocusEnabled(false);
        lblAddress.setVerifyInputWhenFocusTarget(false);

        lblBirthday.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblBirthday.setText("Birthday");
        lblBirthday.setAutoscrolls(true);
        lblBirthday.setFocusable(false);
        lblBirthday.setInheritsPopupMenu(false);
        lblBirthday.setRequestFocusEnabled(false);
        lblBirthday.setVerifyInputWhenFocusTarget(false);

        txtfldBirthday.setEditable(false);
        txtfldBirthday.setBackground(new java.awt.Color(255, 255, 255));
        txtfldBirthday.setBorder(null);
        txtfldBirthday.setFocusable(false);

        txtfldAddress.setEditable(false);
        txtfldAddress.setBackground(new java.awt.Color(255, 255, 255));
        txtfldAddress.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtfldAddress.setBorder(null);
        txtfldAddress.setFocusable(false);

        javax.swing.GroupLayout pnlContactInformationLayout = new javax.swing.GroupLayout(pnlContactInformation);
        pnlContactInformation.setLayout(pnlContactInformationLayout);
        pnlContactInformationLayout.setHorizontalGroup(
            pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContactInformationLayout.createSequentialGroup()
                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlContactInformationLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblContactInformation))
                    .addGroup(pnlContactInformationLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblAddress)
                            .addGroup(pnlContactInformationLayout.createSequentialGroup()
                                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPhoneNo)
                                    .addComponent(lblEmail)
                                    .addComponent(lblBirthday))
                                .addGap(75, 75, 75)
                                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfldBirthday, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(144, Short.MAX_VALUE))
        );
        pnlContactInformationLayout.setVerticalGroup(
            pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContactInformationLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblContactInformation)
                .addGap(18, 18, 18)
                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPhoneNo)
                    .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEmail)
                    .addComponent(txtfldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAddress)
                    .addComponent(txtfldAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlContactInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBirthday)
                    .addComponent(txtfldBirthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlEmploymentDetails.setBackground(new java.awt.Color(255, 255, 255));
        pnlEmploymentDetails.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        lblEmploymentDetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblEmploymentDetails.setText("Employment Details");
        lblEmploymentDetails.setAutoscrolls(true);
        lblEmploymentDetails.setFocusable(false);
        lblEmploymentDetails.setInheritsPopupMenu(false);
        lblEmploymentDetails.setRequestFocusEnabled(false);
        lblEmploymentDetails.setVerifyInputWhenFocusTarget(false);

        lblStatus.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblStatus.setText("Status");
        lblStatus.setAutoscrolls(true);
        lblStatus.setFocusable(false);
        lblStatus.setInheritsPopupMenu(false);
        lblStatus.setRequestFocusEnabled(false);
        lblStatus.setVerifyInputWhenFocusTarget(false);

        txtfldStatus.setEditable(false);
        txtfldStatus.setBackground(new java.awt.Color(255, 255, 255));
        txtfldStatus.setBorder(null);
        txtfldStatus.setFocusable(false);

        lblPosition.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblPosition.setText("Position");
        lblPosition.setAutoscrolls(true);
        lblPosition.setFocusable(false);
        lblPosition.setInheritsPopupMenu(false);
        lblPosition.setRequestFocusEnabled(false);
        lblPosition.setVerifyInputWhenFocusTarget(false);

        txtfldPosition.setEditable(false);
        txtfldPosition.setBackground(new java.awt.Color(255, 255, 255));
        txtfldPosition.setBorder(null);
        txtfldPosition.setFocusable(false);

        lblSupervisor.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblSupervisor.setText("Immediate Supervisor");
        lblSupervisor.setAutoscrolls(true);
        lblSupervisor.setFocusable(false);
        lblSupervisor.setInheritsPopupMenu(false);
        lblSupervisor.setRequestFocusEnabled(false);
        lblSupervisor.setVerifyInputWhenFocusTarget(false);

        txtfldSupervisor.setEditable(false);
        txtfldSupervisor.setBackground(new java.awt.Color(255, 255, 255));
        txtfldSupervisor.setBorder(null);
        txtfldSupervisor.setFocusable(false);

        javax.swing.GroupLayout pnlEmploymentDetailsLayout = new javax.swing.GroupLayout(pnlEmploymentDetails);
        pnlEmploymentDetails.setLayout(pnlEmploymentDetailsLayout);
        pnlEmploymentDetailsLayout.setHorizontalGroup(
            pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmploymentDetailsLayout.createSequentialGroup()
                .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlEmploymentDetailsLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblEmploymentDetails))
                    .addGroup(pnlEmploymentDetailsLayout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPosition)
                            .addComponent(lblStatus)
                            .addComponent(lblSupervisor))
                        .addGap(54, 54, 54)
                        .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtfldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtfldPosition)
                            .addComponent(txtfldSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        pnlEmploymentDetailsLayout.setVerticalGroup(
            pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmploymentDetailsLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblEmploymentDetails)
                .addGap(18, 18, 18)
                .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblStatus)
                    .addComponent(txtfldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtfldPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPosition))
                .addGap(18, 18, 18)
                .addGroup(pnlEmploymentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSupervisor)
                    .addComponent(txtfldSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(61, Short.MAX_VALUE))
        );

        pnlBenefits.setBackground(new java.awt.Color(255, 255, 255));
        pnlBenefits.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        lblBenefits.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBenefits.setText("Benefits");
        lblBenefits.setAutoscrolls(true);
        lblBenefits.setFocusable(false);
        lblBenefits.setInheritsPopupMenu(false);
        lblBenefits.setRequestFocusEnabled(false);
        lblBenefits.setVerifyInputWhenFocusTarget(false);

        lblSSS.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblSSS.setText("SSS Number");
        lblSSS.setAutoscrolls(true);
        lblSSS.setFocusable(false);
        lblSSS.setInheritsPopupMenu(false);
        lblSSS.setRequestFocusEnabled(false);
        lblSSS.setVerifyInputWhenFocusTarget(false);

        txtfldSSS.setEditable(false);
        txtfldSSS.setBackground(new java.awt.Color(255, 255, 255));
        txtfldSSS.setBorder(null);
        txtfldSSS.setFocusable(false);

        lblPhilhealth.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblPhilhealth.setText("PhilHealth Number");
        lblPhilhealth.setAutoscrolls(true);
        lblPhilhealth.setFocusable(false);
        lblPhilhealth.setInheritsPopupMenu(false);
        lblPhilhealth.setRequestFocusEnabled(false);
        lblPhilhealth.setVerifyInputWhenFocusTarget(false);

        txtfldPhilhealth.setEditable(false);
        txtfldPhilhealth.setBackground(new java.awt.Color(255, 255, 255));
        txtfldPhilhealth.setBorder(null);
        txtfldPhilhealth.setFocusable(false);

        txtfldTIN.setEditable(false);
        txtfldTIN.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTIN.setBorder(null);
        txtfldTIN.setFocusable(false);

        lblTIN.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblTIN.setText("TIN Number");
        lblTIN.setAutoscrolls(true);
        lblTIN.setFocusable(false);
        lblTIN.setInheritsPopupMenu(false);
        lblTIN.setRequestFocusEnabled(false);
        lblTIN.setVerifyInputWhenFocusTarget(false);

        lblPagibig.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblPagibig.setText("Pag-ibig Number");
        lblPagibig.setAutoscrolls(true);
        lblPagibig.setFocusable(false);
        lblPagibig.setInheritsPopupMenu(false);
        lblPagibig.setRequestFocusEnabled(false);
        lblPagibig.setVerifyInputWhenFocusTarget(false);

        txtfldPagibig.setEditable(false);
        txtfldPagibig.setBackground(new java.awt.Color(255, 255, 255));
        txtfldPagibig.setBorder(null);
        txtfldPagibig.setFocusable(false);

        javax.swing.GroupLayout pnlBenefitsLayout = new javax.swing.GroupLayout(pnlBenefits);
        pnlBenefits.setLayout(pnlBenefitsLayout);
        pnlBenefitsLayout.setHorizontalGroup(
            pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBenefitsLayout.createSequentialGroup()
                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBenefitsLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblBenefits))
                    .addGroup(pnlBenefitsLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnlBenefitsLayout.createSequentialGroup()
                                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPhilhealth)
                                    .addComponent(lblTIN)
                                    .addComponent(lblPagibig))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldTIN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldPagibig, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(pnlBenefitsLayout.createSequentialGroup()
                                .addComponent(lblSSS)
                                .addGap(95, 95, 95)
                                .addComponent(txtfldSSS, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        pnlBenefitsLayout.setVerticalGroup(
            pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBenefitsLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblBenefits)
                .addGap(18, 18, 18)
                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSSS)
                    .addComponent(txtfldSSS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPhilhealth)
                    .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTIN)
                    .addComponent(txtfldTIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlBenefitsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPagibig)
                    .addComponent(txtfldPagibig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pnlCompensationDetails.setBackground(new java.awt.Color(255, 255, 255));
        pnlCompensationDetails.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        lblCompensationDetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCompensationDetails.setText("Company Information");
        lblCompensationDetails.setAutoscrolls(true);
        lblCompensationDetails.setFocusable(false);
        lblCompensationDetails.setInheritsPopupMenu(false);
        lblCompensationDetails.setRequestFocusEnabled(false);
        lblCompensationDetails.setVerifyInputWhenFocusTarget(false);

        txtfldCompanyContactNumbers.setEditable(false);
        txtfldCompanyContactNumbers.setBackground(new java.awt.Color(255, 255, 255));
        txtfldCompanyContactNumbers.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtfldCompanyContactNumbers.setText("Contact Numbers:       Phone: (028) 911-5071 / (028) 911-5072 / (028) 911-5073");
        txtfldCompanyContactNumbers.setBorder(null);
        txtfldCompanyContactNumbers.setFocusable(false);

        txtfldCompanyEmail.setEditable(false);
        txtfldCompanyEmail.setBackground(new java.awt.Color(255, 255, 255));
        txtfldCompanyEmail.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtfldCompanyEmail.setText("Email Address:  corporate@motorph.com");
        txtfldCompanyEmail.setBorder(null);
        txtfldCompanyEmail.setFocusable(false);

        txtfldOfficeAddress.setEditable(false);
        txtfldOfficeAddress.setBackground(new java.awt.Color(255, 255, 255));
        txtfldOfficeAddress.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtfldOfficeAddress.setText("Office Address: 7 Jupiter Avenue cor. F. Sandoval Jr., Bagong Nayon, Quezon City");
        txtfldOfficeAddress.setBorder(null);
        txtfldOfficeAddress.setFocusable(false);

        javax.swing.GroupLayout pnlCompensationDetailsLayout = new javax.swing.GroupLayout(pnlCompensationDetails);
        pnlCompensationDetails.setLayout(pnlCompensationDetailsLayout);
        pnlCompensationDetailsLayout.setHorizontalGroup(
            pnlCompensationDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCompensationDetailsLayout.createSequentialGroup()
                .addGroup(pnlCompensationDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCompensationDetailsLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(lblCompensationDetails))
                    .addGroup(pnlCompensationDetailsLayout.createSequentialGroup()
                        .addGap(278, 278, 278)
                        .addComponent(txtfldCompanyEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlCompensationDetailsLayout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addGroup(pnlCompensationDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtfldOfficeAddress)
                            .addComponent(txtfldCompanyContactNumbers))))
                .addContainerGap(248, Short.MAX_VALUE))
        );
        pnlCompensationDetailsLayout.setVerticalGroup(
            pnlCompensationDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCompensationDetailsLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblCompensationDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtfldCompanyEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtfldCompanyContactNumbers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtfldOfficeAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlFullEmpDetailsLayout = new javax.swing.GroupLayout(pnlFullEmpDetails);
        pnlFullEmpDetails.setLayout(pnlFullEmpDetailsLayout);
        pnlFullEmpDetailsLayout.setHorizontalGroup(
            pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(pnlContactInformation, javax.swing.GroupLayout.DEFAULT_SIZE, 904, Short.MAX_VALUE)
                            .addComponent(pnlCompensationDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnlBenefits, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlEmploymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 373, Short.MAX_VALUE))
        );
        pnlFullEmpDetailsLayout.setVerticalGroup(
            pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlContactInformation, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlBenefits, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlEmploymentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(pnlCompensationDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        scrollPaneFullEmpDetails.setViewportView(pnlFullEmpDetails);

        javax.swing.GroupLayout pnlEmpDetailsLayout = new javax.swing.GroupLayout(pnlEmpDetails);
        pnlEmpDetails.setLayout(pnlEmpDetailsLayout);
        pnlEmpDetailsLayout.setHorizontalGroup(
            pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEmpDetailsLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlEmployeeDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(scrollPaneFullEmpDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(26, Short.MAX_VALUE)))
        );
        pnlEmpDetailsLayout.setVerticalGroup(
            pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                .addComponent(pnlEmployeeDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(597, Short.MAX_VALUE))
            .addGroup(pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                    .addGap(175, 175, 175)
                    .addComponent(scrollPaneFullEmpDetails, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlEmpDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlEmpDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
                ex.printStackTrace();
            }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new MainDashboard().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblAddress;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblBenefits;
    private javax.swing.JLabel lblBirthday;
    private javax.swing.JLabel lblCompensationDetails;
    private javax.swing.JLabel lblContactInformation;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblDashboardLogo;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblEmploymentDetails;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPagibig;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblPhilhealth;
    private javax.swing.JLabel lblPhoneNo;
    private javax.swing.JLabel lblPosition;
    private javax.swing.JLabel lblSSS;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblSupervisor;
    private javax.swing.JLabel lblTIN;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JPanel pnlBenefits;
    private javax.swing.JPanel pnlCompensationDetails;
    private javax.swing.JPanel pnlContactInformation;
    private javax.swing.JPanel pnlEmpDetails;
    private javax.swing.JPanel pnlEmployeeDetails;
    private javax.swing.JPanel pnlEmploymentDetails;
    private javax.swing.JPanel pnlFullEmpDetails;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JScrollPane scrollPaneFullEmpDetails;
    private javax.swing.JTextField txtfldAddress;
    private javax.swing.JTextField txtfldBirthday;
    private javax.swing.JTextField txtfldCompanyContactNumbers;
    private javax.swing.JTextField txtfldCompanyEmail;
    private javax.swing.JTextField txtfldEmail;
    private javax.swing.JTextField txtfldEmpNo;
    private javax.swing.JTextField txtfldFullName;
    private javax.swing.JTextField txtfldOfficeAddress;
    private javax.swing.JTextField txtfldPagibig;
    private javax.swing.JTextField txtfldPhilhealth;
    private javax.swing.JTextField txtfldPhoneNo;
    private javax.swing.JTextField txtfldPosition;
    private javax.swing.JTextField txtfldSSS;
    private javax.swing.JTextField txtfldStatus;
    private javax.swing.JTextField txtfldSupervisor;
    private javax.swing.JTextField txtfldTIN;
    private javax.swing.JTextField txtfldWelcomeMessage;
    // End of variables declaration//GEN-END:variables
}
