/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import entity.EmployeeDetailsEntity;
import java.awt.BorderLayout;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import entity.PayrollEntity;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import service.PayrollService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import entity.DeductionEntity;
import model.Employee;
import service.EmployeeService;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.EmployeeDetails;
import model.PayrollSummary;
import utils.JasperPayrollReportExporter;

/**
 *
 * @author Mary
 */
public class Analytics extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Analytics.class.getName());
    
    private final PayrollService payrollService = new PayrollService();
    private final EmployeeService employeeService = new EmployeeService();

    /**
     * Creates new form Analytics
     */
    public Analytics() {
        initComponents();

        WindowUtils.applyStandardWindowConfig(this, "Analytics");
        this.setResizable(true);

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        
        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(Analytics.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(Analytics.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {
            LogOutFrame.showLogoutFrame(this);
        });

        btnLoadCharts.addActionListener(e -> downloadMonthlySummaryReport());

        initializeMonthFilter();
        loadCharts();
    }
    
    private void loadCharts() {
       loadGrossVsNetChart();
        loadDeductionsChart();
        loadEmployeePerPosition();
    }

    private void initializeMonthFilter() {
    try {
        List<String> months = payrollService.getAvailablePayrollMonths();

        cmbSelectMonthYear.removeAllItems();

        for (String month : months) {
            cmbSelectMonthYear.addItem(month);
        }

        if (!months.isEmpty()) {
            String latestMonth = months.get(months.size() - 1);
            cmbSelectMonthYear.setSelectedItem(latestMonth);
        }

    } catch (Exception e) {
        e.printStackTrace();

        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Unable to load payroll months: " + e.getMessage()
        );
    }
}
    
    private void loadGrossVsNetChart() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            String monthYear = cmbSelectMonthYear.getSelectedItem().toString();

            // for now, use first cutoff
            String cutoff = "1st-15th";

            List<PayrollEntity> payrolls =
                    payrollService.getPayrollBySelectedPeriod(monthYear, cutoff);

            BigDecimal totalGrossPay = BigDecimal.ZERO;
            BigDecimal totalNetPay = BigDecimal.ZERO;

            for (PayrollEntity payroll : payrolls) {
                totalGrossPay = totalGrossPay.add(
                        payroll.getGrossPay() != null ? payroll.getGrossPay() : BigDecimal.ZERO
                );

                totalNetPay = totalNetPay.add(
                        payroll.getNetPay() != null ? payroll.getNetPay() : BigDecimal.ZERO
                );
            }

            dataset.addValue(totalGrossPay, "Amount", "Gross Pay");
            dataset.addValue(totalNetPay, "Amount", "Net Pay");

        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Unable to load payroll chart: " + ex.getMessage()
            );
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Total Gross Pay vs Total Net Pay",
                "",
                "Amount",
                dataset,
                org.jfree.chart.plot.PlotOrientation.HORIZONTAL,
                false,
                true,
                false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(400, 200));
        
        pnlChartGrossPayVsNetPay.removeAll();
        pnlChartGrossPayVsNetPay.setLayout(new BorderLayout());
        pnlChartGrossPayVsNetPay.add(chartPanel, BorderLayout.CENTER);
        pnlChartGrossPayVsNetPay.revalidate();
        pnlChartGrossPayVsNetPay.repaint();
    }

    private void loadDeductionsChart() {
        DefaultPieDataset dataset = new DefaultPieDataset();

        try {
            String monthYear = cmbSelectMonthYear.getSelectedItem().toString();

            String cutoff = "1st-15th";

            List<PayrollEntity> payrolls =
                    payrollService.getPayrollBySelectedPeriod(monthYear, cutoff);

            BigDecimal totalSSS = BigDecimal.ZERO;
            BigDecimal totalPhilHealth = BigDecimal.ZERO;
            BigDecimal totalPagibig = BigDecimal.ZERO;
            BigDecimal totalTax = BigDecimal.ZERO;

            for (PayrollEntity payroll : payrolls) {

                List<DeductionEntity> deductions =
                        payrollService.getDeductionsByPayrollId(
                                payroll.getPayrollId()
                        );

                for (DeductionEntity deduction : deductions) {

                    if (deduction.getDeductionType() == null
                            || deduction.getDeductionType().getDeductionTypeName() == null) {
                        continue;
                    }

                    String typeName =
                            deduction.getDeductionType()
                                    .getDeductionTypeName()
                                    .toLowerCase();

                    BigDecimal amount =
                            deduction.getAmount() != null
                                    ? deduction.getAmount()
                                    : BigDecimal.ZERO;

                    if (typeName.contains("sss")) {
                        totalSSS = totalSSS.add(amount);
                    } else if (typeName.contains("philhealth")
                            || typeName.contains("phil health")) {
                        totalPhilHealth = totalPhilHealth.add(amount);
                    } else if (typeName.contains("pag")
                            || typeName.contains("ibig")) {
                        totalPagibig = totalPagibig.add(amount);
                    } else if (typeName.contains("tax")
                            || typeName.contains("withholding")) {
                        totalTax = totalTax.add(amount);
                    }
                }
            }

            dataset.setValue("SSS", totalSSS);
            dataset.setValue("PhilHealth", totalPhilHealth);
            dataset.setValue("Pag-IBIG", totalPagibig);
            dataset.setValue("Withholding Tax", totalTax);

        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Unable to load deductions chart: " + ex.getMessage()
            );
        }

        JFreeChart chart = ChartFactory.createPieChart(
                "Deduction Breakdown",
                dataset,
                true,
                true,
                false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(350, 350));

        chartPanel.setMouseWheelEnabled(false);
        chartPanel.setDomainZoomable(false);
        chartPanel.setRangeZoomable(false);

        pnlDeductionBreakdown.removeAll();
        pnlDeductionBreakdown.setLayout(new BorderLayout());
        pnlDeductionBreakdown.add(chartPanel, BorderLayout.CENTER);
        pnlDeductionBreakdown.revalidate();
        pnlDeductionBreakdown.repaint();
    }
    
    private void loadEmployeePerPosition() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            List<EmployeeDetails> employees = employeeService.getAllEmployees();

            Map<String, Integer> positionCounts = new LinkedHashMap<>();

            for (EmployeeDetails employee : employees) {
                String position = employee.getJobDetails()
                        .getPosition()
                        .getDisplayName();

                if (position == null || position.isBlank()) {
                    position = "Unassigned";
                }

                positionCounts.put(
                        position,
                        positionCounts.getOrDefault(position, 0) + 1
                );
            }

            for (Map.Entry<String, Integer> entry : positionCounts.entrySet()) {
                dataset.addValue(entry.getValue(), "Employees", entry.getKey());
            }

        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Unable to load position chart: " + ex.getMessage()
            );
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Employees Per Position",
                "Position",
                "Employees",
                dataset
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(350, 350));

        pnlEmployeeCountPerDept.removeAll();
        pnlEmployeeCountPerDept.setLayout(new BorderLayout());
        pnlEmployeeCountPerDept.add(chartPanel, BorderLayout.CENTER);
        pnlEmployeeCountPerDept.revalidate();
        pnlEmployeeCountPerDept.repaint();
    }


    private void downloadMonthlySummaryReport() {
        if (cmbSelectMonthYear.getSelectedItem() == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a month first.");
            return;
        }

        String monthYear = cmbSelectMonthYear.getSelectedItem().toString();

        try {
            DefaultTableModel reportModel = buildMonthlySummaryReportModel(monthYear);

            if (reportModel.getRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "No payroll data found for " + monthYear + "."
                );
                return;
            }

            BigDecimal totalGross = BigDecimal.ZERO;
            BigDecimal totalDeductions = BigDecimal.ZERO;
            BigDecimal totalNet = BigDecimal.ZERO;

            for (int row = 0; row < reportModel.getRowCount(); row++) {
                totalGross = totalGross.add((BigDecimal) reportModel.getValueAt(row, 4));
                totalDeductions = totalDeductions
                        .add((BigDecimal) reportModel.getValueAt(row, 6))
                        .add((BigDecimal) reportModel.getValueAt(row, 8))
                        .add((BigDecimal) reportModel.getValueAt(row, 10))
                        .add((BigDecimal) reportModel.getValueAt(row, 12));
                totalNet = totalNet.add((BigDecimal) reportModel.getValueAt(row, 13));
            }

            String filename = promptForMonthlyReportLocation(monthYear);
            if (filename == null) {
                return;
            }

            JasperPayrollReportExporter.exportPayrollReportFromTable(
                    reportModel,
                    monthYear,
                    totalGross.doubleValue(),
                    totalDeductions.doubleValue(),
                    totalNet.doubleValue(),
                    filename
            );

            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Monthly summary report saved successfully as: " + filename
            );
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Error generating monthly summary report: " + ex.getMessage(),
                    "Report Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
        }
    }

    private DefaultTableModel buildMonthlySummaryReportModel(String monthYear) throws Exception {
        DefaultTableModel model = new DefaultTableModel(
                new Object[] {
                    "Employee No",
                    "Employee Full Name",
                    "Position",
                    "Department",
                    "Gross Income",
                    "Social Security No.",
                    "Social Security Contribution",
                    "Philhealth No.",
                    "Philhealth Contribution",
                    "Pag-ibig No.",
                    "Pag-ibig Contribution",
                    "TIN",
                    "Withholding Tax",
                    "Net Pay"
                },
                0
        );

        Map<String, MonthlyReportRow> monthlyRows = new LinkedHashMap<>();

        for (String cutoff : getCutoffLabels(monthYear)) {
            List<PayrollEntity> payrolls = payrollService.getPayrollBySelectedPeriod(monthYear, cutoff);

            for (PayrollEntity payroll : payrolls) {
                if (payroll.getEmployee() == null) {
                    continue;
                }

                String employeeNumber = String.valueOf(payroll.getEmployee().getEmployeeNumber());
                MonthlyReportRow row = monthlyRows.computeIfAbsent(
                        employeeNumber,
                        this::createMonthlyReportRow
                );

                PayrollSummary summary = payrollService.getPayrollSummary(
                        employeeNumber,
                        monthYear,
                        cutoff
                );

                if (summary == null) {
                    continue;
                }

                row.grossPay = row.grossPay.add(toMoney(summary.getGrossIncome()));
                row.sssContribution = row.sssContribution.add(toMoney(summary.getSss()));
                row.philhealthContribution = row.philhealthContribution.add(toMoney(summary.getPhilHealth()));
                row.pagibigContribution = row.pagibigContribution.add(toMoney(summary.getPagibig()));
                row.withholdingTax = row.withholdingTax.add(toMoney(summary.getTax()));
            }
        }

        for (MonthlyReportRow row : monthlyRows.values()) {
            row.netPay = row.grossPay
                    .subtract(row.sssContribution)
                    .subtract(row.philhealthContribution)
                    .subtract(row.pagibigContribution)
                    .subtract(row.withholdingTax);

            model.addRow(new Object[] {
                row.employeeNumber,
                row.employeeFullName,
                row.position,
                row.department,
                row.grossPay,
                row.sssNumber,
                row.sssContribution,
                row.philhealthNumber,
                row.philhealthContribution,
                row.pagibigNumber,
                row.pagibigContribution,
                row.tinNumber,
                row.withholdingTax,
                row.netPay
            });
        }

        return model;
    }

    private List<String> getCutoffLabels(String monthYear) throws Exception {
        List<String> labels = new java.util.ArrayList<>();

        for (Integer cutoffDay : payrollService.getCutoffsForMonth(monthYear)) {
            if (cutoffDay == null) {
                continue;
            }

            if (cutoffDay == 15) {
                labels.add("1st-15th");
            } else if (cutoffDay > 15) {
                labels.add("16th-" + cutoffDay + getDaySuffix(cutoffDay));
            }
        }

        return labels;
    }

    private MonthlyReportRow createMonthlyReportRow(String employeeNumber) {
        MonthlyReportRow row = new MonthlyReportRow(employeeNumber);

        try {
            EmployeeDetailsEntity employee = employeeService.getEmployeeEntityByNumber(employeeNumber);

            if (employee == null) {
                return row;
            }

            row.employeeFullName = blankToDefault(employee.getLastName(), "N/A")
                    + ", " + blankToDefault(employee.getFirstName(), "N/A");

            if (employee.getEmployee() != null) {
                row.sssNumber = blankToDefault(employee.getEmployee().getSssNumber(), "");
                row.philhealthNumber = blankToDefault(employee.getEmployee().getPhilhealthNumber(), "");
                row.pagibigNumber = blankToDefault(employee.getEmployee().getPagibigNumber(), "");
                row.tinNumber = blankToDefault(employee.getEmployee().getTinNumber(), "");

                if (employee.getEmployee().getDepartment() != null) {
                    row.department = blankToDefault(
                            employee.getEmployee().getDepartment().getDepartmentName(),
                            "Unassigned"
                    );
                }

                if (employee.getEmployee().getPosition() != null) {
                    row.position = blankToDefault(
                            employee.getEmployee().getPosition().getPositionName(),
                            "Unassigned"
                    );
                }
            }
        } catch (Exception ex) {
            row.employeeFullName = "N/A";
        }

        return row;
    }

    private String promptForMonthlyReportLocation(String monthYear) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Monthly Summary Report PDF");

        String filename = "MotorPH_Monthly_Summary_"
                + monthYear.replaceAll("[^a-zA-Z0-9-_]", "_")
                + ".pdf";

        fileChooser.setSelectedFile(
                new java.io.File(System.getProperty("user.home") + "/Downloads/" + filename)
        );
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents", "pdf"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection != JFileChooser.APPROVE_OPTION) {
            return null;
        }

        String path = fileChooser.getSelectedFile().getAbsolutePath();
        return path.toLowerCase().endsWith(".pdf") ? path : path + ".pdf";
    }

    private BigDecimal safe(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private BigDecimal toMoney(double value) {
        return BigDecimal.valueOf(value).setScale(2, java.math.RoundingMode.HALF_UP);
    }

    private String blankToDefault(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private String getDaySuffix(int day) {
        if (day >= 11 && day <= 13) {
            return "th";
        }

        return switch (day % 10) {
            case 1 -> "st";
            case 2 -> "nd";
            case 3 -> "rd";
            default -> "th";
        };
    }

    private static class MonthlyReportRow {

        private final String employeeNumber;
        private String employeeFullName = "N/A";
        private String position = "Unassigned";
        private String department = "Unassigned";
        private String sssNumber = "";
        private String philhealthNumber = "";
        private String pagibigNumber = "";
        private String tinNumber = "";
        private BigDecimal grossPay = BigDecimal.ZERO;
        private BigDecimal sssContribution = BigDecimal.ZERO;
        private BigDecimal philhealthContribution = BigDecimal.ZERO;
        private BigDecimal pagibigContribution = BigDecimal.ZERO;
        private BigDecimal withholdingTax = BigDecimal.ZERO;
        private BigDecimal netPay = BigDecimal.ZERO;

        private MonthlyReportRow(String employeeNumber) {
            this.employeeNumber = employeeNumber;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlEmpDetails = new javax.swing.JPanel();
        pnlEmployeeDetails = new javax.swing.JPanel();
        lblDashboardLogo = new javax.swing.JLabel();
        scrollPaneFullEmpDetails = new javax.swing.JScrollPane();
        pnlFullEmpDetails = new javax.swing.JPanel();
        lblSelectYear = new javax.swing.JLabel();
        cmbSelectMonthYear = new javax.swing.JComboBox<>();
        btnLoadCharts = new javax.swing.JButton();
        pnlChartGrossPayVsNetPay = new javax.swing.JPanel();
        pnlEmployeeCountPerDept = new javax.swing.JPanel();
        btnLoadCharts1 = new javax.swing.JButton();
        pnlDeductionBreakdown = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEmpDetails.setBackground(new java.awt.Color(238, 238, 238));

        pnlEmployeeDetails.setBackground(new java.awt.Color(33, 60, 81));
        pnlEmployeeDetails.setPreferredSize(new java.awt.Dimension(884, 142));

        lblDashboardLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblDashboardLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboardLogo.setText("Analytics");

        javax.swing.GroupLayout pnlEmployeeDetailsLayout = new javax.swing.GroupLayout(pnlEmployeeDetails);
        pnlEmployeeDetails.setLayout(pnlEmployeeDetailsLayout);
        pnlEmployeeDetailsLayout.setHorizontalGroup(
            pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblDashboardLogo)
                .addContainerGap(701, Short.MAX_VALUE))
        );
        pnlEmployeeDetailsLayout.setVerticalGroup(
            pnlEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeDetailsLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblDashboardLogo)
                .addGap(22, 22, 22))
        );

        scrollPaneFullEmpDetails.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneFullEmpDetails.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnlFullEmpDetails.setMaximumSize(null);

        lblSelectYear.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblSelectYear.setText("Select Month & Year");

        cmbSelectMonthYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnLoadCharts.setBackground(new java.awt.Color(101, 148, 177));
        btnLoadCharts.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLoadCharts.setForeground(new java.awt.Color(255, 255, 255));
        btnLoadCharts.setText("Dowload Monthly Report");

        pnlChartGrossPayVsNetPay.setBackground(new java.awt.Color(255, 255, 255));
        pnlChartGrossPayVsNetPay.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        javax.swing.GroupLayout pnlChartGrossPayVsNetPayLayout = new javax.swing.GroupLayout(pnlChartGrossPayVsNetPay);
        pnlChartGrossPayVsNetPay.setLayout(pnlChartGrossPayVsNetPayLayout);
        pnlChartGrossPayVsNetPayLayout.setHorizontalGroup(
            pnlChartGrossPayVsNetPayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 444, Short.MAX_VALUE)
        );
        pnlChartGrossPayVsNetPayLayout.setVerticalGroup(
            pnlChartGrossPayVsNetPayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 161, Short.MAX_VALUE)
        );

        pnlEmployeeCountPerDept.setBackground(new java.awt.Color(255, 255, 255));
        pnlEmployeeCountPerDept.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        javax.swing.GroupLayout pnlEmployeeCountPerDeptLayout = new javax.swing.GroupLayout(pnlEmployeeCountPerDept);
        pnlEmployeeCountPerDept.setLayout(pnlEmployeeCountPerDeptLayout);
        pnlEmployeeCountPerDeptLayout.setHorizontalGroup(
            pnlEmployeeCountPerDeptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlEmployeeCountPerDeptLayout.setVerticalGroup(
            pnlEmployeeCountPerDeptLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        btnLoadCharts1.setBackground(new java.awt.Color(101, 148, 177));
        btnLoadCharts1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLoadCharts1.setForeground(new java.awt.Color(255, 255, 255));
        btnLoadCharts1.setText("Load Charts");
        btnLoadCharts1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadCharts1ActionPerformed(evt);
            }
        });

        pnlDeductionBreakdown.setBackground(new java.awt.Color(255, 255, 255));
        pnlDeductionBreakdown.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        javax.swing.GroupLayout pnlDeductionBreakdownLayout = new javax.swing.GroupLayout(pnlDeductionBreakdown);
        pnlDeductionBreakdown.setLayout(pnlDeductionBreakdownLayout);
        pnlDeductionBreakdownLayout.setHorizontalGroup(
            pnlDeductionBreakdownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlDeductionBreakdownLayout.setVerticalGroup(
            pnlDeductionBreakdownLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 306, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout pnlFullEmpDetailsLayout = new javax.swing.GroupLayout(pnlFullEmpDetails);
        pnlFullEmpDetails.setLayout(pnlFullEmpDetailsLayout);
        pnlFullEmpDetailsLayout.setHorizontalGroup(
            pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                        .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pnlChartGrossPayVsNetPay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pnlDeductionBreakdown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(pnlEmployeeCountPerDept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                        .addComponent(lblSelectYear)
                        .addGap(18, 18, 18)
                        .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(270, 270, 270)
                        .addComponent(btnLoadCharts, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnLoadCharts1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        pnlFullEmpDetailsLayout.setVerticalGroup(
            pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSelectYear)
                    .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLoadCharts)
                    .addComponent(btnLoadCharts1))
                .addGap(27, 27, 27)
                .addGroup(pnlFullEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlFullEmpDetailsLayout.createSequentialGroup()
                        .addComponent(pnlChartGrossPayVsNetPay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pnlDeductionBreakdown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlEmployeeCountPerDept, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        scrollPaneFullEmpDetails.setViewportView(pnlFullEmpDetails);

        javax.swing.GroupLayout pnlEmpDetailsLayout = new javax.swing.GroupLayout(pnlEmpDetails);
        pnlEmpDetails.setLayout(pnlEmpDetailsLayout);
        pnlEmpDetailsLayout.setHorizontalGroup(
            pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEmpDetailsLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlEmployeeDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(scrollPaneFullEmpDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(26, Short.MAX_VALUE)))
        );
        pnlEmpDetailsLayout.setVerticalGroup(
            pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                .addComponent(pnlEmployeeDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(597, Short.MAX_VALUE))
            .addGroup(pnlEmpDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlEmpDetailsLayout.createSequentialGroup()
                    .addGap(175, 175, 175)
                    .addComponent(scrollPaneFullEmpDetails, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlEmpDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlEmpDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoadCharts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadCharts1ActionPerformed
          if (cmbSelectMonthYear.getSelectedItem() == null) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Please select a month first."
        );
        return;
    }

    loadCharts();
    }//GEN-LAST:event_btnLoadCharts1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Analytics().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLoadCharts;
    private javax.swing.JButton btnLoadCharts1;
    private javax.swing.JComboBox<String> cmbSelectMonthYear;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblDashboardLogo;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblSelectYear;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JPanel pnlChartGrossPayVsNetPay;
    private javax.swing.JPanel pnlDeductionBreakdown;
    private javax.swing.JPanel pnlEmpDetails;
    private javax.swing.JPanel pnlEmployeeCountPerDept;
    private javax.swing.JPanel pnlEmployeeDetails;
    private javax.swing.JPanel pnlFullEmpDetails;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JScrollPane scrollPaneFullEmpDetails;
    // End of variables declaration//GEN-END:variables
}
