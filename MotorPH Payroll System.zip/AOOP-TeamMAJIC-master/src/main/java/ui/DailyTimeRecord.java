package ui;

import entity.AttendanceEntity;
import java.io.IOException;
import javax.swing.Timer;
import model.EmployeeDetails;
import service.AttendanceService;
import service.EmployeeService;
import service.LoginService;
import ui.helpers.RBACController;
import utils.DateTimeUtils;
import utils.WindowUtils;

/**
 * Displays the daily time record screen for attendance management.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class DailyTimeRecord extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(DailyTimeRecord.class.getName());

    private Timer workingHoursTimer;
    private java.time.LocalTime clockInTimeValue;

    private AttendanceService attendanceService = new AttendanceService();
    private EmployeeService employeeService = new EmployeeService();

    public DailyTimeRecord() throws IOException {
        initComponents();

        txtfldStatus.setEditable(false);
        btnClockOut.setEnabled(false);

        loadTaskActivity();
        loadTodayAttendance();

        lblDTR.setEnabled(false);

        WindowUtils.applyStandardWindowConfig(this, "Daily Time Record");

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(DailyTimeRecord.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {
            LogOutFrame.showLogoutFrame(this);
        });

        txtfldCurrentMonth.setText(DateTimeUtils.getCurrentMonth());
        txtfldCurrentDate.setText(DateTimeUtils.getCurrentDay());

        Timer timer = new Timer(1000, e -> {
            txtfldCurrentTime.setText(DateTimeUtils.getCurrentTimeWithSeconds());
        });

        timer.start();

        btnClockIn.addActionListener(e -> clockInAction());
        btnClockOut.addActionListener(e -> clockOutAction());
    }

    private void loadTaskActivity() {
        try {
            String empNo = LoginService.getInstance().getLoggedInEmployeeNumber();
            EmployeeDetails emp = employeeService.getEmployeeByNumber(empNo);

            if (emp != null) {
                String position = emp.getJobDetails().getPosition().getDisplayName();

                txtfldTime.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                txtfldTaskActivity.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                txtfldTime.setText("9:00 AM - 5:00 PM");
                txtfldTaskActivity.setText("Work on " + position + " tasks");

                txtfldFullName.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                txtfldFullName.setText(emp.getFullName());

                txtfldEmpNo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                txtfldEmpNo.setText("EMPLOYEE NO. " + emp.getEmployeeNumber());
            }

        } catch (Exception e) {
            System.out.println("Unable to load task activity: " + e.getMessage());
        }
    }

    private void loadTodayAttendance() {
        try {
            String employeeNo =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            String today = DateTimeUtils.getCurrentDate();

            AttendanceEntity attendance =
                    attendanceService.findAttendanceEntity(employeeNo, today);

            if (attendance == null) {
                txtfldStatus.setText("Not Yet Clocked In");
                btnClockIn.setEnabled(true);
                btnClockOut.setEnabled(false);
                txtfldClockInTime.setText("");
                txtfldClockOutTime.setText("");
                txtfldWorkingHoursForTheDay.setText("");
                return;
            }

            String clockIn = attendance.getLogin() != null
                    ? attendance.getLogin().toString()
                    : "";

            String clockOut = attendance.getLogout() != null
                    ? attendance.getLogout().toString()
                    : "";

            txtfldClockInTime.setText(clockIn);

            if (attendance.getLogin() != null) {
                clockInTimeValue = attendance.getLogin();
            }

            if (clockOut.isEmpty()) {
                txtfldStatus.setText("Working");
                btnClockIn.setEnabled(false);
                btnClockOut.setEnabled(true);
                startWorkingHoursTimer();
            } else {
                txtfldClockOutTime.setText(clockOut);
                txtfldStatus.setText("Completed");
                btnClockIn.setEnabled(false);
                btnClockOut.setEnabled(false);

                txtfldWorkingHoursForTheDay.setText(
                        attendanceService.calculateWorkingHours(
                                attendance.getLogin(),
                                attendance.getLogout()
                        )
                );

                if (workingHoursTimer != null) {
                    workingHoursTimer.stop();
                }
            }

        } catch (Exception e) {
            System.out.println(
                    "Error loading attendance from database: "
                            + e.getMessage()
            );
        }
    }

    private void clockInAction() {
        try {
            String employeeNo =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            String clockInTime = DateTimeUtils.getCurrentTime();
            String date = DateTimeUtils.getCurrentDate();

            txtfldStatus.setText("Working");
            txtfldClockInTime.setText(clockInTime);

            clockInTimeValue = java.time.LocalTime.parse(clockInTime);

            attendanceService.clockIn(employeeNo, date, clockInTime);

            startWorkingHoursTimer();

            btnClockIn.setEnabled(false);
            btnClockOut.setEnabled(true);

        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Error saving Clock In:\n" + ex.getMessage()
            );
        }
    }

    private void clockOutAction() {
        try {
            String employeeNo =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            btnClockOut.setEnabled(false);
            txtfldStatus.setText("Completed");

            String clockOutTime = DateTimeUtils.getCurrentTime();
            String date = DateTimeUtils.getCurrentDate();

            txtfldClockOutTime.setText(clockOutTime);

            if (workingHoursTimer != null) {
                workingHoursTimer.stop();
            }

            attendanceService.clockOut(employeeNo, date, clockOutTime);

            java.time.LocalTime clockOut =
                    java.time.LocalTime.parse(clockOutTime);

            String workingHours =
                    attendanceService.calculateWorkingHours(
                            clockInTimeValue,
                            clockOut
                    );

            txtfldWorkingHoursForTheDay.setText(workingHours);
            btnClockIn.setEnabled(false);

        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Error saving Clock Out:\n" + ex.getMessage()
            );
        }
    }

    private void startWorkingHoursTimer() {
        if (workingHoursTimer != null) {
            workingHoursTimer.stop();
        }

        workingHoursTimer = new Timer(1000, evt -> {
            java.time.LocalTime now = java.time.LocalTime.now();

            txtfldWorkingHoursForTheDay.setText(
                    attendanceService.calculateWorkingHours(
                            clockInTimeValue,
                            now
                    )
            );
        });

        workingHoursTimer.start();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlDTR = new javax.swing.JPanel();
        pnlDTRHeader = new javax.swing.JPanel();
        lblDailyTimeRecordLogo = new javax.swing.JLabel();
        lblCurrentTime = new javax.swing.JLabel();
        txtfldCurrentTime = new javax.swing.JTextField();
        txtfldFullName = new javax.swing.JTextField();
        txtfldEmpNo = new javax.swing.JTextField();
        scrollPaneDailyTimeRecord = new javax.swing.JScrollPane();
        pnlDTRBody = new javax.swing.JPanel();
        pnlClockInOut = new javax.swing.JPanel();
        txtfldCurrentDate = new javax.swing.JTextField();
        txtfldCurrentMonth = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        btnClockIn = new javax.swing.JButton();
        btnClockOut = new javax.swing.JButton();
        pnlHoursWorked = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        lblClockIn = new javax.swing.JLabel();
        lblClockOut = new javax.swing.JLabel();
        lblWorkingHours = new javax.swing.JLabel();
        txtfldWorkingHoursForTheDay = new javax.swing.JTextField();
        txtfldClockInTime = new javax.swing.JTextField();
        txtfldClockOutTime = new javax.swing.JTextField();
        lblYourTasksforToday = new javax.swing.JLabel();
        lblWorkSchedule = new javax.swing.JLabel();
        pnlTasksAndSchedule = new javax.swing.JPanel();
        jSeparator5 = new javax.swing.JSeparator();
        lblClockIn1 = new javax.swing.JLabel();
        lblBreak1 = new javax.swing.JLabel();
        txtfldTaskActivity = new javax.swing.JTextField();
        txtfldTime = new javax.swing.JTextField();
        txtfldStatus = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlDTR.setBackground(new java.awt.Color(238, 238, 238));

        pnlDTRHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlDTRHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblDailyTimeRecordLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblDailyTimeRecordLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblDailyTimeRecordLogo.setText("Daily Time Record");

        lblCurrentTime.setForeground(new java.awt.Color(255, 255, 255));
        lblCurrentTime.setText("Current Time: ");

        txtfldCurrentTime.setEditable(false);
        txtfldCurrentTime.setBackground(new java.awt.Color(33, 60, 81));
        txtfldCurrentTime.setForeground(new java.awt.Color(255, 255, 255));
        txtfldCurrentTime.setBorder(null);
        txtfldCurrentTime.setFocusable(false);

        txtfldFullName.setEditable(false);
        txtfldFullName.setBackground(new java.awt.Color(33, 60, 81));
        txtfldFullName.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        txtfldFullName.setForeground(new java.awt.Color(255, 255, 255));
        txtfldFullName.setBorder(null);
        txtfldFullName.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtfldFullName.setFocusable(false);
        txtfldFullName.setRequestFocusEnabled(false);
        txtfldFullName.setVerifyInputWhenFocusTarget(false);

        txtfldEmpNo.setEditable(false);
        txtfldEmpNo.setBackground(new java.awt.Color(33, 60, 81));
        txtfldEmpNo.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        txtfldEmpNo.setForeground(new java.awt.Color(255, 255, 255));
        txtfldEmpNo.setBorder(null);
        txtfldEmpNo.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        txtfldEmpNo.setFocusable(false);
        txtfldEmpNo.setRequestFocusEnabled(false);
        txtfldEmpNo.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlDTRHeaderLayout = new javax.swing.GroupLayout(pnlDTRHeader);
        pnlDTRHeader.setLayout(pnlDTRHeaderLayout);
        pnlDTRHeaderLayout.setHorizontalGroup(
            pnlDTRHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDTRHeaderLayout.createSequentialGroup()
                .addGroup(pnlDTRHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlDTRHeaderLayout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(lblDailyTimeRecordLogo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 356, Short.MAX_VALUE)
                        .addComponent(lblCurrentTime)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtfldCurrentTime, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlDTRHeaderLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlDTRHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtfldFullName, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(44, 44, 44))
        );
        pnlDTRHeaderLayout.setVerticalGroup(
            pnlDTRHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlDTRHeaderLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(txtfldFullName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(pnlDTRHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCurrentTime)
                    .addComponent(txtfldCurrentTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDailyTimeRecordLogo))
                .addGap(22, 22, 22))
        );

        scrollPaneDailyTimeRecord.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneDailyTimeRecord.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        pnlDTRBody.setMaximumSize(null);

        pnlClockInOut.setBackground(new java.awt.Color(255, 255, 255));
        pnlClockInOut.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));
        pnlClockInOut.setPreferredSize(new java.awt.Dimension(871, 136));

        txtfldCurrentDate.setEditable(false);
        txtfldCurrentDate.setBackground(new java.awt.Color(255, 255, 255));
        txtfldCurrentDate.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        txtfldCurrentDate.setForeground(new java.awt.Color(221, 174, 211));
        txtfldCurrentDate.setBorder(null);
        txtfldCurrentDate.setFocusable(false);
        txtfldCurrentDate.setRequestFocusEnabled(false);

        txtfldCurrentMonth.setEditable(false);
        txtfldCurrentMonth.setBackground(new java.awt.Color(255, 255, 255));
        txtfldCurrentMonth.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        txtfldCurrentMonth.setForeground(new java.awt.Color(33, 60, 81));
        txtfldCurrentMonth.setBorder(null);
        txtfldCurrentMonth.setFocusable(false);
        txtfldCurrentMonth.setRequestFocusEnabled(false);

        jSeparator1.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        btnClockIn.setBackground(new java.awt.Color(101, 148, 177));
        btnClockIn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClockIn.setForeground(new java.awt.Color(255, 255, 255));
        btnClockIn.setText("Clock In");

        btnClockOut.setBackground(new java.awt.Color(204, 0, 51));
        btnClockOut.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClockOut.setForeground(new java.awt.Color(255, 255, 255));
        btnClockOut.setText("Clock Out");

        javax.swing.GroupLayout pnlClockInOutLayout = new javax.swing.GroupLayout(pnlClockInOut);
        pnlClockInOut.setLayout(pnlClockInOutLayout);
        pnlClockInOutLayout.setHorizontalGroup(
            pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlClockInOutLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtfldCurrentDate, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfldCurrentMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(68, 68, 68)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addComponent(btnClockIn, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btnClockOut, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlClockInOutLayout.setVerticalGroup(
            pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlClockInOutLayout.createSequentialGroup()
                .addGroup(pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlClockInOutLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlClockInOutLayout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(txtfldCurrentMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtfldCurrentDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pnlClockInOutLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(pnlClockInOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnClockIn, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnClockOut, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pnlHoursWorked.setBackground(new java.awt.Color(255, 255, 255));
        pnlHoursWorked.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator2.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblClockIn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockIn.setText("Clock In");

        lblClockOut.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockOut.setText("Clock Out");

        lblWorkingHours.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblWorkingHours.setText("Working Hours");

        txtfldWorkingHoursForTheDay.setEditable(false);
        txtfldWorkingHoursForTheDay.setBackground(new java.awt.Color(255, 255, 255));
        txtfldWorkingHoursForTheDay.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        txtfldWorkingHoursForTheDay.setForeground(new java.awt.Color(33, 60, 81));
        txtfldWorkingHoursForTheDay.setAutoscrolls(false);
        txtfldWorkingHoursForTheDay.setBorder(null);
        txtfldWorkingHoursForTheDay.setFocusable(false);
        txtfldWorkingHoursForTheDay.setRequestFocusEnabled(false);
        txtfldWorkingHoursForTheDay.setVerifyInputWhenFocusTarget(false);

        txtfldClockInTime.setEditable(false);
        txtfldClockInTime.setBackground(new java.awt.Color(255, 255, 255));
        txtfldClockInTime.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        txtfldClockInTime.setForeground(new java.awt.Color(33, 60, 81));
        txtfldClockInTime.setAutoscrolls(false);
        txtfldClockInTime.setBorder(null);
        txtfldClockInTime.setFocusable(false);
        txtfldClockInTime.setRequestFocusEnabled(false);
        txtfldClockInTime.setVerifyInputWhenFocusTarget(false);

        txtfldClockOutTime.setEditable(false);
        txtfldClockOutTime.setBackground(new java.awt.Color(255, 255, 255));
        txtfldClockOutTime.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        txtfldClockOutTime.setForeground(new java.awt.Color(33, 60, 81));
        txtfldClockOutTime.setAutoscrolls(false);
        txtfldClockOutTime.setBorder(null);
        txtfldClockOutTime.setFocusable(false);
        txtfldClockOutTime.setRequestFocusEnabled(false);
        txtfldClockOutTime.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlHoursWorkedLayout = new javax.swing.GroupLayout(pnlHoursWorked);
        pnlHoursWorked.setLayout(pnlHoursWorkedLayout);
        pnlHoursWorkedLayout.setHorizontalGroup(
            pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHoursWorkedLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClockIn)
                    .addComponent(txtfldClockInTime, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(135, 135, 135)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClockOut)
                    .addComponent(txtfldClockOutTime, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(137, 137, 137)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblWorkingHours)
                    .addComponent(txtfldWorkingHoursForTheDay, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlHoursWorkedLayout.setVerticalGroup(
            pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHoursWorkedLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlHoursWorkedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlHoursWorkedLayout.createSequentialGroup()
                        .addComponent(lblWorkingHours)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldWorkingHoursForTheDay, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlHoursWorkedLayout.createSequentialGroup()
                        .addComponent(lblClockOut)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldClockOutTime, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlHoursWorkedLayout.createSequentialGroup()
                        .addComponent(lblClockIn)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldClockInTime, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator3, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                    .addComponent(jSeparator2))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        lblYourTasksforToday.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblYourTasksforToday.setText("Your Tasks for Today | Schedule: 9:00 AM to 5:00 PM");

        lblWorkSchedule.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        lblWorkSchedule.setText("Status:");
        lblWorkSchedule.setFocusable(false);
        lblWorkSchedule.setRequestFocusEnabled(false);
        lblWorkSchedule.setVerifyInputWhenFocusTarget(false);

        pnlTasksAndSchedule.setBackground(new java.awt.Color(255, 255, 255));
        pnlTasksAndSchedule.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator5.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblClockIn1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockIn1.setText("Time");

        lblBreak1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblBreak1.setText("Task/Activity");

        txtfldTaskActivity.setEditable(false);
        txtfldTaskActivity.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTaskActivity.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtfldTaskActivity.setBorder(null);
        txtfldTaskActivity.setFocusable(false);

        txtfldTime.setEditable(false);
        txtfldTime.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTime.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtfldTime.setBorder(null);
        txtfldTime.setFocusable(false);

        javax.swing.GroupLayout pnlTasksAndScheduleLayout = new javax.swing.GroupLayout(pnlTasksAndSchedule);
        pnlTasksAndSchedule.setLayout(pnlTasksAndScheduleLayout);
        pnlTasksAndScheduleLayout.setHorizontalGroup(
            pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                .addGroup(pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(lblClockIn1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addContainerGap(15, Short.MAX_VALUE)
                        .addComponent(txtfldTime, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)))
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addComponent(lblBreak1))
                    .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(txtfldTaskActivity, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38))
        );
        pnlTasksAndScheduleLayout.setVerticalGroup(
            pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                        .addGroup(pnlTasksAndScheduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                                .addComponent(lblClockIn1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtfldTime, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlTasksAndScheduleLayout.createSequentialGroup()
                                .addComponent(lblBreak1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtfldTaskActivity, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        txtfldStatus.setEditable(false);
        txtfldStatus.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        txtfldStatus.setAutoscrolls(false);
        txtfldStatus.setBorder(null);
        txtfldStatus.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtfldStatus.setEnabled(false);
        txtfldStatus.setFocusable(false);
        txtfldStatus.setRequestFocusEnabled(false);
        txtfldStatus.setSelectedTextColor(new java.awt.Color(242, 242, 242));
        txtfldStatus.setSelectionColor(new java.awt.Color(242, 242, 242));
        txtfldStatus.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlDTRBodyLayout = new javax.swing.GroupLayout(pnlDTRBody);
        pnlDTRBody.setLayout(pnlDTRBodyLayout);
        pnlDTRBodyLayout.setHorizontalGroup(
            pnlDTRBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDTRBodyLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDTRBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblYourTasksforToday)
                    .addGroup(pnlDTRBodyLayout.createSequentialGroup()
                        .addComponent(lblWorkSchedule)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtfldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlClockInOut, javax.swing.GroupLayout.DEFAULT_SIZE, 855, Short.MAX_VALUE)
                    .addComponent(pnlHoursWorked, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTasksAndSchedule, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        pnlDTRBodyLayout.setVerticalGroup(
            pnlDTRBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDTRBodyLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlClockInOut, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlHoursWorked, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblYourTasksforToday)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDTRBodyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblWorkSchedule)
                    .addComponent(txtfldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlTasksAndSchedule, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        scrollPaneDailyTimeRecord.setViewportView(pnlDTRBody);

        javax.swing.GroupLayout pnlDTRLayout = new javax.swing.GroupLayout(pnlDTR);
        pnlDTR.setLayout(pnlDTRLayout);
        pnlDTRLayout.setHorizontalGroup(
            pnlDTRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDTRLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlDTRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlDTRHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 895, Short.MAX_VALUE)
                    .addComponent(scrollPaneDailyTimeRecord, javax.swing.GroupLayout.DEFAULT_SIZE, 895, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDTRLayout.setVerticalGroup(
            pnlDTRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDTRLayout.createSequentialGroup()
                .addComponent(pnlDTRHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(scrollPaneDailyTimeRecord, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlDTR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(DailyTimeRecord.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClockIn;
    private javax.swing.JButton btnClockOut;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblBreak1;
    private javax.swing.JLabel lblClockIn;
    private javax.swing.JLabel lblClockIn1;
    private javax.swing.JLabel lblClockOut;
    private javax.swing.JLabel lblCurrentTime;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDailyTimeRecordLogo;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JLabel lblWorkSchedule;
    private javax.swing.JLabel lblWorkingHours;
    private javax.swing.JLabel lblYourTasksforToday;
    private javax.swing.JPanel pnlClockInOut;
    private javax.swing.JPanel pnlDTR;
    private javax.swing.JPanel pnlDTRBody;
    private javax.swing.JPanel pnlDTRHeader;
    private javax.swing.JPanel pnlHoursWorked;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlTasksAndSchedule;
    private javax.swing.JScrollPane scrollPaneDailyTimeRecord;
    private javax.swing.JTextField txtfldClockInTime;
    private javax.swing.JTextField txtfldClockOutTime;
    private javax.swing.JTextField txtfldCurrentDate;
    private javax.swing.JTextField txtfldCurrentMonth;
    private javax.swing.JTextField txtfldCurrentTime;
    private javax.swing.JTextField txtfldEmpNo;
    private javax.swing.JTextField txtfldFullName;
    private javax.swing.JTextField txtfldStatus;
    private javax.swing.JTextField txtfldTaskActivity;
    private javax.swing.JTextField txtfldTime;
    private javax.swing.JTextField txtfldWorkingHoursForTheDay;
    // End of variables declaration//GEN-END:variables
}
