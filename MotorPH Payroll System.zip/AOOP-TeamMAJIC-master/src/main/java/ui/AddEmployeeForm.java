/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import entity.AddressEntity;
import model.EmployeeDetails;
import utils.EmployeeValidator;
import utils.FormUtils;
import utils.WindowUtils;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.JTextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import service.EmployeeService;
import java.util.logging.Logger;


/**
 * Displays the form used to add a new employee record.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class AddEmployeeForm extends javax.swing.JFrame {
    
    private static final Logger logger =
        Logger.getLogger(AddEmployeeForm.class.getName());

    /**
     * Service layer responsible for employee operations
     * such as saving employees and generating IDs.
     */
    private EmployeeService employeeService =
        new EmployeeService();
    
    /**
     * Constructor
     * Initializes the UI and prepares form components.
     */
    public AddEmployeeForm() throws IOException {
    initComponents(); 

    jDateChooserBirthday.setDateFormatString("MM/dd/yyyy");
    
    // Apply consistent window configuration (title, center, etc.)
    WindowUtils.applyStandardWindowConfig(this, "Add Employee Form");

    // Close only this window, not the entire application
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        
    // Initialize UI behaviors
    initializeForm();
    initializeTooltips();
    attachButtonActions();
}


    /**
     * Initializes form values and UI behaviors.
     */
    private void initializeForm() throws IOException {

        // Generate next employee number automatically
        txtfldEmpNo.setText(employeeService.generateNextEmployeeNumber());

        // Prevent manual editing of computed / system fields
        FormUtils.makeDisplayOnly(txtfldEmpNo);
        FormUtils.makeDisplayOnly(txtfldGrossSemiMonthly);
        FormUtils.makeDisplayOnly(txtfldHourlyRate);

        /**
         * Automatically compute:
         * - Gross Semi Monthly Salary
         * - Hourly Rate
         * based on Basic Salary input
         */
        FormUtils.attachAutoComputeListener(
                txtfldBasicSalary,
                txtfldGrossSemiMonthly,
                txtfldHourlyRate
        );

        // Populate dropdown lists
        FormUtils.populateStatusComboBox(cmbbxStatus);
        FormUtils.populatePositionComboBox(cmbbxPosition);

        // Ensure no option is pre-selected
        cmbbxStatus.setSelectedIndex(-1);
        cmbbxPosition.setSelectedIndex(-1);

        /**
         * Attach duplicate checkers for:
         * - Government IDs
         * - Employee name + birthday combination
         */
    }

    /**
     * Adds tooltips to guide the user when filling the form.
     */
    private void initializeTooltips() {
        FormUtils.applyTooltips(
            txtfldEmpNo,
            txtfldLastName,
            txtfldFirstName,
            jDateChooserBirthday,
           txtfldStreet,
            txtfldBarangay,
            txtfldCity,
            txtfldProvince,
            txtfldZipcode,
            txtfldPhoneNo,
            txtfldEmail,
            txtfldSSS,
            txtfldPhilhealth,
            txtfldTIN,
            txtfldPagibig,
            cmbbxStatus,
            cmbbxPosition,
            txtfldSupervisor,
            txtfldBasicSalary,
            txtfldRiceSubsidy,
            txtfldPhoneAllowance,
            txtfldClothingAllowance,
            txtfldGrossSemiMonthly,
            txtfldHourlyRate
    );
    }

    /**
     * Attaches button event handlers.
     */
    private void attachButtonActions() {

        btnAdd.addActionListener(e -> addEmployee());
        btnClearAll.addActionListener(e -> clearForm());
        btnBack.addActionListener(e -> goBack());
    }

    /**
     * Handles adding a new employee to the system.
     */
    private void addEmployee() {

        try {

            // Ensure required dropdown fields are selected
            if (cmbbxStatus.getSelectedItem() == null ||
                cmbbxPosition.getSelectedItem() == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please select both Status and Position.",
                        "Missing Selection",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            /**
             * Collect employee details from form fields.
             */
            EmployeeDetails employee =
            FormUtils.collectEmployeeDetailsFromForm(new JTextField[]{
                    txtfldEmpNo, txtfldLastName, txtfldFirstName,
                    txtfldStreet, txtfldPhoneNo,
                    txtfldEmail, txtfldSSS, txtfldPhilhealth,
                    txtfldTIN, txtfldPagibig, txtfldSupervisor,
                    txtfldBasicSalary, txtfldRiceSubsidy,
                    txtfldPhoneAllowance, txtfldClothingAllowance,
                    txtfldGrossSemiMonthly, txtfldHourlyRate
                },
                jDateChooserBirthday,   
                cmbbxStatus,
                cmbbxPosition
    );


            if (employee == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to collect employee data.");
                return;
            }

            /**
             * Perform full validation.
             */
            EmployeeValidator.ValidationResult result =
                EmployeeValidator.validateEmployeeUpdateFields(
                        txtfldFirstName.getText(),
                        txtfldLastName.getText(),
                        txtfldStreet.getText(),
                        txtfldBarangay.getText(),
                        txtfldCity.getText(),
                        txtfldProvince.getText(),
                        txtfldZipcode.getText(),
                        txtfldPhoneNo.getText(),
                        txtfldEmail.getText(),
                        txtfldSSS.getText(),
                        txtfldPhilhealth.getText(),
                        txtfldTIN.getText(),
                        txtfldPagibig.getText(),
                        txtfldSupervisor.getText(),
                        employee.getPerson().getBirthday(),
                        txtfldBasicSalary.getText(),
                        txtfldRiceSubsidy.getText(),
                        txtfldPhoneAllowance.getText(),
                        txtfldClothingAllowance.getText()
                );

            if (!result.isValid()) {
                result.showErrors();
                return;
            }

            /**
             * Save employee through the service layer.
             */
            AddressEntity address = new AddressEntity();

            address.setStreet(txtfldStreet.getText().trim());
            address.setBarangay(txtfldBarangay.getText().trim());
            address.setCity(txtfldCity.getText().trim());
            address.setProvince(txtfldProvince.getText().trim());
            address.setZipcode(txtfldZipcode.getText().trim());

            employeeService.addEmployee(employee, address);

            JOptionPane.showMessageDialog(
                    this,
                    "Employee added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            // Reset form fields
            clearForm();

            // Generate next employee number
            txtfldEmpNo.setText(
                    employeeService.generateNextEmployeeNumber());

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving employee: " + e.getMessage(),
                    "System Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /**
     * Clears all input fields in the form.
     */
    private void clearForm() {

        FormUtils.resetAddEmployeeFormFields(txtfldLastName,
                txtfldFirstName,
                jDateChooserBirthday,
                txtfldStreet,
                txtfldPhoneNo,
                txtfldEmail,
                txtfldSSS,
                txtfldPhilhealth,
                txtfldTIN,
                txtfldPagibig,
                cmbbxStatus,
                cmbbxPosition,
                txtfldSupervisor,
                txtfldBasicSalary,
                txtfldRiceSubsidy,
                txtfldPhoneAllowance,
                txtfldClothingAllowance,
                txtfldGrossSemiMonthly,
                txtfldHourlyRate
        );
    }

    /**
     * Returns the user to the EmployeeList screen.
     */
    private void goBack() {

        new EmployeeListDashboard().setVisible(true);
        dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnClearAll = new javax.swing.JButton();
        txtfldLastName = new javax.swing.JTextField();
        lblStreet = new javax.swing.JLabel();
        lblAsterisk14 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        txtfldHourlyRate = new javax.swing.JTextField();
        lblBasicSalary = new javax.swing.JLabel();
        lblAsterisk15 = new javax.swing.JLabel();
        lblLastName = new javax.swing.JLabel();
        lblBirthday = new javax.swing.JLabel();
        txtfldPagibig = new javax.swing.JTextField();
        lblTIN = new javax.swing.JLabel();
        lblAsterisk18 = new javax.swing.JLabel();
        lblAsterisk2 = new javax.swing.JLabel();
        lblLeaveID = new javax.swing.JLabel();
        lblAsterisk1 = new javax.swing.JLabel();
        lblAsterisk17 = new javax.swing.JLabel();
        txtfldSSS = new javax.swing.JTextField();
        lblPagibig = new javax.swing.JLabel();
        lblSSS = new javax.swing.JLabel();
        txtfldSupervisor = new javax.swing.JTextField();
        lblAsterisk13 = new javax.swing.JLabel();
        lblAsterisk12 = new javax.swing.JLabel();
        lblAsterisk11 = new javax.swing.JLabel();
        lblAsterisk10 = new javax.swing.JLabel();
        lblAsterisk9 = new javax.swing.JLabel();
        lblHourlyRate = new javax.swing.JLabel();
        txtfldTIN = new javax.swing.JTextField();
        lblAsterisk16 = new javax.swing.JLabel();
        txtfldGrossSemiMonthly = new javax.swing.JTextField();
        jDateChooserBirthday = new com.toedter.calendar.JDateChooser();
        txtfldPhilhealth = new javax.swing.JTextField();
        lblGrossSemiMonthly = new javax.swing.JLabel();
        lblAsterisk8 = new javax.swing.JLabel();
        lblPhilhealth = new javax.swing.JLabel();
        lblAsterisk7 = new javax.swing.JLabel();
        txtfldClothingAllowance = new javax.swing.JTextField();
        lblAsterisk6 = new javax.swing.JLabel();
        lblClothingAllowance = new javax.swing.JLabel();
        lblAsterisk5 = new javax.swing.JLabel();
        lblAsterisk19 = new javax.swing.JLabel();
        lblSupervisor = new javax.swing.JLabel();
        txtfldPhoneAllowance = new javax.swing.JTextField();
        lblRiceSubsidy = new javax.swing.JLabel();
        txtfldPhoneNo = new javax.swing.JTextField();
        cmbbxPosition = new javax.swing.JComboBox<>();
        txtfldEmail = new javax.swing.JTextField();
        lblPhoneAllowance = new javax.swing.JLabel();
        lblPhoneNo = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblQuickActions = new javax.swing.JLabel();
        txtfldStreet = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        lblPosition = new javax.swing.JLabel();
        txtfldBasicSalary = new javax.swing.JTextField();
        txtfldFirstName = new javax.swing.JTextField();
        txtfldRiceSubsidy = new javax.swing.JTextField();
        lblFirstName = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        pnlMyPayslipHeader = new javax.swing.JPanel();
        lblAddEmployeeLogo = new javax.swing.JLabel();
        lblAsterisk4 = new javax.swing.JLabel();
        lblAsterisk3 = new javax.swing.JLabel();
        cmbbxStatus = new javax.swing.JComboBox<>();
        txtfldEmpNo = new javax.swing.JTextField();
        lblBarangay = new javax.swing.JLabel();
        lblAsterisk20 = new javax.swing.JLabel();
        txtfldBarangay = new javax.swing.JTextField();
        lblCity = new javax.swing.JLabel();
        lblAsterisk21 = new javax.swing.JLabel();
        txtfldCity = new javax.swing.JTextField();
        lblProvince = new javax.swing.JLabel();
        lblAsterisk22 = new javax.swing.JLabel();
        txtfldProvince = new javax.swing.JTextField();
        lblZipcode = new javax.swing.JLabel();
        lblAsterisk23 = new javax.swing.JLabel();
        txtfldZipcode = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnClearAll.setBackground(new java.awt.Color(101, 148, 177));
        btnClearAll.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnClearAll.setForeground(new java.awt.Color(255, 255, 255));
        btnClearAll.setText("Clear All");

        lblStreet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStreet.setText("Street");

        lblAsterisk14.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk14.setText("*");

        btnBack.setBackground(new java.awt.Color(101, 148, 177));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("Back");

        lblBasicSalary.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBasicSalary.setText("Basic Salary");

        lblAsterisk15.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk15.setText("*");

        lblLastName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLastName.setText("Last Name");

        lblBirthday.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBirthday.setText("Birthday");

        txtfldPagibig.setText("############");

        lblTIN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTIN.setText("TIN Number");

        lblAsterisk18.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk18.setText("*");

        lblAsterisk2.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk2.setText("*");

        lblLeaveID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLeaveID.setText("Employee No.");

        lblAsterisk1.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk1.setText("*");

        lblAsterisk17.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk17.setText("*");

        txtfldSSS.setText("##-#######-#");

        lblPagibig.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPagibig.setText("Pag-ibig Number");

        lblSSS.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSSS.setText("SSS Number");

        lblAsterisk13.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk13.setText("*");

        lblAsterisk12.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk12.setText("*");

        lblAsterisk11.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk11.setText("*");

        lblAsterisk10.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk10.setText("*");

        lblAsterisk9.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk9.setText("*");

        lblHourlyRate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHourlyRate.setText("Hourly Rate");

        txtfldTIN.setText("###-###-###-###");

        lblAsterisk16.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk16.setText("*");

        txtfldPhilhealth.setText("############");

        lblGrossSemiMonthly.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGrossSemiMonthly.setText("Gross Semi-Monthly");

        lblAsterisk8.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk8.setText("*");

        lblPhilhealth.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhilhealth.setText("PhilHealth Number");

        lblAsterisk7.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk7.setText("*");

        lblAsterisk6.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk6.setText("*");

        lblClothingAllowance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblClothingAllowance.setText("Clothing Allowance");

        lblAsterisk5.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk5.setText("*");

        lblAsterisk19.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk19.setText("*");

        lblSupervisor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSupervisor.setText("Immediate Supervisor");

        lblRiceSubsidy.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRiceSubsidy.setText("Rice Subsidy");

        txtfldPhoneNo.setText("###-###-###");

        cmbbxPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblPhoneAllowance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhoneAllowance.setText("Phone Allowance");

        lblPhoneNo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhoneNo.setText("Phone Number");

        lblEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEmail.setText("Email Address");

        lblQuickActions.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblQuickActions.setText("Quick Actions");

        btnAdd.setBackground(new java.awt.Color(101, 148, 177));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("Add");

        lblPosition.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPosition.setText("Position");

        lblFirstName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFirstName.setText("First Name");

        lblStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStatus.setText("Status");

        pnlMyPayslipHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlMyPayslipHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblAddEmployeeLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblAddEmployeeLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblAddEmployeeLogo.setText("Add New Employee");

        javax.swing.GroupLayout pnlMyPayslipHeaderLayout = new javax.swing.GroupLayout(pnlMyPayslipHeader);
        pnlMyPayslipHeader.setLayout(pnlMyPayslipHeaderLayout);
        pnlMyPayslipHeaderLayout.setHorizontalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblAddEmployeeLogo)
                .addContainerGap(801, Short.MAX_VALUE))
        );
        pnlMyPayslipHeaderLayout.setVerticalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addContainerGap(101, Short.MAX_VALUE)
                .addComponent(lblAddEmployeeLogo)
                .addGap(22, 22, 22))
        );

        lblAsterisk4.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk4.setText("*");

        lblAsterisk3.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk3.setText("*");

        cmbbxStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtfldEmpNo.setBackground(new java.awt.Color(204, 204, 204));

        lblBarangay.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBarangay.setText("Barangay");

        lblAsterisk20.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk20.setText("*");

        lblCity.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCity.setText("City");

        lblAsterisk21.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk21.setText("*");

        lblProvince.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblProvince.setText("Province");

        lblAsterisk22.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk22.setText("*");

        lblZipcode.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblZipcode.setText("Zipcode");

        lblAsterisk23.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk23.setText("*");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 1146, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblLastName)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblLeaveID)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblFirstName)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblBirthday)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblStreet)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblBarangay)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk20, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblCity)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk21, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblProvince)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk22, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblZipcode)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk23, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(61, 61, 61)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfldProvince, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldCity, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jDateChooserBirthday, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldZipcode, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblGrossSemiMonthly)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk17, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblHourlyRate)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk18, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(13, 13, 13)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtfldGrossSemiMonthly)
                                            .addComponent(txtfldHourlyRate, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(lblSupervisor)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(lblPosition)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(lblAsterisk11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(lblStatus)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(lblAsterisk10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblBasicSalary)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk13, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblRiceSubsidy)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk14, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblPhoneAllowance)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk15, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblClothingAllowance)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk16, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(txtfldPhoneAllowance, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldRiceSubsidy, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldBasicSalary, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldSupervisor, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cmbbxPosition, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(txtfldClothingAllowance)
                                            .addComponent(cmbbxStatus, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblQuickActions)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblPhoneNo)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblEmail)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk19, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(34, 34, 34)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblSSS)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblPhilhealth)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk7))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                        .addComponent(lblTIN)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblAsterisk8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(lblPagibig, javax.swing.GroupLayout.Alignment.LEADING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk9, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(32, 32, 32)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldPagibig, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldTIN, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldSSS, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(63, 63, 63)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblQuickActions)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd)
                    .addComponent(btnClearAll)
                    .addComponent(btnBack))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblAsterisk10)
                            .addComponent(lblStatus)
                            .addComponent(cmbbxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPosition)
                            .addComponent(lblAsterisk11)
                            .addComponent(cmbbxPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSupervisor)
                            .addComponent(lblAsterisk12))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBasicSalary)
                            .addComponent(txtfldBasicSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk13))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblRiceSubsidy)
                                .addComponent(lblAsterisk14))
                            .addComponent(txtfldRiceSubsidy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldPhoneAllowance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPhoneAllowance)
                            .addComponent(lblAsterisk15))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldClothingAllowance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblClothingAllowance)
                            .addComponent(lblAsterisk16))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldGrossSemiMonthly, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblGrossSemiMonthly)
                            .addComponent(lblAsterisk17))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldHourlyRate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHourlyRate)
                            .addComponent(lblAsterisk18)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblLeaveID)
                            .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblLastName)
                            .addComponent(txtfldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblFirstName)
                            .addComponent(txtfldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblBirthday)
                                .addComponent(lblAsterisk3))
                            .addComponent(jDateChooserBirthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblStreet)
                            .addComponent(txtfldStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBarangay)
                            .addComponent(txtfldBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk20))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCity)
                            .addComponent(txtfldCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk21))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblProvince)
                            .addComponent(txtfldProvince, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk22))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblZipcode)
                            .addComponent(txtfldZipcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk23))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPhoneNo)
                            .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEmail)
                            .addComponent(txtfldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk19))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSSS)
                            .addComponent(txtfldSSS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPhilhealth)
                            .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk7))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTIN)
                            .addComponent(txtfldTIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk8))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPagibig)
                            .addComponent(txtfldPagibig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk9))))
                .addContainerGap(58, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new AddEmployeeForm().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(AddEmployeeForm.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JComboBox<String> cmbbxPosition;
    private javax.swing.JComboBox<String> cmbbxStatus;
    private com.toedter.calendar.JDateChooser jDateChooserBirthday;
    private javax.swing.JLabel lblAddEmployeeLogo;
    private javax.swing.JLabel lblAsterisk1;
    private javax.swing.JLabel lblAsterisk10;
    private javax.swing.JLabel lblAsterisk11;
    private javax.swing.JLabel lblAsterisk12;
    private javax.swing.JLabel lblAsterisk13;
    private javax.swing.JLabel lblAsterisk14;
    private javax.swing.JLabel lblAsterisk15;
    private javax.swing.JLabel lblAsterisk16;
    private javax.swing.JLabel lblAsterisk17;
    private javax.swing.JLabel lblAsterisk18;
    private javax.swing.JLabel lblAsterisk19;
    private javax.swing.JLabel lblAsterisk2;
    private javax.swing.JLabel lblAsterisk20;
    private javax.swing.JLabel lblAsterisk21;
    private javax.swing.JLabel lblAsterisk22;
    private javax.swing.JLabel lblAsterisk23;
    private javax.swing.JLabel lblAsterisk3;
    private javax.swing.JLabel lblAsterisk4;
    private javax.swing.JLabel lblAsterisk5;
    private javax.swing.JLabel lblAsterisk6;
    private javax.swing.JLabel lblAsterisk7;
    private javax.swing.JLabel lblAsterisk8;
    private javax.swing.JLabel lblAsterisk9;
    private javax.swing.JLabel lblBarangay;
    private javax.swing.JLabel lblBasicSalary;
    private javax.swing.JLabel lblBirthday;
    private javax.swing.JLabel lblCity;
    private javax.swing.JLabel lblClothingAllowance;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblGrossSemiMonthly;
    private javax.swing.JLabel lblHourlyRate;
    private javax.swing.JLabel lblLastName;
    private javax.swing.JLabel lblLeaveID;
    private javax.swing.JLabel lblPagibig;
    private javax.swing.JLabel lblPhilhealth;
    private javax.swing.JLabel lblPhoneAllowance;
    private javax.swing.JLabel lblPhoneNo;
    private javax.swing.JLabel lblPosition;
    private javax.swing.JLabel lblProvince;
    private javax.swing.JLabel lblQuickActions;
    private javax.swing.JLabel lblRiceSubsidy;
    private javax.swing.JLabel lblSSS;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblStreet;
    private javax.swing.JLabel lblSupervisor;
    private javax.swing.JLabel lblTIN;
    private javax.swing.JLabel lblZipcode;
    private javax.swing.JPanel pnlMyPayslipHeader;
    private javax.swing.JTextField txtfldBarangay;
    private javax.swing.JTextField txtfldBasicSalary;
    private javax.swing.JTextField txtfldCity;
    private javax.swing.JTextField txtfldClothingAllowance;
    private javax.swing.JTextField txtfldEmail;
    private javax.swing.JTextField txtfldEmpNo;
    private javax.swing.JTextField txtfldFirstName;
    private javax.swing.JTextField txtfldGrossSemiMonthly;
    private javax.swing.JTextField txtfldHourlyRate;
    private javax.swing.JTextField txtfldLastName;
    private javax.swing.JTextField txtfldPagibig;
    private javax.swing.JTextField txtfldPhilhealth;
    private javax.swing.JTextField txtfldPhoneAllowance;
    private javax.swing.JTextField txtfldPhoneNo;
    private javax.swing.JTextField txtfldProvince;
    private javax.swing.JTextField txtfldRiceSubsidy;
    private javax.swing.JTextField txtfldSSS;
    private javax.swing.JTextField txtfldStreet;
    private javax.swing.JTextField txtfldSupervisor;
    private javax.swing.JTextField txtfldTIN;
    private javax.swing.JTextField txtfldZipcode;
    // End of variables declaration//GEN-END:variables
}
