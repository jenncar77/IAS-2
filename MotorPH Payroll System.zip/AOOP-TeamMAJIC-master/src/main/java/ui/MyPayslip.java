package ui;

import entity.AllowanceEntity;
import entity.EmployeeDetailsEntity;
import java.io.IOException;
import javax.swing.JOptionPane;
import model.PayrollSummary;
import service.LoginService;
import service.PayrollService;
import service.EmployeeService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import utils.NumberFormattingUtils;
import utils.PayslipPDFExporter;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import utils.JasperPayslipExporter;

/**
 * Displays the payslip viewing screen for the logged-in employee.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class MyPayslip extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(MyPayslip.class.getName());

    // ===============================
    // SERVICES
    // ===============================
    private final PayrollService payrollService =
        new PayrollService();

    private final EmployeeService employeeService =
        new EmployeeService();

    public MyPayslip() throws Exception {

        initComponents();
        
        alignFieldsRight();

        lblMyPayslip.setEnabled(false);

        loadPayPeriods();

        cmbSelectMonthYear.addActionListener(e -> {
            String selectedMonth = (String) cmbSelectMonthYear.getSelectedItem();
            if (selectedMonth != null) {
                updateCutoffDropdown(selectedMonth);
            }
        });

        WindowUtils.applyStandardWindowConfig(this, "My Payslip");

        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        txtfldGrossSalary.setEditable(false);
        txtfldTotalDeductions.setEditable(false);
        txtfldNetSalary.setEditable(false);
        txtfldSSSDeductionAmount.setEditable(false);
        txtfldPhilHealthDeductionAmount.setEditable(false);
        txtfldPagibigDeductionAmount.setEditable(false);
        txtfldTax.setEditable(false);

        btnViewPayslip.addActionListener(this::btnViewPayslipActionPerformed);
        btnDownloadPayslipAsPDF.addActionListener(this::btnDownloadPayslipAsPDFActionPerformed);

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
        try {
            new DailyTimeRecord().setVisible(true);
        } catch (IOException ex) {
            System.getLogger(MainDashboard.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

        // Open logout confirmation ONLY (no logout yet)
        LogOutFrame.showLogoutFrame(this);

            });
    }

    // ===============================
    // LOAD PAY PERIODS FROM PAYROLL SERVICE
    // ===============================
    private void loadPayPeriods() throws Exception {

        List<String> months =
                payrollService.getAvailablePayrollMonths();

        cmbSelectMonthYear.removeAllItems();

        for (String month : months) {
            cmbSelectMonthYear.addItem(month);
        }

        if (!months.isEmpty()) {
            String latestMonth = months.get(months.size() - 1);

            cmbSelectMonthYear.setSelectedItem(latestMonth);

            updateCutoffDropdown(latestMonth);
        }
    }

    // ===============================
    // UPDATE CUTOFF DROPDOWN
    // ===============================
    private void updateCutoffDropdown(String selectedMonth) {

        try {
            cmbChooseAPayslip.removeAllItems();

            List<Integer> cutoffs =
                    payrollService.getCutoffsForMonth(selectedMonth);

            if (cutoffs == null || cutoffs.isEmpty()) {
                return;
            }

            String[] parts = selectedMonth.split(" ");
            String monthName = parts[0];
            int year = Integer.parseInt(parts[1]);

            java.time.Month month =
                    java.time.Month.valueOf(monthName.toUpperCase());

            int lastDay = month.length(java.time.Year.isLeap(year));

            if (cutoffs.contains(15)) {
                cmbChooseAPayslip.addItem("1st-15th");
            }

            if (cutoffs.contains(lastDay)
                    || cutoffs.contains(30)
                    || cutoffs.contains(31)) {
                cmbChooseAPayslip.addItem("16th-" + lastDay + getDaySuffix(lastDay));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error loading cutoff list:\n" + e.getMessage()
            );
        }
    }

    // ===============================
    // HELPER: DAY SUFFIX
    // ===============================
    private String getDaySuffix(int day) {
        if (day >= 11 && day <= 13) return "th";

        switch (day % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    // ===============================
    // VIEW PAYSLIP
    // ===============================
    private void btnViewPayslipActionPerformed(java.awt.event.ActionEvent evt) {

        String selectedMonthYear = (String) cmbSelectMonthYear.getSelectedItem();
        String selectedCutoff = (String) cmbChooseAPayslip.getSelectedItem();

        if (selectedMonthYear == null || selectedCutoff == null) {
            JOptionPane.showMessageDialog(this, "Please select a pay period first.");
            return;
        }

        try {
            String employeeNumber =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            PayrollSummary summary =
                    payrollService.getPayrollSummary(
                            employeeNumber,
                            selectedMonthYear,
                            selectedCutoff
                    );

            if (summary == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "No payroll data found for this employee in the selected pay period."
                );
                return;
            }

            txtfldGrossSalary.setText(
                    NumberFormattingUtils.formatCurrency(summary.getGrossIncome()));

            txtfldTotalDeductions.setText(
                    NumberFormattingUtils.formatCurrency(summary.getTotalDeductions()));

            txtfldSSSDeductionAmount.setText(
                    NumberFormattingUtils.formatCurrency(summary.getSss()));

            txtfldPhilHealthDeductionAmount.setText(
                    NumberFormattingUtils.formatCurrency(summary.getPhilHealth()));

            txtfldPagibigDeductionAmount.setText(
                    NumberFormattingUtils.formatCurrency(summary.getPagibig()));

            txtfldTax.setText(
                    NumberFormattingUtils.formatCurrency(summary.getTax()));

            txtfldNetSalary.setText(
                    NumberFormattingUtils.formatCurrency(summary.getNetIncome()));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error loading payslip: " + ex.getMessage(),
                    "Payroll Error",
                    JOptionPane.ERROR_MESSAGE
            );

            ex.printStackTrace();
        }
    }

    // ===============================
    // DOWNLOAD PAYSLIP
    // ===============================
    private void btnDownloadPayslipAsPDFActionPerformed(java.awt.event.ActionEvent evt) {

        String selectedMonthYear = (String) cmbSelectMonthYear.getSelectedItem();
        String selectedCutoff = (String) cmbChooseAPayslip.getSelectedItem();

        if (selectedMonthYear == null || selectedCutoff == null) {
            JOptionPane.showMessageDialog(this, "Please select a pay period first.");
            return;
        }

        try {

            String employeeNumber =
                    LoginService.getInstance().getLoggedInEmployeeNumber();

            var emp =
                    employeeService.getEmployeeByNumber(employeeNumber);

            PayrollSummary summary =
                    payrollService.getPayrollSummary(
                            employeeNumber,
                            selectedMonthYear,
                            selectedCutoff
                    );

            if (summary == null) return;

            String filename =
                    PayslipPDFExporter.promptForFileLocation(
                            emp.getEmployeeNumber() + "_" + selectedMonthYear + "_" + selectedCutoff
                    );

            if (filename == null) return;

            EmployeeDetailsEntity employeeEntity =
                    employeeService.getEmployeeEntityByNumber(employeeNumber);
            double[] allowances = getAllowanceBreakdown(employeeNumber);
            LocalDate[] payPeriodDates = getPayPeriodDates(selectedMonthYear, selectedCutoff);

            JasperPayslipExporter.exportPayslip(
                    emp.getEmployeeNumber(),
                    emp.getFullName(),
                    emp.getJobDetails().getPosition().getDisplayName(),
                    getDepartmentName(employeeEntity),
                    selectedMonthYear + " - " + selectedCutoff,
                    formatReportDate(payPeriodDates[0]),
                    formatReportDate(payPeriodDates[1]),
                    summary.getGrossIncome(),
                    summary.getTotalDeductions(),
                    summary.getNetIncome(),
                    summary.getSss(),
                    summary.getPhilHealth(),
                    summary.getPagibig(),
                    summary.getTax(),
                    summary.getRegularPay(),
                    summary.getTotalAllowances(),
                    allowances[0],
                    allowances[1],
                    allowances[2],
                    summary.getDailyRate(),
                    summary.getDaysWorked(),
                    summary.getOvertimePay(),
                    filename
            );
            JOptionPane.showMessageDialog(
                    this,
                    "Payslip saved successfully as: " + filename);

        } catch (Exception ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Error generating payslip: " + ex.getMessage());
        }
    }
    

    private double[] getAllowanceBreakdown(String employeeNumber) throws IOException {
        double riceSubsidy = 0.0;
        double phoneAllowance = 0.0;
        double clothingAllowance = 0.0;

        for (AllowanceEntity allowance : payrollService.getAllowancesByEmployee(employeeNumber)) {
            if (allowance.getAllowanceType() == null
                    || allowance.getAllowanceType().getAllowanceTypeName() == null
                    || allowance.getAmount() == null) {
                continue;
            }

            String typeName = allowance.getAllowanceType()
                    .getAllowanceTypeName()
                    .toLowerCase(Locale.ROOT);
            double amount = allowance.getAmount().doubleValue();

            if (typeName.contains("rice")) {
                riceSubsidy += amount;
            } else if (typeName.contains("phone")) {
                phoneAllowance += amount;
            } else if (typeName.contains("clothing")) {
                clothingAllowance += amount;
            }
        }

        return new double[] { riceSubsidy / 2, phoneAllowance / 2, clothingAllowance / 2 };
    }

    private String getDepartmentName(EmployeeDetailsEntity employeeEntity) {
        if (employeeEntity == null
                || employeeEntity.getEmployee() == null
                || employeeEntity.getEmployee().getDepartment() == null
                || employeeEntity.getEmployee().getDepartment().getDepartmentName() == null) {
            return "N/A";
        }

        return employeeEntity.getEmployee().getDepartment().getDepartmentName();
    }

    private LocalDate[] getPayPeriodDates(String selectedMonthYear, String selectedCutoff) {
        YearMonth month = YearMonth.parse(
                selectedMonthYear,
                DateTimeFormatter.ofPattern("MMMM yyyy")
        );

        if ("1st-15th".equalsIgnoreCase(selectedCutoff)) {
            return new LocalDate[] { month.atDay(1), month.atDay(15) };
        }

        return new LocalDate[] { month.atDay(16), month.atEndOfMonth() };
    }

    private String formatReportDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy"));
    }
    //To align the fields to the right
    
    private void alignFieldsRight() {
    javax.swing.JTextField[] fields = {
        txtfldGrossSalary,
        txtfldTotalDeductions,
        txtfldNetSalary,
        txtfldSSSDeductionAmount,
        txtfldPhilHealthDeductionAmount,
        txtfldPagibigDeductionAmount,
        txtfldTax
    };

    for (javax.swing.JTextField field : fields) {
        field.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMyPayslip = new javax.swing.JPanel();
        pnlMyPayslipHeader = new javax.swing.JPanel();
        lblPayslip = new javax.swing.JLabel();
        lblPayPeriod = new javax.swing.JLabel();
        lblAsterisk = new javax.swing.JLabel();
        lblSelectYear = new javax.swing.JLabel();
        cmbSelectMonthYear = new javax.swing.JComboBox<>();
        lblChooseAPayslip = new javax.swing.JLabel();
        cmbChooseAPayslip = new javax.swing.JComboBox<>();
        btnViewPayslip = new javax.swing.JButton();
        btnDownloadPayslipAsPDF = new javax.swing.JButton();
        pnlPayrollOverview = new javax.swing.JPanel();
        lblGrossSalary = new javax.swing.JLabel();
        txtfldGrossSalary = new javax.swing.JTextField();
        lblBreakdownofDeductions = new javax.swing.JLabel();
        txtfldSSSDeductionAmount = new javax.swing.JTextField();
        lblPhilhealthDeduction = new javax.swing.JLabel();
        txtfldPhilHealthDeductionAmount = new javax.swing.JTextField();
        lblPagibigDeduction = new javax.swing.JLabel();
        txtfldPagibigDeductionAmount = new javax.swing.JTextField();
        lblTax = new javax.swing.JLabel();
        txtfldTax = new javax.swing.JTextField();
        lblNetSalary = new javax.swing.JLabel();
        txtfldNetSalary = new javax.swing.JTextField();
        lblPayrollOverview = new javax.swing.JLabel();
        lblIncludesText = new javax.swing.JLabel();
        lblSeparator = new javax.swing.JLabel();
        lblTotalDeductions = new javax.swing.JLabel();
        txtfldTotalDeductions = new javax.swing.JTextField();
        lblSssDeduction = new javax.swing.JLabel();
        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMyPayslip.setBackground(new java.awt.Color(238, 238, 238));

        pnlMyPayslipHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlMyPayslipHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblPayslip.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblPayslip.setText("My Payslip");

        javax.swing.GroupLayout pnlMyPayslipHeaderLayout = new javax.swing.GroupLayout(pnlMyPayslipHeader);
        pnlMyPayslipHeader.setLayout(pnlMyPayslipHeaderLayout);
        pnlMyPayslipHeaderLayout.setHorizontalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblPayslip)
                .addContainerGap(676, Short.MAX_VALUE))
        );
        pnlMyPayslipHeaderLayout.setVerticalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblPayslip)
                .addGap(22, 22, 22))
        );

        lblPayPeriod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblPayPeriod.setText("Pay Period");

        lblAsterisk.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblAsterisk.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk.setText("*");

        lblSelectYear.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblSelectYear.setText("Select Month & Year");

        cmbSelectMonthYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblChooseAPayslip.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChooseAPayslip.setText("Choose a Cutoff");

        cmbChooseAPayslip.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnViewPayslip.setBackground(new java.awt.Color(101, 148, 177));
        btnViewPayslip.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnViewPayslip.setForeground(new java.awt.Color(255, 255, 255));
        btnViewPayslip.setText("View Payslip");

        btnDownloadPayslipAsPDF.setBackground(new java.awt.Color(101, 148, 177));
        btnDownloadPayslipAsPDF.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDownloadPayslipAsPDF.setForeground(new java.awt.Color(255, 255, 255));
        btnDownloadPayslipAsPDF.setText("Download Payslip");

        pnlPayrollOverview.setBackground(new java.awt.Color(204, 204, 204));
        pnlPayrollOverview.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pnlPayrollOverview.setForeground(new java.awt.Color(255, 153, 51));

        lblGrossSalary.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblGrossSalary.setText("Gross Salary");

        txtfldGrossSalary.setBorder(null);

        lblBreakdownofDeductions.setFont(new java.awt.Font("Courier New", 2, 14)); // NOI18N
        lblBreakdownofDeductions.setText("Breakdown of Salary Deductions");

        txtfldSSSDeductionAmount.setForeground(new java.awt.Color(255, 0, 51));
        txtfldSSSDeductionAmount.setBorder(null);

        lblPhilhealthDeduction.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblPhilhealthDeduction.setText("PhilHealth Deduction");

        txtfldPhilHealthDeductionAmount.setForeground(new java.awt.Color(255, 0, 51));
        txtfldPhilHealthDeductionAmount.setBorder(null);

        lblPagibigDeduction.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblPagibigDeduction.setText("Pag-IBIG Deduction");

        txtfldPagibigDeductionAmount.setForeground(new java.awt.Color(255, 0, 51));
        txtfldPagibigDeductionAmount.setBorder(null);

        lblTax.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblTax.setText("Tax");

        txtfldTax.setForeground(new java.awt.Color(255, 0, 51));
        txtfldTax.setBorder(null);

        lblNetSalary.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblNetSalary.setText("Net Salary");

        txtfldNetSalary.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtfldNetSalary.setBorder(null);

        lblPayrollOverview.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        lblPayrollOverview.setText("Payroll Overview");

        lblIncludesText.setFont(new java.awt.Font("Courier New", 2, 10)); // NOI18N
        lblIncludesText.setText("includes Bi-Monthly Allowances");

        lblSeparator.setText("----------------------------");

        lblTotalDeductions.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblTotalDeductions.setText("Total Deductions");

        txtfldTotalDeductions.setBorder(null);

        lblSssDeduction.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        lblSssDeduction.setText("SSS Deduction");

        javax.swing.GroupLayout pnlPayrollOverviewLayout = new javax.swing.GroupLayout(pnlPayrollOverview);
        pnlPayrollOverview.setLayout(pnlPayrollOverviewLayout);
        pnlPayrollOverviewLayout.setHorizontalGroup(
            pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblGrossSalary)
                            .addComponent(lblIncludesText)
                            .addComponent(lblTotalDeductions)
                            .addComponent(lblNetSalary))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 271, Short.MAX_VALUE)
                        .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSeparator, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtfldGrossSalary, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtfldTotalDeductions, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtfldNetSalary, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblBreakdownofDeductions)
                                    .addComponent(lblPayrollOverview))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblPhilhealthDeduction)
                                    .addComponent(lblTax, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblPagibigDeduction)
                                    .addComponent(lblSssDeduction))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfldSSSDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldPhilHealthDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldPagibigDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtfldTax, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(55, 55, 55))
        );
        pnlPayrollOverviewLayout.setVerticalGroup(
            pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(lblPayrollOverview)
                .addGap(31, 31, 31)
                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addComponent(lblGrossSalary)
                        .addGap(2, 2, 2)
                        .addComponent(lblIncludesText)
                        .addGap(18, 18, 18)
                        .addComponent(lblTotalDeductions)
                        .addGap(42, 42, 42)
                        .addComponent(lblNetSalary)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 112, Short.MAX_VALUE)
                        .addComponent(lblBreakdownofDeductions))
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addComponent(txtfldGrossSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(txtfldTotalDeductions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblSeparator)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtfldNetSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(114, 114, 114)))
                .addGap(18, 18, 18)
                .addGroup(pnlPayrollOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addComponent(lblSssDeduction)
                        .addGap(18, 18, 18)
                        .addComponent(lblPhilhealthDeduction)
                        .addGap(18, 18, 18)
                        .addComponent(lblPagibigDeduction)
                        .addGap(18, 18, 18)
                        .addComponent(lblTax))
                    .addGroup(pnlPayrollOverviewLayout.createSequentialGroup()
                        .addComponent(txtfldSSSDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldPhilHealthDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldPagibigDeductionAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtfldTax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout pnlMyPayslipLayout = new javax.swing.GroupLayout(pnlMyPayslip);
        pnlMyPayslip.setLayout(pnlMyPayslipLayout);
        pnlMyPayslipLayout.setHorizontalGroup(
            pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pnlPayrollOverview, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                                .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSelectYear)
                                    .addComponent(lblChooseAPayslip)
                                    .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                                        .addComponent(lblPayPeriod)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbChooseAPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(67, 67, 67)
                                .addComponent(btnViewPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(btnDownloadPayslipAsPDF)
                                .addGap(16, 16, 16)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlMyPayslipLayout.setVerticalGroup(
            pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMyPayslipLayout.createSequentialGroup()
                .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipLayout.createSequentialGroup()
                        .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblAsterisk)
                            .addComponent(lblPayPeriod))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbSelectMonthYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSelectYear))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbChooseAPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblChooseAPayslip))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipLayout.createSequentialGroup()
                        .addGroup(pnlMyPayslipLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnViewPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDownloadPayslipAsPDF, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)))
                .addComponent(pnlPayrollOverview, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 21, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(MyPayslip.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDownloadPayslipAsPDF;
    private javax.swing.JButton btnViewPayslip;
    private javax.swing.JComboBox<String> cmbChooseAPayslip;
    private javax.swing.JComboBox<String> cmbSelectMonthYear;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblAsterisk;
    private javax.swing.JLabel lblBreakdownofDeductions;
    private javax.swing.JLabel lblChooseAPayslip;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblGrossSalary;
    private javax.swing.JLabel lblIncludesText;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblNetSalary;
    private javax.swing.JLabel lblPagibigDeduction;
    private javax.swing.JLabel lblPayPeriod;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblPayrollOverview;
    private javax.swing.JLabel lblPayslip;
    private javax.swing.JLabel lblPhilhealthDeduction;
    private javax.swing.JLabel lblSelectYear;
    private javax.swing.JLabel lblSeparator;
    private javax.swing.JLabel lblSssDeduction;
    private javax.swing.JLabel lblTax;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblTotalDeductions;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlMyPayslip;
    private javax.swing.JPanel pnlMyPayslipHeader;
    private javax.swing.JPanel pnlPayrollOverview;
    private javax.swing.JTextField txtfldGrossSalary;
    private javax.swing.JTextField txtfldNetSalary;
    private javax.swing.JTextField txtfldPagibigDeductionAmount;
    private javax.swing.JTextField txtfldPhilHealthDeductionAmount;
    private javax.swing.JTextField txtfldSSSDeductionAmount;
    private javax.swing.JTextField txtfldTax;
    private javax.swing.JTextField txtfldTotalDeductions;
    // End of variables declaration//GEN-END:variables
}
