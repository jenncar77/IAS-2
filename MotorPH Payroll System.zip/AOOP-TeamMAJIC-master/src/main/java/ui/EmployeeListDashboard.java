/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package ui;

import java.io.IOException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import service.EmployeeService;
import service.LoginService;
import ui.helpers.RBACController;
import utils.EmployeeValidator;
import utils.FormUtils;
import utils.WindowUtils;
import com.toedter.calendar.JDateChooser;
import entity.EmployeeDetailsEntity;
import entity.UserAccountEntity;
import repository.UserAccountRepository;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;


/**
 * Displays the employee list and maintenance screen.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class EmployeeListDashboard extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(EmployeeListDashboard.class.getName());

    private final EmployeeService employeeService = new EmployeeService();

    /**
     * Creates new form EmployeeList
     */
    public EmployeeListDashboard() {
        initComponents();
        
        alignFirstColumnLeft();

        jDateChooser1.setDateFormatString("MM/dd/yyyy");

        lblEmployeeList.setEnabled(false);

        setComponentNames();

        btnUpdateEmployee.setEnabled(false);
        btnDeleteEmployee.setEnabled(false);

        FormUtils.populateStatusComboBox(cmbbxStatus);
        FormUtils.populatePositionComboBox(cmbbxPosition);

        // Ensure nothing is selected initially
        cmbbxStatus.setSelectedIndex(-1);
        cmbbxPosition.setSelectedIndex(-1);

        // Apply standard window configuration
        WindowUtils.applyStandardWindowConfig(this, "Employee List");

        // Apply Role-Based Access Control (RBAC)
        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics
        );

        // Load employees from database through EmployeeService
        refreshEmployeeTable();
        
        // Lock fields initially
        FormUtils.lockAllFields(pnlUpdateEmployeeDetails, false);

        // Table row click listener
        attachTableRowListener();

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                System.getLogger(MainDashboard.class.getName())
                        .log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(EmployeeListDashboard.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {
            LogOutFrame.showLogoutFrame(this);
        });
    }
    
    private void alignFirstColumnLeft() {
        DefaultTableCellRenderer leftRenderer =
                new DefaultTableCellRenderer();

        leftRenderer.setHorizontalAlignment(SwingConstants.LEFT);

        tblEmp.getColumnModel()
              .getColumn(0)
              .setCellRenderer(leftRenderer);
    }

    private void refreshEmployeeTable() {
        try {
            DefaultTableModel model = (DefaultTableModel) tblEmp.getModel();
            model.setRowCount(0);

            List<Object[]> rows = employeeService.getEmployeeTableRows();

            for (Object[] row : rows) {
                model.addRow(row);
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load employee list: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void attachTableRowListener() {
    tblEmp.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) {
            int selectedRow = tblEmp.getSelectedRow();

            if (selectedRow < 0) {
                btnUpdateEmployee.setEnabled(false);
                btnDeleteEmployee.setEnabled(false);
                return;
            }

            btnUpdateEmployee.setEnabled(true);
            btnDeleteEmployee.setEnabled(true);

            String empNo = tblEmp.getValueAt(selectedRow, 0).toString();

            try {
                EmployeeDetailsEntity emp =
                        employeeService.getEmployeeEntityByNumber(empNo);

                if (emp != null) {
                    pnlUpdateEmployeeDetails.setVisible(true);

                    txtfldEmpNo.setText(String.valueOf(emp.getEmployeeNumber()));
                    txtfldLastName.setText(emp.getLastName());
                    txtfldFirstName.setText(emp.getFirstName());

                    if (emp.getBirthday() != null) {
                        jDateChooser1.setDate(
                                java.sql.Date.valueOf(emp.getBirthday())
                        );
                    } else {
                        jDateChooser1.setDate(null);
                    }
                    
                    if (emp.getAddress() != null) {
                        txtfldStreet.setText(emp.getAddress().getStreet());
                        txtfldBarangay.setText(emp.getAddress().getBarangay());
                        txtfldCity.setText(emp.getAddress().getCity());
                        txtfldProvince.setText(emp.getAddress().getProvince());
                        txtfldZipcode.setText(emp.getAddress().getZipcode());
                    } else {
                        txtfldStreet.setText("");
                        txtfldBarangay.setText("");
                        txtfldCity.setText("");
                        txtfldProvince.setText("");
                        txtfldZipcode.setText("");
                    }

                    txtfldPhoneNo.setText(emp.getPhoneNumber());

                    if (emp.getEmployee() != null) {
                        txtfldSSS.setText(emp.getEmployee().getSssNumber());
                        txtfldPhilhealth.setText(emp.getEmployee().getPhilhealthNumber());
                        txtfldTIN.setText(emp.getEmployee().getTinNumber());
                        txtfldPagibig.setText(emp.getEmployee().getPagibigNumber());

                        if (emp.getEmployee().getEmploymentStatus() != null) {
                            cmbbxStatus.setSelectedItem(
                                    emp.getEmployee()
                                            .getEmploymentStatus()
                                            .getEmploymentStatusName()
                            );
                        }

                        if (emp.getEmployee().getPosition() != null) {
                            cmbbxPosition.setSelectedItem(
                                    emp.getEmployee()
                                            .getPosition()
                                            .getPositionName()
                            );
                        }
                    }

                    UserAccountRepository userAccountRepository =
                new UserAccountRepository();

                UserAccountEntity account =
                        userAccountRepository.findByEmployeeNumber(emp.getEmployeeNumber());

                if (account != null) {
                    txtfldEmail.setText(account.getUsername());
                } else {
                    txtfldEmail.setText("");
                }

                
                if (emp.getEmployee() != null
                        && emp.getEmployee().getImmediateSupervisor() != null
                        && emp.getEmployee().getImmediateSupervisor().getEmployeeDetails() != null) {

                    txtfldSupervisor.setText(
                            emp.getEmployee()
                                    .getImmediateSupervisor()
                                    .getEmployeeDetails()
                                    .getFirstName()
                            + " "
                            + emp.getEmployee()
                                    .getImmediateSupervisor()
                                    .getEmployeeDetails()
                                    .getLastName()
                    );
                } else {
                    txtfldSupervisor.setText("");
                }

                    Object[] compFields =
                            employeeService.getCompensationAndAllowanceFields(
                                    String.valueOf(emp.getEmployeeNumber())
                            );

                    txtfldBasicSalary.setText(compFields[0].toString());
                    txtfldRiceSubsidy.setText(compFields[1].toString());
                    txtfldPhoneAllowance.setText(compFields[2].toString());
                    txtfldClothingAllowance.setText(compFields[3].toString());
                    txtfldGrossSemiMonthly.setText(compFields[4].toString());
                    txtfldHourlyRate.setText(compFields[5].toString());

                    FormUtils.lockAllFields(pnlUpdateEmployeeDetails, false);
                    FormUtils.disableUpdateButtons(btnSaveUpdate, btnCancelUpdate);

                    btnUpdateEmployee.setEnabled(true);
                    btnDeleteEmployee.setEnabled(true);
                }

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to load employee details: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    });
}

    private void setComponentNames() {
        txtfldEmpNo.setName("txtfldEmpNo");
        txtfldLastName.setName("txtfldLastName");
        txtfldFirstName.setName("txtfldFirstName");
        jDateChooser1.setName("txtfldBirthday");
        txtfldPhoneNo.setName("txtfldPhoneNo");
        txtfldEmail.setName("txtfldEmail");
        txtfldSSS.setName("txtfldSSS");
        txtfldPhilhealth.setName("txtfldPhilhealth");
        txtfldTIN.setName("txtfldTIN");
        txtfldPagibig.setName("txtfldPagibig");

        txtfldSupervisor.setName("txtfldSupervisor");

        txtfldBasicSalary.setName("txtfldBasicSalary");
        txtfldRiceSubsidy.setName("txtfldRiceSubsidy");
        txtfldPhoneAllowance.setName("txtfldPhoneAllowance");
        txtfldClothingAllowance.setName("txtfldClothingAllowance");
        txtfldGrossSemiMonthly.setName("txtfldGrossSemiMonthly");
        txtfldHourlyRate.setName("txtfldHourlyRate");

        cmbbxStatus.setName("cmbbxStatus");
        cmbbxPosition.setName("cmbbxPosition");
    }

                       

    private void btnDeleteEmployeeActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        int selectedRow = tblEmp.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an employee from the table.",
                    "No Row Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String empNumber = tblEmp.getValueAt(selectedRow, 0).toString();

        int confirmation = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this employee?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmation != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            employeeService.deleteEmployee(empNumber);

            JOptionPane.showMessageDialog(
                    this,
                    "Employee deleted successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            refreshEmployeeTable();

            btnUpdateEmployee.setEnabled(false);
            btnDeleteEmployee.setEnabled(false);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to delete employee from database: "
                            + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }                       

    private void btnUpdateEmployeeActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        if (tblEmp.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first.");
            return;
        }
        // 1. Unlock all fields except Employee Number (which should remain read-only)
        FormUtils.unlockAllFieldsExceptEmpNo(pnlUpdateEmployeeDetails);

        // 2. Set Gross Salary and Hourly Rate fields to display-only (auto-computed)
        FormUtils.makeDisplayOnly(txtfldGrossSemiMonthly);
        FormUtils.makeDisplayOnly(txtfldHourlyRate);

        // 3. Enable Save and Cancel buttons
        FormUtils.enableUpdateButtons(btnSaveUpdate, btnCancelUpdate);

        // 4. Attach listeners for auto-computing salary rates on Basic Salary changes
        FormUtils.attachAutoComputeListener(txtfldBasicSalary, txtfldGrossSemiMonthly, txtfldHourlyRate);

        // 5. Disable Update button to prevent redundant clicks during editing
        btnUpdateEmployee.setEnabled(false);

        // 6. Focus on Last Name field to guide the user to start editing
        txtfldLastName.requestFocus();

        // 7. Attaches tooltips to the input fields to help users fill the form correctly.
        FormUtils.applyTooltips(
                txtfldEmpNo,
                txtfldLastName,
                txtfldFirstName,
                jDateChooser1,
                txtfldStreet,
                txtfldBarangay,
                txtfldCity,
                txtfldProvince,
                txtfldZipcode,
                txtfldPhoneNo,
                txtfldEmail,
                txtfldSSS,
                txtfldPhilhealth,
                txtfldTIN,
                txtfldPagibig,
                cmbbxStatus,
                cmbbxPosition,
                txtfldSupervisor,
                txtfldBasicSalary,
                txtfldRiceSubsidy,
                txtfldPhoneAllowance,
                txtfldClothingAllowance,
                txtfldGrossSemiMonthly,
                txtfldHourlyRate
        );
    }                                                 

    private void btnAddNewEmployeeActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        try {
        new AddEmployeeForm().setVisible(true);
        dispose();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(
            this,
            "Failed to open Add Employee form: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    }                                                 

   private void btnSaveUpdateActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String empNo = txtfldEmpNo.getText().trim();

            java.time.LocalDate birthday = null;

            if (jDateChooser1.getDate() != null) {
                birthday = jDateChooser1.getDate()
                        .toInstant()
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate();
            }

            EmployeeValidator.ValidationResult validation =
                EmployeeValidator.validateEmployeeUpdateFields(
                        txtfldFirstName.getText(),
                        txtfldLastName.getText(),
                        txtfldStreet.getText(),
                        txtfldBarangay.getText(),
                        txtfldCity.getText(),
                        txtfldProvince.getText(),
                        txtfldZipcode.getText(),
                        txtfldPhoneNo.getText(),
                        txtfldEmail.getText(),
                        txtfldSSS.getText(),
                        txtfldPhilhealth.getText(),
                        txtfldTIN.getText(),
                        txtfldPagibig.getText(),
                        txtfldSupervisor.getText(),
                        birthday,
                        txtfldBasicSalary.getText(),
                        txtfldRiceSubsidy.getText(),
                        txtfldPhoneAllowance.getText(),
                        txtfldClothingAllowance.getText()
                );

            if (!validation.isValid()) {
                validation.showErrors();
                return;
            }

            EmployeeDetailsEntity emp =
                    employeeService.getEmployeeEntityByNumber(empNo);

            if (emp == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Employee not found in database.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            emp.setLastName(txtfldLastName.getText().trim());
            emp.setFirstName(txtfldFirstName.getText().trim());
            emp.setBirthday(birthday);
            emp.setPhoneNumber(txtfldPhoneNo.getText().trim());

            if (emp.getEmployee() != null) {
                emp.getEmployee().setSssNumber(txtfldSSS.getText().trim());
                emp.getEmployee().setPhilhealthNumber(txtfldPhilhealth.getText().trim());
                emp.getEmployee().setTinNumber(txtfldTIN.getText().trim());
                emp.getEmployee().setPagibigNumber(txtfldPagibig.getText().trim());
            }

            employeeService.updateEmployeeEntity(emp);
            
            employeeService.updateGovernmentIds(
                    empNo,
                    txtfldSSS.getText().trim(),
                    txtfldPhilhealth.getText().trim(),
                    txtfldTIN.getText().trim(),
                    txtfldPagibig.getText().trim()
            );

            employeeService.updateCompensationAndAllowances(
                    empNo,
                    Double.parseDouble(txtfldBasicSalary.getText().replace(",", "").trim()),
                    Double.parseDouble(txtfldRiceSubsidy.getText().replace(",", "").trim()),
                    Double.parseDouble(txtfldPhoneAllowance.getText().replace(",", "").trim()),
                    Double.parseDouble(txtfldClothingAllowance.getText().replace(",", "").trim())
            );

            JOptionPane.showMessageDialog(
                    this,
                    "Employee updated successfully."
            );
            refreshEmployeeTable();

            tblEmp.clearSelection();
            btnUpdateEmployee.setEnabled(false);
            btnDeleteEmployee.setEnabled(false);

            FormUtils.lockAllFields(pnlUpdateEmployeeDetails, false);
            FormUtils.disableUpdateButtons(btnSaveUpdate, btnCancelUpdate);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error saving employee data to database: "
                            + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Salary and allowances must be valid numbers.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }                  

    private void btnCancelUpdateActionPerformed(java.awt.event.ActionEvent evt) {                                                
        FormUtils.lockAllFields(pnlUpdateEmployeeDetails, false);

        int selectedRow = tblEmp.getSelectedRow();

        if (selectedRow != -1) {
            String selectedEmpNo = tblEmp.getValueAt(selectedRow, 0).toString();

            try {
                EmployeeDetailsEntity emp =
                        employeeService.getEmployeeEntityByNumber(selectedEmpNo);

                if (emp != null) {
                    txtfldEmpNo.setText(String.valueOf(emp.getEmployeeNumber()));
                    txtfldLastName.setText(emp.getLastName());
                    txtfldFirstName.setText(emp.getFirstName());

                    if (emp.getBirthday() != null) {
                        jDateChooser1.setDate(java.sql.Date.valueOf(emp.getBirthday()));
                    } else {
                        jDateChooser1.setDate(null);
                    }

                    txtfldPhoneNo.setText(emp.getPhoneNumber());

                    if (emp.getEmployee() != null) {
                        txtfldSSS.setText(emp.getEmployee().getSssNumber());
                        txtfldPhilhealth.setText(emp.getEmployee().getPhilhealthNumber());
                        txtfldTIN.setText(emp.getEmployee().getTinNumber());
                        txtfldPagibig.setText(emp.getEmployee().getPagibigNumber());

                        if (emp.getEmployee().getEmploymentStatus() != null) {
                            cmbbxStatus.setSelectedItem(
                                    emp.getEmployee()
                                            .getEmploymentStatus()
                                            .getEmploymentStatusName()
                            );
                        }

                        if (emp.getEmployee().getPosition() != null) {
                            cmbbxPosition.setSelectedItem(
                                    emp.getEmployee()
                                            .getPosition()
                                            .getPositionName()
                            );
                        }
                    }
                }

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Error reading employee data from database: "
                                + ex.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }

        FormUtils.disableUpdateButtons(btnSaveUpdate, btnCancelUpdate);
        btnUpdateEmployee.setEnabled(true);
    
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlEmployeeList = new javax.swing.JPanel();
        pnlEmployeeListHeader = new javax.swing.JPanel();
        lblEmployeeListLogo = new javax.swing.JLabel();
        btnDeleteEmployee = new javax.swing.JButton();
        btnUpdateEmployee = new javax.swing.JButton();
        btnAddNewEmployee = new javax.swing.JButton();
        pnlQuickActions = new javax.swing.JPanel();
        lblQuickActions2 = new javax.swing.JLabel();
        scrlPaneEmployeeListTable = new javax.swing.JScrollPane();
        tblEmp = new javax.swing.JTable();
        pnlUpdateEmployeeDetails = new javax.swing.JPanel();
        btnSaveUpdate = new javax.swing.JButton();
        btnCancelUpdate = new javax.swing.JButton();
        lblStatus = new javax.swing.JLabel();
        lblAsterisk11 = new javax.swing.JLabel();
        lblPosition = new javax.swing.JLabel();
        lblEmpNo = new javax.swing.JLabel();
        txtfldEmpNo = new javax.swing.JTextField();
        lblLastName = new javax.swing.JLabel();
        lblAsterisk1 = new javax.swing.JLabel();
        txtfldLastName = new javax.swing.JTextField();
        lblFirstName = new javax.swing.JLabel();
        lblAsterisk2 = new javax.swing.JLabel();
        txtfldFirstName = new javax.swing.JTextField();
        lblBirthday = new javax.swing.JLabel();
        lblAsterisk3 = new javax.swing.JLabel();
        lblAsterisk10 = new javax.swing.JLabel();
        lblPhoneNo = new javax.swing.JLabel();
        lblAsterisk19 = new javax.swing.JLabel();
        lblAsterisk5 = new javax.swing.JLabel();
        txtfldPhoneNo = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        lblAsterisk20 = new javax.swing.JLabel();
        txtfldEmail = new javax.swing.JTextField();
        lblSSS = new javax.swing.JLabel();
        lblAsterisk6 = new javax.swing.JLabel();
        txtfldSSS = new javax.swing.JTextField();
        lblPhilhealth = new javax.swing.JLabel();
        lblAsterisk7 = new javax.swing.JLabel();
        txtfldPhilhealth = new javax.swing.JTextField();
        lblTIN = new javax.swing.JLabel();
        lblAsterisk8 = new javax.swing.JLabel();
        txtfldTIN = new javax.swing.JTextField();
        lblPagibig = new javax.swing.JLabel();
        lblAsterisk9 = new javax.swing.JLabel();
        txtfldPagibig = new javax.swing.JTextField();
        lblSupervisor = new javax.swing.JLabel();
        lblAsterisk12 = new javax.swing.JLabel();
        txtfldSupervisor = new javax.swing.JTextField();
        txtfldRiceSubsidy = new javax.swing.JTextField();
        lblPhoneAllowance = new javax.swing.JLabel();
        txtfldPhoneAllowance = new javax.swing.JTextField();
        lblAsterisk13 = new javax.swing.JLabel();
        lblClothingAllowance = new javax.swing.JLabel();
        lblAsterisk15 = new javax.swing.JLabel();
        txtfldClothingAllowance = new javax.swing.JTextField();
        lblAsterisk14 = new javax.swing.JLabel();
        lblAsterisk16 = new javax.swing.JLabel();
        lblAsterisk17 = new javax.swing.JLabel();
        lblAsterisk18 = new javax.swing.JLabel();
        lblGrossSemiMonthly = new javax.swing.JLabel();
        txtfldGrossSemiMonthly = new javax.swing.JTextField();
        lblHourlyRate = new javax.swing.JLabel();
        txtfldHourlyRate = new javax.swing.JTextField();
        lblBasicSalary = new javax.swing.JLabel();
        txtfldBasicSalary = new javax.swing.JTextField();
        lblRiceSubsidy = new javax.swing.JLabel();
        cmbbxStatus = new javax.swing.JComboBox<>();
        cmbbxPosition = new javax.swing.JComboBox<>();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        lblStreet = new javax.swing.JLabel();
        lblAsterisk21 = new javax.swing.JLabel();
        txtfldStreet = new javax.swing.JTextField();
        lblBarangay = new javax.swing.JLabel();
        lblAsterisk22 = new javax.swing.JLabel();
        txtfldBarangay = new javax.swing.JTextField();
        lblCity = new javax.swing.JLabel();
        lblAsterisk23 = new javax.swing.JLabel();
        txtfldCity = new javax.swing.JTextField();
        lblProvince = new javax.swing.JLabel();
        lblAsterisk24 = new javax.swing.JLabel();
        txtfldProvince = new javax.swing.JTextField();
        lblZipcode = new javax.swing.JLabel();
        lblAsterisk25 = new javax.swing.JLabel();
        txtfldZipcode = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEmployeeList.setBackground(new java.awt.Color(238, 238, 238));

        pnlEmployeeListHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlEmployeeListHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblEmployeeListLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblEmployeeListLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeListLogo.setText("Employee List");

        javax.swing.GroupLayout pnlEmployeeListHeaderLayout = new javax.swing.GroupLayout(pnlEmployeeListHeader);
        pnlEmployeeListHeader.setLayout(pnlEmployeeListHeaderLayout);
        pnlEmployeeListHeaderLayout.setHorizontalGroup(
            pnlEmployeeListHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEmployeeListHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblEmployeeListLogo)
                .addContainerGap(626, Short.MAX_VALUE))
        );
        pnlEmployeeListHeaderLayout.setVerticalGroup(
            pnlEmployeeListHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlEmployeeListHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblEmployeeListLogo)
                .addGap(22, 22, 22))
        );

        btnDeleteEmployee.setBackground(new java.awt.Color(101, 148, 177));
        btnDeleteEmployee.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeleteEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteEmployee.setText("Delete");

        btnUpdateEmployee.setBackground(new java.awt.Color(101, 148, 177));
        btnUpdateEmployee.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateEmployee.setText("Update");

        btnAddNewEmployee.setBackground(new java.awt.Color(101, 148, 177));
        btnAddNewEmployee.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAddNewEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnAddNewEmployee.setText("New Employee");
        btnAddNewEmployee.setMaximumSize(new java.awt.Dimension(81, 22));
        btnAddNewEmployee.setMinimumSize(new java.awt.Dimension(81, 22));

        pnlQuickActions.setBackground(new java.awt.Color(33, 60, 81));

        lblQuickActions2.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblQuickActions2.setForeground(new java.awt.Color(255, 255, 255));
        lblQuickActions2.setText("QUICK ACTIONS");

        javax.swing.GroupLayout pnlQuickActionsLayout = new javax.swing.GroupLayout(pnlQuickActions);
        pnlQuickActions.setLayout(pnlQuickActionsLayout);
        pnlQuickActionsLayout.setHorizontalGroup(
            pnlQuickActionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuickActionsLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(lblQuickActions2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlQuickActionsLayout.setVerticalGroup(
            pnlQuickActionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuickActionsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQuickActions2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblEmp.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 153), 1, true));
        tblEmp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Employee Number", "Last Name", "First Name", "SSS Number", "PhilHealth Number", "TIN", "Pag-ibig Number"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblEmp.setGridColor(new java.awt.Color(255, 204, 153));
        tblEmp.getTableHeader().setReorderingAllowed(false);
        scrlPaneEmployeeListTable.setViewportView(tblEmp);

        javax.swing.GroupLayout pnlEmployeeListLayout = new javax.swing.GroupLayout(pnlEmployeeList);
        pnlEmployeeList.setLayout(pnlEmployeeListLayout);
        pnlEmployeeListLayout.setHorizontalGroup(
            pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                .addGroup(pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                        .addGroup(pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(pnlEmployeeListHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(btnAddNewEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnUpdateEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnDeleteEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlQuickActions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                                .addComponent(scrlPaneEmployeeListTable, javax.swing.GroupLayout.PREFERRED_SIZE, 871, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        pnlEmployeeListLayout.setVerticalGroup(
            pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlEmployeeListLayout.createSequentialGroup()
                .addComponent(pnlEmployeeListHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlQuickActions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlEmployeeListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddNewEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdateEmployee)
                    .addComponent(btnDeleteEmployee))
                .addGap(18, 18, 18)
                .addComponent(scrlPaneEmployeeListTable, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlUpdateEmployeeDetails.setBackground(new java.awt.Color(238, 238, 238));

        btnSaveUpdate.setBackground(new java.awt.Color(101, 148, 177));
        btnSaveUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSaveUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnSaveUpdate.setText("Save");

        btnCancelUpdate.setBackground(new java.awt.Color(101, 148, 177));
        btnCancelUpdate.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCancelUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelUpdate.setText("Cancel");

        lblStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStatus.setText("Status");

        lblAsterisk11.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk11.setText("*");

        lblPosition.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPosition.setText("Position");

        lblEmpNo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEmpNo.setText("Employee No.");

        lblLastName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLastName.setText("Last Name");

        lblAsterisk1.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk1.setText("*");

        lblFirstName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFirstName.setText("First Name");

        lblAsterisk2.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk2.setText("*");

        lblBirthday.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBirthday.setText("Birthday");

        lblAsterisk3.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk3.setText("*");

        lblAsterisk10.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk10.setText("*");

        lblPhoneNo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhoneNo.setText("Phone Number");

        lblAsterisk19.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk19.setText("*");

        lblAsterisk5.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk5.setText("*");

        lblEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEmail.setText("Email Address");

        lblAsterisk20.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk20.setText("*");

        lblSSS.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSSS.setText("SSS Number");

        lblAsterisk6.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk6.setText("*");

        lblPhilhealth.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhilhealth.setText("PhilHealth Number");

        lblAsterisk7.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk7.setText("*");

        lblTIN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTIN.setText("TIN Number");

        lblAsterisk8.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk8.setText("*");

        lblPagibig.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPagibig.setText("Pag-ibig Number");

        lblAsterisk9.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk9.setText("*");

        lblSupervisor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSupervisor.setText("Immediate Supervisor");

        lblAsterisk12.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk12.setText("*");

        txtfldSupervisor.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        lblPhoneAllowance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhoneAllowance.setText("Phone Allowance");

        lblAsterisk13.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk13.setText("*");

        lblClothingAllowance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblClothingAllowance.setText("Clothing Allowance");

        lblAsterisk15.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk15.setText("*");

        lblAsterisk14.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk14.setText("*");

        lblAsterisk16.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk16.setText("*");

        lblAsterisk17.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk17.setText("*");

        lblAsterisk18.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk18.setText("*");

        lblGrossSemiMonthly.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblGrossSemiMonthly.setText("Gross Semi-Monthly");

        lblHourlyRate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHourlyRate.setText("Hourly Rate");

        lblBasicSalary.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBasicSalary.setText("Basic Salary");

        lblRiceSubsidy.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRiceSubsidy.setText("Rice Subsidy");

        cmbbxStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cmbbxPosition.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblStreet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblStreet.setText("Street");

        lblAsterisk21.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk21.setText("*");

        lblBarangay.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBarangay.setText("Barangay");

        lblAsterisk22.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk22.setText("*");

        lblCity.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCity.setText("City");

        lblAsterisk23.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk23.setText("*");

        lblProvince.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblProvince.setText("Province");

        lblAsterisk24.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk24.setText("*");

        lblZipcode.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblZipcode.setText("Zip code");

        lblAsterisk25.setForeground(new java.awt.Color(204, 0, 0));
        lblAsterisk25.setText("*");

        javax.swing.GroupLayout pnlUpdateEmployeeDetailsLayout = new javax.swing.GroupLayout(pnlUpdateEmployeeDetails);
        pnlUpdateEmployeeDetails.setLayout(pnlUpdateEmployeeDetailsLayout);
        pnlUpdateEmployeeDetailsLayout.setHorizontalGroup(
            pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                                .addComponent(lblLastName)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                                .addComponent(lblEmpNo)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk19, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(46, 46, 46)
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(txtfldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                                .addComponent(lblPhoneNo)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                                .addComponent(lblEmail)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lblAsterisk20, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(35, 35, 35)
                                        .addComponent(txtfldEmail))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addGap(162, 162, 162)
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldFirstName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jDateChooser1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(18, 18, 18)
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblPhoneAllowance)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk15, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblClothingAllowance)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk16, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblGrossSemiMonthly)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk17, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblHourlyRate)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk18, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblBasicSalary)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk13, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblRiceSubsidy)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk14, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(txtfldClothingAllowance, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldGrossSemiMonthly, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldHourlyRate, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtfldPhoneAllowance, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtfldRiceSubsidy)
                                        .addComponent(txtfldBasicSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(btnSaveUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnCancelUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblFirstName)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblBirthday)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addComponent(lblStreet)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk21, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addComponent(lblBarangay)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk22, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addComponent(lblCity)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk23, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(73, 73, 73)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtfldCity)
                            .addComponent(txtfldBarangay)
                            .addComponent(txtfldStreet))
                        .addGap(216, 216, 216))
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                    .addComponent(lblSupervisor)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(lblAsterisk12)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtfldSupervisor))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                            .addComponent(lblPosition)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(lblAsterisk11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                            .addComponent(lblStatus)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(lblAsterisk10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(81, 81, 81)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cmbbxPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(cmbbxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblSSS)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addComponent(lblPhilhealth)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk7))
                                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                                .addComponent(lblTIN)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(lblAsterisk8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(lblPagibig, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblAsterisk9, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(35, 35, 35)
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtfldTIN)
                                    .addComponent(txtfldPagibig, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtfldSSS)
                                    .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addComponent(lblProvince)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk24, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(78, 78, 78)
                                .addComponent(txtfldProvince, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addComponent(lblZipcode)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAsterisk25, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(78, 78, 78)
                                .addComponent(txtfldZipcode, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        pnlUpdateEmployeeDetailsLayout.setVerticalGroup(
            pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveUpdate)
                    .addComponent(btnCancelUpdate))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblBasicSalary)
                            .addComponent(txtfldBasicSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk13))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblRiceSubsidy)
                                .addComponent(lblAsterisk14))
                            .addComponent(txtfldRiceSubsidy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldPhoneAllowance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPhoneAllowance)
                            .addComponent(lblAsterisk15))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldClothingAllowance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblClothingAllowance)
                            .addComponent(lblAsterisk16)))
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEmpNo)
                            .addComponent(txtfldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk19))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblLastName)
                            .addComponent(txtfldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk1))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblFirstName)
                            .addComponent(txtfldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk2))
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblBirthday)
                                    .addComponent(lblAsterisk3)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblPhoneNo)
                            .addComponent(txtfldPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk5))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEmail)
                            .addComponent(txtfldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAsterisk20)))
                    .addGroup(pnlUpdateEmployeeDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldGrossSemiMonthly, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblGrossSemiMonthly)
                            .addComponent(lblAsterisk17))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtfldHourlyRate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHourlyRate)
                            .addComponent(lblAsterisk18))))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblStreet)
                    .addComponent(txtfldStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk21))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBarangay)
                    .addComponent(txtfldBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk22))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCity)
                    .addComponent(txtfldCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk23))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblProvince)
                    .addComponent(txtfldProvince, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk24))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblZipcode)
                    .addComponent(txtfldZipcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk25))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSSS)
                    .addComponent(txtfldSSS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk6))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPhilhealth)
                    .addComponent(txtfldPhilhealth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk7))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTIN)
                    .addComponent(txtfldTIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk8))
                .addGap(14, 14, 14)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPagibig)
                    .addComponent(txtfldPagibig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAsterisk9))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAsterisk10)
                    .addComponent(lblStatus)
                    .addComponent(cmbbxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPosition)
                    .addComponent(lblAsterisk11)
                    .addComponent(cmbbxPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateEmployeeDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtfldSupervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSupervisor)
                    .addComponent(lblAsterisk12))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 874, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlUpdateEmployeeDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(pnlUpdateEmployeeDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(pnlEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new EmployeeListDashboard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddNewEmployee;
    private javax.swing.JButton btnCancelUpdate;
    private javax.swing.JButton btnDeleteEmployee;
    private javax.swing.JButton btnSaveUpdate;
    private javax.swing.JButton btnUpdateEmployee;
    private javax.swing.JComboBox<String> cmbbxPosition;
    private javax.swing.JComboBox<String> cmbbxStatus;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblAsterisk1;
    private javax.swing.JLabel lblAsterisk10;
    private javax.swing.JLabel lblAsterisk11;
    private javax.swing.JLabel lblAsterisk12;
    private javax.swing.JLabel lblAsterisk13;
    private javax.swing.JLabel lblAsterisk14;
    private javax.swing.JLabel lblAsterisk15;
    private javax.swing.JLabel lblAsterisk16;
    private javax.swing.JLabel lblAsterisk17;
    private javax.swing.JLabel lblAsterisk18;
    private javax.swing.JLabel lblAsterisk19;
    private javax.swing.JLabel lblAsterisk2;
    private javax.swing.JLabel lblAsterisk20;
    private javax.swing.JLabel lblAsterisk21;
    private javax.swing.JLabel lblAsterisk22;
    private javax.swing.JLabel lblAsterisk23;
    private javax.swing.JLabel lblAsterisk24;
    private javax.swing.JLabel lblAsterisk25;
    private javax.swing.JLabel lblAsterisk3;
    private javax.swing.JLabel lblAsterisk5;
    private javax.swing.JLabel lblAsterisk6;
    private javax.swing.JLabel lblAsterisk7;
    private javax.swing.JLabel lblAsterisk8;
    private javax.swing.JLabel lblAsterisk9;
    private javax.swing.JLabel lblBarangay;
    private javax.swing.JLabel lblBasicSalary;
    private javax.swing.JLabel lblBirthday;
    private javax.swing.JLabel lblCity;
    private javax.swing.JLabel lblClothingAllowance;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEmpNo;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblEmployeeListLogo;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblGrossSemiMonthly;
    private javax.swing.JLabel lblHourlyRate;
    private javax.swing.JLabel lblLastName;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPagibig;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblPhilhealth;
    private javax.swing.JLabel lblPhoneAllowance;
    private javax.swing.JLabel lblPhoneNo;
    private javax.swing.JLabel lblPosition;
    private javax.swing.JLabel lblProvince;
    private javax.swing.JLabel lblQuickActions2;
    private javax.swing.JLabel lblRiceSubsidy;
    private javax.swing.JLabel lblSSS;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblStreet;
    private javax.swing.JLabel lblSupervisor;
    private javax.swing.JLabel lblTIN;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JLabel lblZipcode;
    private javax.swing.JPanel pnlEmployeeList;
    private javax.swing.JPanel pnlEmployeeListHeader;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlQuickActions;
    private javax.swing.JPanel pnlUpdateEmployeeDetails;
    private javax.swing.JScrollPane scrlPaneEmployeeListTable;
    private javax.swing.JTable tblEmp;
    private javax.swing.JTextField txtfldBarangay;
    private javax.swing.JTextField txtfldBasicSalary;
    private javax.swing.JTextField txtfldCity;
    private javax.swing.JTextField txtfldClothingAllowance;
    private javax.swing.JTextField txtfldEmail;
    private javax.swing.JTextField txtfldEmpNo;
    private javax.swing.JTextField txtfldFirstName;
    private javax.swing.JTextField txtfldGrossSemiMonthly;
    private javax.swing.JTextField txtfldHourlyRate;
    private javax.swing.JTextField txtfldLastName;
    private javax.swing.JTextField txtfldPagibig;
    private javax.swing.JTextField txtfldPhilhealth;
    private javax.swing.JTextField txtfldPhoneAllowance;
    private javax.swing.JTextField txtfldPhoneNo;
    private javax.swing.JTextField txtfldProvince;
    private javax.swing.JTextField txtfldRiceSubsidy;
    private javax.swing.JTextField txtfldSSS;
    private javax.swing.JTextField txtfldStreet;
    private javax.swing.JTextField txtfldSupervisor;
    private javax.swing.JTextField txtfldTIN;
    private javax.swing.JTextField txtfldZipcode;
    // End of variables declaration//GEN-END:variables
}
