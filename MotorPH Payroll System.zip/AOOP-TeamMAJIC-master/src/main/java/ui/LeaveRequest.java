package ui;

import java.io.IOException;
import ui.helpers.RBACController;
import utils.WindowUtils;
import utils.DateTimeUtils;
import service.LoginService;
import service.LeaveService;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Displays the employee leave request screen.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class LeaveRequest extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LeaveRequest.class.getName());

    private final LeaveService leaveService =
        new LeaveService();

    public LeaveRequest() {
        initComponents();

        lblLeaveRequest.setEnabled(false);

        loadLeaveSummary();
        loadLeaveRequestHistory();
        initializeFilters();
        loadLeaveHistoryTable();

        WindowUtils.applyStandardWindowConfig(this, "Leave Request");

    RBACController.applyPermissions(
        lblUserManagement,
        lblPayroll,
        lblEmployeeList,
        lblLeaveManagement,
        lblAnalytics

    );

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
        try {
            new DailyTimeRecord().setVisible(true);
        } catch (IOException ex) {
            System.getLogger(MainDashboard.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });

         WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveManagement, () -> {
            new LeaveManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(LeaveRequest.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

            LoginService.getInstance().logout();

            new LogOutFrame().setVisible(true);

        });
    }

    private void loadLeaveRequestHistory() {

    DefaultTableModel model = (DefaultTableModel) tblLeaveRequestHistory.getModel();
    model.setRowCount(0);

    try {

        String loggedEmployee =
                LoginService.getInstance().getLoggedInEmployeeNumber();

        List<String[]> rows = leaveService.getAllLeaves();

        for (int i = 1; i < rows.size(); i++) {

            String[] data = rows.get(i);

            String employeeNo = data[1];

            if (employeeNo.equals(loggedEmployee)) {

                model.addRow(new Object[]{
                        data[0],
                        data[2],
                        data[3],
                        data[4],
                        data[5]
                });
            }
        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this,
                "Error loading leave history:\n" + e.getMessage());
    }
}

   private void loadLeaveSummary() {

    try {

        String employeeNo = LoginService.getInstance().getLoggedInEmployeeNumber();

        int totalCredits = 15;

        int[] summary = leaveService.getLeaveSummary(employeeNo);

        int usedCredits = summary[0];
        int pendingLeaves = summary[1];

        int remainingBalance = leaveService.getRemainingLeaveBalance(employeeNo);

        txtfldTotalCredits.setText(String.valueOf(totalCredits));
        txtfldUsedCredits.setText(String.valueOf(usedCredits));
        txtfldPendingLeaves.setText(String.valueOf(pendingLeaves));
        txtfldRemainingBalance.setText(String.valueOf(remainingBalance));

    }
    catch (Exception e) {

        javax.swing.JOptionPane.showMessageDialog(this,
                "Error loading leave summary:\n" + e.getMessage());
    }

   btnNewLeaveRequest.addActionListener(e -> {

    LeaveRequestForm form = new LeaveRequestForm();

    form.setVisible(true);

});
}

   private void initializeFilters() {

    cmbStatusFilter.setModel(new javax.swing.DefaultComboBoxModel<>(
            new String[]{"All", "Pending", "Approved", "Rejected"}
    ));

    cmbStatusFilter.setSelectedItem("All");

    int currentYear = LocalDate.now().getYear();

    cmbYearFilter.setModel(new javax.swing.DefaultComboBoxModel<>(
            new String[]{
                    String.valueOf(currentYear),
                    String.valueOf(currentYear - 1),
                    String.valueOf(currentYear - 2)
            }
    ));

    cmbYearFilter.setSelectedItem(String.valueOf(currentYear));

    cmbStatusFilter.addActionListener(e -> loadLeaveHistoryTable());
    cmbYearFilter.addActionListener(e -> loadLeaveHistoryTable());
}

   private void loadLeaveHistoryTable() {

    try {

        String selectedStatus = cmbStatusFilter.getSelectedItem().toString();
        String selectedYear = cmbYearFilter.getSelectedItem().toString();

        String employeeNo =
                LoginService.getInstance().getLoggedInEmployeeNumber();

        List<String[]> rows = leaveService.getAllLeaves();

        DefaultTableModel model =
                (DefaultTableModel) tblLeaveRequestHistory.getModel();

        model.setRowCount(0);

        for (int i = 1; i < rows.size(); i++) {

            String[] data = rows.get(i);

            if (data.length < 9) continue;

            String leaveID = data[0];
            String empNo = data[1];
            String startDate = data[2];
            String endDate = data[3];
            String duration = data[4];
            String status = data[5];

            if (!empNo.equals(employeeNo)) continue;

            LocalDate start =
        LocalDate.parse(startDate, DateTimeUtils.DATE_FORMAT);

            if (!startDate.startsWith(selectedYear)) {

                if (start.getYear() != Integer.parseInt(selectedYear)) {
                    continue;
                }
            }

            if (!selectedStatus.equals("All") &&
                    !status.equalsIgnoreCase(selectedStatus)) {
                continue;
            }

            model.addRow(new Object[]{
                    leaveID,
                    startDate,
                    endDate,
                    duration,
                    status
            });
        }

    } catch (Exception e) {

        javax.swing.JOptionPane.showMessageDialog(this,
                "Error loading leave history:\n" + e.getMessage());
    }
}

     /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeaveRequest = new javax.swing.JPanel();
        pnlLeaveRequestHeader = new javax.swing.JPanel();
        lblLeaveRequuest = new javax.swing.JLabel();
        pnlLeaveCreditsSummary = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        lblClockIn = new javax.swing.JLabel();
        lblBreak = new javax.swing.JLabel();
        lblWorkingHours = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        lblRemainingBalance = new javax.swing.JLabel();
        txtfldUsedCredits = new javax.swing.JTextField();
        txtfldTotalCredits = new javax.swing.JTextField();
        txtfldRemainingBalance = new javax.swing.JTextField();
        txtfldPendingLeaves = new javax.swing.JTextField();
        btnNewLeaveRequest = new javax.swing.JButton();
        scrlPaneLeaveRequest = new javax.swing.JScrollPane();
        tblLeaveRequestHistory = new javax.swing.JTable();
        lblChoosePayPeriod = new javax.swing.JLabel();
        cmbStatusFilter = new javax.swing.JComboBox<>();
        cmbYearFilter = new javax.swing.JComboBox<>();
        lblChoosePayPeriod1 = new javax.swing.JLabel();
        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlLeaveRequest.setBackground(new java.awt.Color(238, 238, 238));

        pnlLeaveRequestHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeaveRequestHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblLeaveRequuest.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblLeaveRequuest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequuest.setText("Leave Request");

        javax.swing.GroupLayout pnlLeaveRequestHeaderLayout = new javax.swing.GroupLayout(pnlLeaveRequestHeader);
        pnlLeaveRequestHeader.setLayout(pnlLeaveRequestHeaderLayout);
        pnlLeaveRequestHeaderLayout.setHorizontalGroup(
            pnlLeaveRequestHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeaveRequestHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblLeaveRequuest)
                .addContainerGap(629, Short.MAX_VALUE))
        );
        pnlLeaveRequestHeaderLayout.setVerticalGroup(
            pnlLeaveRequestHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeaveRequestHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblLeaveRequuest)
                .addGap(22, 22, 22))
        );

        pnlLeaveCreditsSummary.setBackground(new java.awt.Color(255, 255, 255));
        pnlLeaveCreditsSummary.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator2.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblClockIn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockIn.setText("Total Credits");

        lblBreak.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblBreak.setText("Used Credits");

        lblWorkingHours.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblWorkingHours.setText("Pending");

        jSeparator4.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblRemainingBalance.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblRemainingBalance.setText("Remaining Balance");

        txtfldUsedCredits.setEditable(false);
        txtfldUsedCredits.setBackground(new java.awt.Color(255, 255, 255));
        txtfldUsedCredits.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldUsedCredits.setForeground(new java.awt.Color(33, 60, 81));
        txtfldUsedCredits.setAutoscrolls(false);
        txtfldUsedCredits.setBorder(null);
        txtfldUsedCredits.setFocusable(false);
        txtfldUsedCredits.setRequestFocusEnabled(false);
        txtfldUsedCredits.setVerifyInputWhenFocusTarget(false);

        txtfldTotalCredits.setEditable(false);
        txtfldTotalCredits.setBackground(new java.awt.Color(255, 255, 255));
        txtfldTotalCredits.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldTotalCredits.setForeground(new java.awt.Color(33, 60, 81));
        txtfldTotalCredits.setAutoscrolls(false);
        txtfldTotalCredits.setBorder(null);
        txtfldTotalCredits.setFocusable(false);
        txtfldTotalCredits.setRequestFocusEnabled(false);
        txtfldTotalCredits.setVerifyInputWhenFocusTarget(false);

        txtfldRemainingBalance.setEditable(false);
        txtfldRemainingBalance.setBackground(new java.awt.Color(255, 255, 255));
        txtfldRemainingBalance.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldRemainingBalance.setForeground(new java.awt.Color(33, 60, 81));
        txtfldRemainingBalance.setAutoscrolls(false);
        txtfldRemainingBalance.setBorder(null);
        txtfldRemainingBalance.setFocusable(false);
        txtfldRemainingBalance.setRequestFocusEnabled(false);
        txtfldRemainingBalance.setVerifyInputWhenFocusTarget(false);

        txtfldPendingLeaves.setEditable(false);
        txtfldPendingLeaves.setBackground(new java.awt.Color(255, 255, 255));
        txtfldPendingLeaves.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldPendingLeaves.setForeground(new java.awt.Color(33, 60, 81));
        txtfldPendingLeaves.setAutoscrolls(false);
        txtfldPendingLeaves.setBorder(null);
        txtfldPendingLeaves.setFocusable(false);
        txtfldPendingLeaves.setRequestFocusEnabled(false);
        txtfldPendingLeaves.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlLeaveCreditsSummaryLayout = new javax.swing.GroupLayout(pnlLeaveCreditsSummary);
        pnlLeaveCreditsSummary.setLayout(pnlLeaveCreditsSummaryLayout);
        pnlLeaveCreditsSummaryLayout.setHorizontalGroup(
            pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClockIn)
                    .addComponent(txtfldTotalCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBreak)
                    .addComponent(txtfldUsedCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(77, 77, 77)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblWorkingHours)
                    .addComponent(txtfldPendingLeaves, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRemainingBalance)
                    .addComponent(txtfldRemainingBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        pnlLeaveCreditsSummaryLayout.setVerticalGroup(
            pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlLeaveCreditsSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                        .addComponent(lblRemainingBalance)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldRemainingBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                        .addComponent(lblWorkingHours)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldPendingLeaves, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                        .addComponent(lblBreak)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldUsedCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlLeaveCreditsSummaryLayout.createSequentialGroup()
                        .addComponent(lblClockIn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldTotalCredits, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator3, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                    .addComponent(jSeparator2)
                    .addComponent(jSeparator4))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        btnNewLeaveRequest.setBackground(new java.awt.Color(101, 148, 177));
        btnNewLeaveRequest.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNewLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        btnNewLeaveRequest.setText("+ New Leave Request");

        tblLeaveRequestHistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Leave ID", "Start Date", "End Date", "Duration in Days", "Result"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scrlPaneLeaveRequest.setViewportView(tblLeaveRequestHistory);
        if (tblLeaveRequestHistory.getColumnModel().getColumnCount() > 0) {
            tblLeaveRequestHistory.getColumnModel().getColumn(0).setResizable(false);
            tblLeaveRequestHistory.getColumnModel().getColumn(1).setResizable(false);
            tblLeaveRequestHistory.getColumnModel().getColumn(2).setResizable(false);
            tblLeaveRequestHistory.getColumnModel().getColumn(3).setResizable(false);
            tblLeaveRequestHistory.getColumnModel().getColumn(4).setResizable(false);
        }

        lblChoosePayPeriod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChoosePayPeriod.setText("Filter by Status:");

        cmbStatusFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cmbYearFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblChoosePayPeriod1.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChoosePayPeriod1.setText("Choose Year:");

        javax.swing.GroupLayout pnlLeaveRequestLayout = new javax.swing.GroupLayout(pnlLeaveRequest);
        pnlLeaveRequest.setLayout(pnlLeaveRequestLayout);
        pnlLeaveRequestLayout.setHorizontalGroup(
            pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveRequestLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLeaveRequestLayout.createSequentialGroup()
                        .addComponent(lblChoosePayPeriod)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbStatusFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblChoosePayPeriod1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbYearFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlLeaveRequestLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnNewLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlLeaveRequestHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(scrlPaneLeaveRequest, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(pnlLeaveCreditsSummary, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlLeaveRequestLayout.setVerticalGroup(
            pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveRequestLayout.createSequentialGroup()
                .addComponent(pnlLeaveRequestHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnNewLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlLeaveCreditsSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbYearFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblChoosePayPeriod1))
                    .addGroup(pnlLeaveRequestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbStatusFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblChoosePayPeriod)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(scrlPaneLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LeaveRequest().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNewLeaveRequest;
    private javax.swing.JComboBox<String> cmbStatusFilter;
    private javax.swing.JComboBox<String> cmbYearFilter;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblBreak;
    private javax.swing.JLabel lblChoosePayPeriod;
    private javax.swing.JLabel lblChoosePayPeriod1;
    private javax.swing.JLabel lblClockIn;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLeaveRequuest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblRemainingBalance;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JLabel lblWorkingHours;
    private javax.swing.JPanel pnlLeaveCreditsSummary;
    private javax.swing.JPanel pnlLeaveRequest;
    private javax.swing.JPanel pnlLeaveRequestHeader;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JScrollPane scrlPaneLeaveRequest;
    private javax.swing.JTable tblLeaveRequestHistory;
    private javax.swing.JTextField txtfldPendingLeaves;
    private javax.swing.JTextField txtfldRemainingBalance;
    private javax.swing.JTextField txtfldTotalCredits;
    private javax.swing.JTextField txtfldUsedCredits;
    // End of variables declaration//GEN-END:variables
}
