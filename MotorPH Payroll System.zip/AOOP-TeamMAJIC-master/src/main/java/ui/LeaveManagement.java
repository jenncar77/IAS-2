package ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.io.IOException;
import java.time.Year;
import java.util.List;
import javax.swing.*;
import service.LoginService;
import service.LeaveService;
import ui.helpers.RBACController;
import utils.WindowUtils;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * Displays the leave management dashboard for HR workflows.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class LeaveManagement extends JFrame {

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(LeaveManagement.class.getName());

    private final LeaveService leaveService =
        new LeaveService();

    private void setupTableButtons() {
        tblLeaveRequests.getColumn("Action").setCellRenderer(new ActionButtonRenderer());
        tblLeaveRequests.getColumn("Action").setCellEditor(new ActionButtonEditor(new JCheckBox()));
    }

    public LeaveManagement() {

        initComponents();

        TableColumn actionColumn = tblLeaveRequests.getColumnModel().getColumn(6);

        actionColumn.setCellRenderer(new ActionButtonRenderer());
        actionColumn.setCellEditor(new ActionButtonEditor(new JCheckBox()));

        tblLeaveRequests.setRowHeight(60);

        tblLeaveRequests.getColumnModel().getColumn(0).setPreferredWidth(100); // LeaveID
        tblLeaveRequests.getColumnModel().getColumn(1).setPreferredWidth(100); // Employee No.
        tblLeaveRequests.getColumnModel().getColumn(2).setPreferredWidth(100); // Start Date
        tblLeaveRequests.getColumnModel().getColumn(3).setPreferredWidth(100); // End Date
        tblLeaveRequests.getColumnModel().getColumn(4).setPreferredWidth(100); // Duration (Days)
        tblLeaveRequests.getColumnModel().getColumn(5).setPreferredWidth(100); // Status
        tblLeaveRequests.getColumnModel().getColumn(6).setPreferredWidth(200); // Action

        // Center column headers
        ((javax.swing.table.DefaultTableCellRenderer)
                tblLeaveRequests.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        // Center table cell contents
        javax.swing.table.DefaultTableCellRenderer centerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        tblLeaveRequests.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        tblLeaveRequests.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);

        lblLeaveManagement.setEnabled(false);

        initializeFilters();
        cmbStatusFilter.addActionListener(e -> loadLeaveTable());
        cmbYearFilter.addActionListener(e -> loadLeaveTable());
        setupTableButtons();
        loadLeaveTable();
        loadLeaveStats();

        // Apply standard window configuration
        WindowUtils.applyStandardWindowConfig(this, "Leave Management");

        // Apply RBAC
        RBACController.applyPermissions(
                lblUserManagement,
                lblPayroll,
                lblEmployeeList,
                lblLeaveManagement,
                lblAnalytics

        );

        WindowUtils.applyClickableLabelAction(lblDTR, () -> {
            try {
                new DailyTimeRecord().setVisible(true);
            } catch (IOException ex) {
                logger.log(java.util.logging.Level.SEVERE, null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblTimesheet, () -> {
            new Timesheet().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLeaveRequest, () -> {
            new LeaveRequest().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblMyPayslip, () -> {
            try {
                new MyPayslip().setVisible(true);
            } catch (Exception ex) {
                System.getLogger(LeaveManagement.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
            }
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblEmployeeList, () -> {
            new EmployeeListDashboard().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblPayroll, () -> {
            new Payroll().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblUserManagement, () -> {
            new UserManagement().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblDashboard, () -> {
            new MainDashboard().setVisible(true);
            dispose();
        });
        
        WindowUtils.applyClickableLabelAction(lblAnalytics, () -> {
            new Analytics().setVisible(true);
            dispose();
        });

        WindowUtils.applyClickableLabelAction(lblLogout, () -> {

        // Open logout confirmation ONLY (no logout yet)
        LogOutFrame.showLogoutFrame(this);
        });
    }

    private void initializeFilters() {

        cmbStatusFilter.setModel(new DefaultComboBoxModel<>(
                new String[]{"All", "Pending", "Approved", "Rejected"}
        ));

        int year = Year.now().getValue();

        cmbYearFilter.setModel(new DefaultComboBoxModel<>(
                new String[]{
                        String.valueOf(year),
                        String.valueOf(year - 1),
                        String.valueOf(year - 2)
                }
        ));

        cmbYearFilter.setSelectedItem(String.valueOf(year));
    }

    private void loadLeaveTable() {

        try {

            DefaultTableModel model =
                    (DefaultTableModel) tblLeaveRequests.getModel();

            model.setRowCount(0);

            String statusFilter = cmbStatusFilter.getSelectedItem().toString();
            String yearFilter = cmbYearFilter.getSelectedItem().toString();

            List<String[]> data = leaveService.getAllLeaves();

            for (int i = 1; i < data.size(); i++) {
                String[] row = data.get(i);
                String leaveID = row[0];
                String empNo = row[1];
                String startDate = row[2];
                String endDate = row[3];
                String duration = row[4];
                String status = row[5];

                String year = startDate.substring(6, 10);

                if (!year.equals(yearFilter)) continue;

                if (!statusFilter.equals("All") &&
                        !status.equalsIgnoreCase(statusFilter))
                    continue;

                model.addRow(new Object[]{
                        leaveID,
                        empNo,
                        startDate,
                        endDate,
                        duration,
                        status,
                        "Action"
                });
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading leave requests:\n" + e.getMessage()
            );
        }
    }

    private void approveLeave(int row) {

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Approve this leave request?",
                "Confirm Approval",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        updateLeaveStatus(row, "Approved", "N/A");
    }

    private void rejectLeave(int row) {

        String reason = JOptionPane.showInputDialog(
                this,
                "Enter reason for rejection:"
        );

        if (reason == null || reason.trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Rejection reason is required."
            );

            return;
        }

        updateLeaveStatus(row, "Rejected", reason);
    }

    private void updateLeaveStatus(int row, String status, String reason) {

    try {

        String leaveID =
                tblLeaveRequests.getValueAt(row, 0).toString();

        String approver =
                LoginService.getInstance().getLoggedInEmployeeNumber();

        System.out.println("Updating LeaveID: " + leaveID); // DEBUG

        leaveService.updateLeaveStatus(leaveID, status, reason, approver);

        JOptionPane.showMessageDialog(
                this,
                "Leave request updated successfully."
        );

        loadLeaveTable();
        loadLeaveStats();

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
                this,
                "Error updating leave request:\n" + e.getMessage()
        );
    }
}

    private void loadLeaveStats() {

    try {

        int[] stats = leaveService.getCurrentMonthLeaveStats();

        txtfldRequests.setText(String.valueOf(stats[0]));
        txtfldApproved.setText(String.valueOf(stats[1]));
        txtfldRejected.setText(String.valueOf(stats[2]));

    } catch (Exception e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading leave statistics:\n" + e.getMessage()
        );
    }
}

    class ActionButtonRenderer extends JPanel implements TableCellRenderer {

    JButton approve = new JButton("Approve");
    JButton reject = new JButton("Reject");
    JLabel statusLabel = new JLabel("", SwingConstants.CENTER);

    public ActionButtonRenderer() {

        setLayout(new FlowLayout(FlowLayout.CENTER,5,0));

        approve.setBackground(new Color(0,153,0));
        approve.setForeground(Color.WHITE);

        reject.setBackground(new Color(204,0,0));
        reject.setForeground(Color.WHITE);
    }

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected,
            boolean hasFocus, int row, int column) {

        removeAll();

        String status = table.getValueAt(row,5).toString(); // STATUS COLUMN

        if(status.equalsIgnoreCase("Pending")){

            add(approve);
            add(reject);

        } else {

            statusLabel.setText(status);

            if(status.equalsIgnoreCase("Approved")){
                statusLabel.setForeground(new Color(0,153,0));
            }

            if(status.equalsIgnoreCase("Rejected")){
                statusLabel.setForeground(Color.RED);
            }

            add(statusLabel);
        }

        return this;
    }
}

    class ActionButtonEditor extends DefaultCellEditor {

    JPanel panel = new JPanel();
    JButton approve = new JButton("Approve");
    JButton reject = new JButton("Reject");

    int row;   // store clicked row

    public ActionButtonEditor(JCheckBox checkBox) {
        super(checkBox);

        panel.setLayout(new FlowLayout());

        approve.setBackground(new Color(0,153,0));
        approve.setForeground(Color.WHITE);

        reject.setBackground(new Color(204,0,0));
        reject.setForeground(Color.WHITE);

        panel.add(approve);
        panel.add(reject);

        approve.addActionListener(e -> {
            fireEditingStopped();
            approveLeave(row);
        });

        reject.addActionListener(e -> {
            fireEditingStopped();
            rejectLeave(row);
        });
    }

    @Override
    public Component getTableCellEditorComponent(
            JTable table, Object value,
            boolean isSelected, int row, int column) {

        this.row = row;
        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return "";
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLeftSideMenu = new javax.swing.JPanel();
        lblMotorPHLogo = new javax.swing.JLabel();
        lblDashboard = new javax.swing.JLabel();
        lblTimesheet = new javax.swing.JLabel();
        lblDTR = new javax.swing.JLabel();
        lblLeaveRequest = new javax.swing.JLabel();
        lblMyPayslip = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        lblUserManagement = new javax.swing.JLabel();
        lblPayroll = new javax.swing.JLabel();
        lblEmployeeList = new javax.swing.JLabel();
        lblLeaveManagement = new javax.swing.JLabel();
        lblAnalytics = new javax.swing.JLabel();
        pnlLeaveManagement = new javax.swing.JPanel();
        pnlMyPayslipHeader = new javax.swing.JPanel();
        lblLeaveManagementLogo = new javax.swing.JLabel();
        scrlPaneTimeSheet = new javax.swing.JScrollPane();
        tblLeaveRequests = new javax.swing.JTable();
        lblChoosePayPeriod = new javax.swing.JLabel();
        cmbStatusFilter = new javax.swing.JComboBox<>();
        lblChoosePayPeriod1 = new javax.swing.JLabel();
        cmbYearFilter = new javax.swing.JComboBox<>();
        pnlLeaveManagementDashboard = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        lblClockIn = new javax.swing.JLabel();
        lblClockOut = new javax.swing.JLabel();
        lblWorkingHours = new javax.swing.JLabel();
        txtfldRejected = new javax.swing.JTextField();
        txtfldRequests = new javax.swing.JTextField();
        txtfldApproved = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        pnlLeftSideMenu.setBackground(new java.awt.Color(33, 60, 81));
        pnlLeftSideMenu.setForeground(new java.awt.Color(255, 255, 255));

        lblMotorPHLogo.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        lblMotorPHLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblMotorPHLogo.setText("MotorPH");

        lblDashboard.setBackground(new java.awt.Color(102, 102, 102));
        lblDashboard.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDashboard.setForeground(new java.awt.Color(255, 255, 255));
        lblDashboard.setText("Dashboard");

        lblTimesheet.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblTimesheet.setForeground(new java.awt.Color(255, 255, 255));
        lblTimesheet.setText("Timesheet");

        lblDTR.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblDTR.setForeground(new java.awt.Color(255, 255, 255));
        lblDTR.setText("Daily Time Record");

        lblLeaveRequest.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveRequest.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveRequest.setText("Leave Request");

        lblMyPayslip.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblMyPayslip.setForeground(new java.awt.Color(255, 255, 255));
        lblMyPayslip.setText("My Payslip");

        lblLogout.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log out");

        lblUserManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblUserManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblUserManagement.setText("User Management");

        lblPayroll.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblPayroll.setForeground(new java.awt.Color(255, 255, 255));
        lblPayroll.setText("Payroll");

        lblEmployeeList.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblEmployeeList.setForeground(new java.awt.Color(255, 255, 255));
        lblEmployeeList.setText("Employee List");

        lblLeaveManagement.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblLeaveManagement.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagement.setText("Leave Management");

        lblAnalytics.setFont(new java.awt.Font("Georgia", 1, 12)); // NOI18N
        lblAnalytics.setForeground(new java.awt.Color(255, 255, 255));
        lblAnalytics.setText("Analytics");

        javax.swing.GroupLayout pnlLeftSideMenuLayout = new javax.swing.GroupLayout(pnlLeftSideMenu);
        pnlLeftSideMenu.setLayout(pnlLeftSideMenuLayout);
        pnlLeftSideMenuLayout.setHorizontalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLeftSideMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMotorPHLogo)
                .addGap(85, 85, 85))
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAnalytics)
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblUserManagement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblPayroll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblEmployeeList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveManagement, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDTR, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                        .addComponent(lblTimesheet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLeaveRequest, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblMyPayslip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        pnlLeftSideMenuLayout.setVerticalGroup(
            pnlLeftSideMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeftSideMenuLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblMotorPHLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(lblDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblDTR, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblTimesheet, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblMyPayslip, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(lblUserManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblPayroll, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEmployeeList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lblAnalytics)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlLeaveManagement.setBackground(new java.awt.Color(238, 238, 238));

        pnlMyPayslipHeader.setBackground(new java.awt.Color(33, 60, 81));
        pnlMyPayslipHeader.setPreferredSize(new java.awt.Dimension(884, 142));

        lblLeaveManagementLogo.setFont(new java.awt.Font("Sitka Text", 1, 30)); // NOI18N
        lblLeaveManagementLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaveManagementLogo.setText("Leave Management");

        javax.swing.GroupLayout pnlMyPayslipHeaderLayout = new javax.swing.GroupLayout(pnlMyPayslipHeader);
        pnlMyPayslipHeader.setLayout(pnlMyPayslipHeaderLayout);
        pnlMyPayslipHeaderLayout.setHorizontalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(lblLeaveManagementLogo)
                .addContainerGap(566, Short.MAX_VALUE))
        );
        pnlMyPayslipHeaderLayout.setVerticalGroup(
            pnlMyPayslipHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMyPayslipHeaderLayout.createSequentialGroup()
                .addContainerGap(97, Short.MAX_VALUE)
                .addComponent(lblLeaveManagementLogo)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout pnlLeaveManagementLayout = new javax.swing.GroupLayout(pnlLeaveManagement);
        pnlLeaveManagement.setLayout(pnlLeaveManagementLayout);
        pnlLeaveManagementLayout.setHorizontalGroup(
            pnlLeaveManagementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveManagementLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 910, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlLeaveManagementLayout.setVerticalGroup(
            pnlLeaveManagementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlMyPayslipHeader, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
        );

        tblLeaveRequests.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 153), 1, true));
        tblLeaveRequests.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "LeaveID", "Employee No.", "Start Date", "End Date", "Duration (Days)", "Status", "Action"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblLeaveRequests.setGridColor(new java.awt.Color(255, 204, 153));
        tblLeaveRequests.getTableHeader().setReorderingAllowed(false);
        scrlPaneTimeSheet.setViewportView(tblLeaveRequests);
        if (tblLeaveRequests.getColumnModel().getColumnCount() > 0) {
            tblLeaveRequests.getColumnModel().getColumn(0).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(1).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(2).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(3).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(4).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(5).setResizable(false);
            tblLeaveRequests.getColumnModel().getColumn(6).setResizable(false);
        }

        lblChoosePayPeriod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChoosePayPeriod.setText("Filter by Status:");

        cmbStatusFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblChoosePayPeriod1.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblChoosePayPeriod1.setText("Choose Year:");

        cmbYearFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        pnlLeaveManagementDashboard.setBackground(new java.awt.Color(255, 255, 255));
        pnlLeaveManagementDashboard.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(101, 148, 177)));

        jSeparator2.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setBackground(new java.awt.Color(206, 206, 206));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblClockIn.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockIn.setText("Requests");

        lblClockOut.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblClockOut.setText("Approved");

        lblWorkingHours.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblWorkingHours.setText("Rejected");

        txtfldRejected.setEditable(false);
        txtfldRejected.setBackground(new java.awt.Color(255, 255, 255));
        txtfldRejected.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldRejected.setForeground(new java.awt.Color(33, 60, 81));
        txtfldRejected.setAutoscrolls(false);
        txtfldRejected.setBorder(null);
        txtfldRejected.setFocusable(false);
        txtfldRejected.setRequestFocusEnabled(false);
        txtfldRejected.setVerifyInputWhenFocusTarget(false);

        txtfldRequests.setEditable(false);
        txtfldRequests.setBackground(new java.awt.Color(255, 255, 255));
        txtfldRequests.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldRequests.setForeground(new java.awt.Color(33, 60, 81));
        txtfldRequests.setAutoscrolls(false);
        txtfldRequests.setBorder(null);
        txtfldRequests.setFocusable(false);
        txtfldRequests.setRequestFocusEnabled(false);
        txtfldRequests.setVerifyInputWhenFocusTarget(false);

        txtfldApproved.setEditable(false);
        txtfldApproved.setBackground(new java.awt.Color(255, 255, 255));
        txtfldApproved.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        txtfldApproved.setForeground(new java.awt.Color(33, 60, 81));
        txtfldApproved.setAutoscrolls(false);
        txtfldApproved.setBorder(null);
        txtfldApproved.setFocusable(false);
        txtfldApproved.setRequestFocusEnabled(false);
        txtfldApproved.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout pnlLeaveManagementDashboardLayout = new javax.swing.GroupLayout(pnlLeaveManagementDashboard);
        pnlLeaveManagementDashboard.setLayout(pnlLeaveManagementDashboardLayout);
        pnlLeaveManagementDashboardLayout.setHorizontalGroup(
            pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveManagementDashboardLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClockIn)
                    .addComponent(txtfldRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(135, 135, 135)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblClockOut)
                    .addComponent(txtfldApproved, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(137, 137, 137)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblWorkingHours)
                    .addComponent(txtfldRejected, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(97, Short.MAX_VALUE))
        );
        pnlLeaveManagementDashboardLayout.setVerticalGroup(
            pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLeaveManagementDashboardLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlLeaveManagementDashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLeaveManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblWorkingHours)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldRejected, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlLeaveManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblClockIn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlLeaveManagementDashboardLayout.createSequentialGroup()
                        .addComponent(lblClockOut)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtfldApproved, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(pnlLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(scrlPaneTimeSheet, javax.swing.GroupLayout.PREFERRED_SIZE, 895, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlLeaveManagementDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblChoosePayPeriod)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbStatusFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblChoosePayPeriod1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbYearFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlLeftSideMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlLeaveManagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlLeaveManagementDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbStatusFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblChoosePayPeriod)
                    .addComponent(cmbYearFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblChoosePayPeriod1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrlPaneTimeSheet, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LeaveManagement().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbStatusFilter;
    private javax.swing.JComboBox<String> cmbYearFilter;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lblAnalytics;
    private javax.swing.JLabel lblChoosePayPeriod;
    private javax.swing.JLabel lblChoosePayPeriod1;
    private javax.swing.JLabel lblClockIn;
    private javax.swing.JLabel lblClockOut;
    private javax.swing.JLabel lblDTR;
    private javax.swing.JLabel lblDashboard;
    private javax.swing.JLabel lblEmployeeList;
    private javax.swing.JLabel lblLeaveManagement;
    private javax.swing.JLabel lblLeaveManagementLogo;
    private javax.swing.JLabel lblLeaveRequest;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JLabel lblMotorPHLogo;
    private javax.swing.JLabel lblMyPayslip;
    private javax.swing.JLabel lblPayroll;
    private javax.swing.JLabel lblTimesheet;
    private javax.swing.JLabel lblUserManagement;
    private javax.swing.JLabel lblWorkingHours;
    private javax.swing.JPanel pnlLeaveManagement;
    private javax.swing.JPanel pnlLeaveManagementDashboard;
    private javax.swing.JPanel pnlLeftSideMenu;
    private javax.swing.JPanel pnlMyPayslipHeader;
    private javax.swing.JScrollPane scrlPaneTimeSheet;
    private javax.swing.JTable tblLeaveRequests;
    private javax.swing.JTextField txtfldApproved;
    private javax.swing.JTextField txtfldRejected;
    private javax.swing.JTextField txtfldRequests;
    // End of variables declaration//GEN-END:variables
}
