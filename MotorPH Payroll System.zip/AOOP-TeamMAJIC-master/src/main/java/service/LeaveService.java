package service;

import entity.EmployeeEntity;
import entity.LeaveApprovalStatusEntity;
import entity.LeaveRequestEntity;
import entity.LeaveTypeEntity;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.LeaveRequest;
import repository.LeaveRepository;
import utils.DateTimeUtils;
import repository.LeaveTypeRepository;

/**
 * Coordinates leave-request business operations and validations.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class LeaveService {

    private final LeaveRepository leaveRepository;
    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveService() {
        this.leaveRepository = new LeaveRepository();
        this.leaveTypeRepository = new LeaveTypeRepository();
    }

    public LeaveService(String leaveCsvPath) {
        this.leaveRepository = new LeaveRepository();
        this.leaveTypeRepository = new LeaveTypeRepository();
    }

    public List<LeaveTypeEntity> getAllLeaveTypes() {
        return leaveTypeRepository.findAll();
    }
    
    public List<String[]> getAllLeaves() throws IOException {
        return convertToRows(leaveRepository.findAll());
    }

    public void fileLeave(LeaveRequest leave) throws IOException {

        String employeeNo = leave.getEmployeeNumber();

        int remainingCredits = getRemainingLeaveBalance(employeeNo);

        if (remainingCredits <= 0) {
            throw new IllegalArgumentException(
                    "You have no remaining leave credits."
            );
        }

        if (leave.getLeaveDays() > remainingCredits) {
            throw new IllegalArgumentException(
                    "Leave request exceeds your remaining leave credits."
            );
        }

        List<LeaveRequestEntity> existingLeaves =
                leaveRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNo)
                );

        for (LeaveRequestEntity existing : existingLeaves) {

            String status = "";

            if (existing.getApprovalStatus() != null) {
                status = existing.getApprovalStatus()
                        .getLeaveApprovalStatusName();
            }

            if (status.equalsIgnoreCase("Rejected")) {
                continue;
            }

            LocalDate existingStart = existing.getStartDate();
            LocalDate existingEnd = existing.getEndDate();

            LocalDate newStart = leave.getStartDate();
            LocalDate newEnd = leave.getEndDate();

            if (!newStart.isAfter(existingEnd)
                    && !newEnd.isBefore(existingStart)) {

                throw new IllegalArgumentException(
                        "You already filed a leave request that overlaps these dates."
                );
            }
        }

        LeaveRequestEntity entity = new LeaveRequestEntity();

        EmployeeEntity employee = new EmployeeEntity();
        employee.setEmployeeNumber(Integer.parseInt(employeeNo));

        LeaveTypeEntity leaveType = null;
        for (LeaveTypeEntity type : leaveTypeRepository.findAll()) {
            if (type.getLeaveTypeName().equalsIgnoreCase(leave.getReason())) {
                leaveType = type;
                break;
            }
        }

        if (leaveType == null) {
            throw new IllegalArgumentException("Invalid leave type selected.");
        }

        LeaveApprovalStatusEntity status = new LeaveApprovalStatusEntity();
        status.setLeaveApprovalStatusId(1); // Pending

        entity.setEmployee(employee);
        entity.setLeaveType(leaveType);
        entity.setLeaveApprovalStatus(status);
        entity.setStartDate(leave.getStartDate());
        entity.setEndDate(leave.getEndDate());
        entity.setApprovedBy(null);
        entity.setApprovalDate(null);

        leaveRepository.save(entity);
    }

    public void approveLeave(LeaveRequest leave) {
        leave.approve();
    }

    public void rejectLeave(LeaveRequest leave) {
        leave.reject();
    }

    public int[] getLeaveSummary(String employeeNo) throws IOException {

        int usedCredits = 0;
        int pendingLeaves = 0;

        List<LeaveRequestEntity> leaves =
                leaveRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNo)
                );

        for (LeaveRequestEntity leave : leaves) {

            String status = "";

            if (leave.getApprovalStatus() != null) {
                status = leave.getApprovalStatus()
                        .getLeaveApprovalStatusName();
            }

            int leaveDays = calculateLeaveDays(
                    leave.getStartDate(),
                    leave.getEndDate()
            );

            if (status.equalsIgnoreCase("Approved")) {
                usedCredits += leaveDays;
            }

            if (status.equalsIgnoreCase("Pending")) {
                pendingLeaves += leaveDays;
            }
        }

        return new int[]{usedCredits, pendingLeaves};
    }

    public int getRemainingLeaveBalance(String employeeNo) throws IOException {

        int totalCredits = 15;

        int[] summary = getLeaveSummary(employeeNo);
        int usedCredits = summary[0];
        int pendingLeaves = summary[1];

        return Math.max(0, totalCredits - usedCredits - pendingLeaves);
    }

    public int calculateLeaveDays(LocalDate start, LocalDate end) {

        int workingDays = 0;
        LocalDate date = start;

        while (!date.isAfter(end)) {

            DayOfWeek day = date.getDayOfWeek();

            if (day != DayOfWeek.SATURDAY
                    && day != DayOfWeek.SUNDAY) {
                workingDays++;
            }

            date = date.plusDays(1);
        }

        return workingDays;
    }

    public void updateLeaveStatus(
            String leaveID,
            String status,
            String reason,
            String approver
    ) throws Exception {

        int leaveRequestId = parseLeaveId(leaveID);

        LeaveRequestEntity leave =
                leaveRepository.findById(leaveRequestId);

        if (leave == null) {
            throw new IllegalArgumentException(
                    "No matching leave request found: " + leaveID
            );
        }

        LeaveApprovalStatusEntity statusEntity =
                new LeaveApprovalStatusEntity();

        if (status.equalsIgnoreCase("Pending")) {
            statusEntity.setLeaveApprovalStatusId(1);
        } else if (status.equalsIgnoreCase("Approved")) {
            statusEntity.setLeaveApprovalStatusId(2);
        } else if (status.equalsIgnoreCase("Rejected")) {
            statusEntity.setLeaveApprovalStatusId(3);
        } else {
            throw new IllegalArgumentException("Invalid leave status.");
        }

        leave.setLeaveApprovalStatus(statusEntity);

        if (!status.equalsIgnoreCase("Pending")) {

            leave.setApprovalDate(LocalDate.now());

            String loggedInEmployeeNo =
            LoginService.getInstance().getLoggedInEmployeeNumber();

            int userAccountId =
            LoginService.getInstance().getLoggedInUserAccountId();

            leave.setApprovedBy(userAccountId);
        }

        leaveRepository.update(leave);
    }

    public int[] getCurrentMonthLeaveStats() throws Exception {

        int pending = 0;
        int approved = 0;
        int rejected = 0;

        List<LeaveRequestEntity> leaves = leaveRepository.findAll();

        LocalDate now = LocalDate.now();

        for (LeaveRequestEntity leave : leaves) {

            if (leave.getStartDate() == null) {
                continue;
            }

            if (leave.getStartDate().getMonthValue()
                    != now.getMonthValue()) {
                continue;
            }

            if (leave.getStartDate().getYear() != now.getYear()) {
                continue;
            }

            String status = "";

            if (leave.getApprovalStatus() != null) {
                status = leave.getApprovalStatus()
                        .getLeaveApprovalStatusName();
            }

            if (status.equalsIgnoreCase("Pending")) {
                pending++;
            }

            if (status.equalsIgnoreCase("Approved")) {
                approved++;
            }

            if (status.equalsIgnoreCase("Rejected")) {
                rejected++;
            }
        }

        return new int[]{pending, approved, rejected};
    }

    private List<String[]> convertToRows(
            List<LeaveRequestEntity> leaves) {

        List<String[]> rows = new ArrayList<>();

        rows.add(new String[]{
            "Leave ID",
            "Employee Number",
            "Start Date",
            "End Date",
            "Leave Days",
            "Status",
            "Approved By",
            "Reason",
            "Approval Date"
        });

        for (LeaveRequestEntity leave : leaves) {
            rows.add(convertToRow(leave));
        }

        return rows;
    }

    private String[] convertToRow(LeaveRequestEntity leave) {

        String leaveId = "LR"
                + String.format("%03d", leave.getLeaveRequestId());

        String employeeNumber = "";

        if (leave.getEmployee() != null) {
            employeeNumber = String.valueOf(
                    leave.getEmployee().getEmployeeNumber()
            );
        }

        String status = "";

        if (leave.getApprovalStatus() != null) {
            status = leave.getApprovalStatus()
                    .getLeaveApprovalStatusName();
        }

        int leaveDays = calculateLeaveDays(
                leave.getStartDate(),
                leave.getEndDate()
        );

        return new String[]{
            leaveId,
            employeeNumber,
            leave.getStartDate() != null
                    ? leave.getStartDate().format(DateTimeUtils.DATE_FORMAT)
                    : "",
            leave.getEndDate() != null
                    ? leave.getEndDate().format(DateTimeUtils.DATE_FORMAT)
                    : "",
            String.valueOf(leaveDays),
            status,
            leave.getApprovedBy() != null
                    ? String.valueOf(leave.getApprovedBy())
                    : "",
            "",
            leave.getApprovedDate() != null
                    ? leave.getApprovedDate().format(DateTimeUtils.DATE_FORMAT)
                    : ""
        };
    }

    private int parseLeaveId(String leaveID) {
        return Integer.parseInt(
                leaveID.replace("LR", "").trim()
        );
    }
}