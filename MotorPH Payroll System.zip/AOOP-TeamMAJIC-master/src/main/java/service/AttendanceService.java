package service;

import entity.AttendanceEntity;
import entity.EmployeeEntity;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import repository.AttendanceRepository;

/**
 * Coordinates attendance-related business operations.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;

    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("H:mm");

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public AttendanceService() {
        this.attendanceRepository = new AttendanceRepository();
    }

    public AttendanceService(String attendanceCsvPath) {
        this.attendanceRepository = new AttendanceRepository();
    }

    public List<String[]> getAttendanceByEmployee(String employeeNumber)
            throws IOException {

        List<AttendanceEntity> attendanceList =
                attendanceRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNumber)
                );

        return convertToRows(attendanceList);
    }

    public List<String[]> getAttendanceByEmployee(
            String employeeNumber,
            LocalDate startDate,
            LocalDate endDate) throws IOException {

        List<String[]> rows = getAttendanceByEmployee(employeeNumber);
        List<String[]> filteredRows = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;

        for (String[] row : rows) {
            if (row.length < 4 || row[3] == null || row[3].isBlank()) {
                continue;
            }

            LocalDate attendanceDate = LocalDate.parse(row[3], formatter);

            if (!attendanceDate.isBefore(startDate)
                    && !attendanceDate.isAfter(endDate)) {
                filteredRows.add(row);
            }
        }

        return filteredRows;
    }

    public List<String[]> getAllAttendance() throws IOException {
        return convertToRows(attendanceRepository.findAll());
    }

    public String calculateWorkingHours(LocalTime clockIn, LocalTime clockOut) {
        long minutes = Duration.between(clockIn, clockOut).toMinutes();

        if (minutes >= 300) {
            minutes -= 60;
        }

        if (minutes < 0) {
            minutes = 0;
        }

        long hours = minutes / 60;
        long remainingMinutes = minutes % 60;

        return String.format("%02d:%02d", hours, remainingMinutes);
    }

    public String calculateWorkingHours(String clockIn, String clockOut) {
        LocalTime in = LocalTime.parse(clockIn, TIME_FORMAT);
        LocalTime out = LocalTime.parse(clockOut, TIME_FORMAT);

        return calculateWorkingHours(in, out);
    }

    public String[] findAttendance(String employeeNumber, String date)
            throws IOException {

        LocalDate attendanceDate =
                LocalDate.parse(date, DATE_FORMAT);

        AttendanceEntity attendance =
                attendanceRepository.findByEmployeeNumberAndDate(
                        Integer.parseInt(employeeNumber),
                        attendanceDate
                );

        if (attendance == null) {
            return null;
        }

        return convertToRow(attendance);
    }

    public AttendanceEntity findAttendanceEntity(
            String employeeNumber,
            String date) throws IOException {

        return attendanceRepository.findByEmployeeNumberAndDate(
                Integer.parseInt(employeeNumber),
                LocalDate.parse(date, DATE_FORMAT)
        );
    }

    public void clockIn(
            String employeeNumber,
            String date,
            String clockInTime) throws IOException {

        AttendanceEntity attendance = new AttendanceEntity();

        EmployeeEntity employee =
                attendanceRepository.findEmployeeByNumber(
                        Integer.parseInt(employeeNumber)
                );

        if (employee == null) {
            throw new IllegalArgumentException("Employee not found.");
        }

        attendance.setEmployee(employee);
        attendance.setAttendanceDate(LocalDate.parse(date, DATE_FORMAT));
        attendance.setLogin(LocalTime.parse(clockInTime, TIME_FORMAT));

        attendanceRepository.save(attendance);
    }

    public void clockIn(String[] row) throws IOException {

        AttendanceEntity attendance = new AttendanceEntity();

        EmployeeEntity employee =
                attendanceRepository.findEmployeeByNumber(
                        Integer.parseInt(row[0])
                );

        if (employee == null) {
            throw new IllegalArgumentException("Employee not found.");
        }

        attendance.setEmployee(employee);
        attendance.setAttendanceDate(LocalDate.parse(row[3], DATE_FORMAT));
        attendance.setLogin(LocalTime.parse(row[4], TIME_FORMAT));

        if (row.length > 5 && row[5] != null && !row[5].isBlank()) {
            attendance.setLogout(LocalTime.parse(row[5], TIME_FORMAT));
        }

        attendanceRepository.save(attendance);
    }

    public void clockOut(String employeeNo, String date, String clockOut)
            throws IOException {

        AttendanceEntity attendance =
                attendanceRepository.findByEmployeeNumberAndDate(
                        Integer.parseInt(employeeNo),
                        LocalDate.parse(date, DATE_FORMAT)
                );

        if (attendance == null) {
            throw new IllegalArgumentException("Attendance record not found.");
        }

        attendance.setLogout(LocalTime.parse(clockOut, TIME_FORMAT));

        attendanceRepository.update(attendance);
    }

    private List<String[]> convertToRows(List<AttendanceEntity> attendanceList) {
        List<String[]> rows = new ArrayList<>();

        for (AttendanceEntity attendance : attendanceList) {
            rows.add(convertToRow(attendance));
        }

        return rows;
    }

    private String[] convertToRow(AttendanceEntity attendance) {
        String employeeNumber = "";
        String lastName = "";
        String firstName = "";

        if (attendance.getEmployee() != null) {
            employeeNumber =
                    String.valueOf(attendance.getEmployee().getEmployeeNumber());

            if (attendance.getEmployee().getEmployeeDetails() != null) {
                lastName = safe(
                        attendance.getEmployee()
                                .getEmployeeDetails()
                                .getLastName()
                );

                firstName = safe(
                        attendance.getEmployee()
                                .getEmployeeDetails()
                                .getFirstName()
                );
            }
        }

        return new String[]{
            employeeNumber,
            lastName,
            firstName,
            attendance.getAttendanceDate() != null
                    ? attendance.getAttendanceDate().toString()
                    : "",
            attendance.getLogin() != null
                    ? attendance.getLogin().toString()
                    : "",
            attendance.getLogout() != null
                    ? attendance.getLogout().toString()
                    : ""
        };
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
