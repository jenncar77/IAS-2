package service;

import entity.AllowanceEntity;
import entity.CompensationEntity;
import entity.DeductionEntity;
import entity.PayPeriodEntity;
import entity.OvertimeEntity;
import entity.PayrollEntity;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import model.PayrollSummary;
import repository.AllowanceRepository;
import repository.CompensationRepository;
import repository.DeductionRepository;
import repository.PayPeriodRepository;
import repository.OvertimeRepository;
import repository.PayrollRepository;


/**
 * Coordinates payroll computations for the payroll screens.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class PayrollService {

    private final PayrollRepository payrollRepository;
    private final AllowanceRepository allowanceRepository;
    private final DeductionRepository deductionRepository;
    private final CompensationRepository compensationRepository;
    private final PayPeriodRepository payPeriodRepository;
    private final OvertimeRepository overtimeRepository;

    private static final DateTimeFormatter MONTH_FORMAT =
            DateTimeFormatter.ofPattern("MMMM yyyy");

    public PayrollService() {
        this.payrollRepository = new PayrollRepository();
        this.allowanceRepository = new AllowanceRepository();
        this.deductionRepository = new DeductionRepository();
        this.compensationRepository = new CompensationRepository();
        this.payPeriodRepository = new PayPeriodRepository();
        this.overtimeRepository = new OvertimeRepository();
    }

    public PayrollService(String employeeCsvPath, String attendanceCsvPath) {
        this();
    }

    public PayrollSummary computePayroll(String employeeNumber)
            throws IOException {

        int empNo = Integer.parseInt(employeeNumber);

        List<PayrollEntity> payrolls =
                payrollRepository.findByEmployeeNumber(empNo);

        if (payrolls == null || payrolls.isEmpty()) {
            throw new IllegalArgumentException(
                    "Payroll record not found for employee: " + employeeNumber
            );
        }

        PayrollEntity payroll = payrolls.get(payrolls.size() - 1);

        return buildPayrollSummary(payroll);
    }

    public PayrollSummary getPayrollSummary(
            String employeeNumber,
            String monthYear,
            String cutoff
    ) throws Exception {

        PayPeriodEntity payPeriod = findPayPeriod(monthYear, cutoff);

        if (payPeriod == null) {
            throw new IllegalArgumentException(
                    "Pay period not found for " + monthYear + " " + cutoff
            );
        }

        List<PayrollEntity> payrolls =
                payrollRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNumber)
                );

        for (PayrollEntity payroll : payrolls) {
            if (payroll.getPayPeriod() != null
                    && payroll.getPayPeriod().getPayPeriodId()
                    == payPeriod.getPayPeriodId()) {

                return buildPayrollSummary(payroll);
            }
        }

        return null;
    }

    public List<PayrollEntity> getPayrollBySelectedPeriod(
            String monthYear,
            String cutoff
    ) throws Exception {

        PayPeriodEntity payPeriod = findPayPeriod(monthYear, cutoff);

        if (payPeriod == null) {
            return new ArrayList<>();
        }

        return payrollRepository.findByPayPeriodId(
                payPeriod.getPayPeriodId()
        );
    }

    private PayrollSummary buildPayrollSummary(PayrollEntity payroll)
            throws IOException {

        BigDecimal monthlySalary = BigDecimal.ZERO;

        if (payroll.getEmployee() != null) {
            CompensationEntity compensation =
                    compensationRepository.findByEmployeeNumber(
                            payroll.getEmployee().getEmployeeNumber()
                    );

            if (compensation != null) {
                monthlySalary = safe(compensation.getMonthlySalary());
            }
        }

        BigDecimal overtimeHours = BigDecimal.ZERO;
        BigDecimal overtimePay = BigDecimal.ZERO;

        if (payroll.getEmployee() != null && payroll.getPayPeriod() != null) {
            List<OvertimeEntity> overtimeRecords =
                    overtimeRepository.findByEmployeeNumberAndDateRange(
                            payroll.getEmployee().getEmployeeNumber(),
                            payroll.getPayPeriod().getStartDate(),
                            payroll.getPayPeriod().getEndDate()
                    );

            BigDecimal hourlyRate = monthlySalary
                    .divide(BigDecimal.valueOf(21), 10, RoundingMode.HALF_UP)
                    .divide(BigDecimal.valueOf(8), 10, RoundingMode.HALF_UP);

            for (OvertimeEntity overtime : overtimeRecords) {
                BigDecimal hours = safe(overtime.getOvertimeHours());
                BigDecimal rateMultiplier = safe(overtime.getOvertimeRate());

                overtimeHours = overtimeHours.add(hours);
                overtimePay = overtimePay.add(
                        hours.multiply(hourlyRate).multiply(rateMultiplier)
                );
            }
        }

        overtimePay = overtimePay.setScale(2, RoundingMode.HALF_UP);

        BigDecimal totalWorkedHours = safe(payroll.getTotalWorkedHours());
        BigDecimal dailyRate = monthlySalary
                .divide(BigDecimal.valueOf(21), 2, RoundingMode.HALF_UP);
        BigDecimal daysWorked = totalWorkedHours
                .divide(BigDecimal.valueOf(8), 2, RoundingMode.HALF_UP);
        BigDecimal regularPay = dailyRate
                .multiply(daysWorked)
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal grossIncome = regularPay
                .add(overtimePay)
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalAllowances = calculateSemiMonthlyAllowances(payroll);
        BigDecimal sss = calculateSss(monthlySalary);
        BigDecimal philHealth = calculatePhilHealth(monthlySalary);
        BigDecimal pagibig = calculatePagibig(monthlySalary);
        BigDecimal tax = calculateWithholdingTax(
                grossIncome,
                sss,
                philHealth,
                pagibig
        );
        BigDecimal totalDeductions = sss
                .add(philHealth)
                .add(pagibig)
                .add(tax)
                .setScale(2, RoundingMode.HALF_UP);
        BigDecimal netPay = grossIncome
                .add(totalAllowances)
                .subtract(totalDeductions)
                .setScale(2, RoundingMode.HALF_UP);

        return new PayrollSummary(
                payroll.getTotalWorkedHours() != null
                        ? payroll.getTotalWorkedHours().doubleValue()
                        : 0,
                overtimeHours.doubleValue(),
                overtimePay.doubleValue(),
                grossIncome.doubleValue(),
                netPay.doubleValue(),
                sss.doubleValue(),
                philHealth.doubleValue(),
                pagibig.doubleValue(),
                tax.doubleValue(),
                totalDeductions.doubleValue(),
                monthlySalary.doubleValue(),
                totalAllowances.doubleValue()
        );
    }

    private BigDecimal calculateSemiMonthlyAllowances(PayrollEntity payroll)
            throws IOException {
        if (payroll.getEmployee() == null) {
            return safe(payroll.getTotalAllowances());
        }

        BigDecimal monthlyAllowanceTotal = BigDecimal.ZERO;

        for (AllowanceEntity allowance : allowanceRepository.findByEmployeeNumber(
                payroll.getEmployee().getEmployeeNumber())) {
            monthlyAllowanceTotal = monthlyAllowanceTotal.add(
                    safe(allowance.getAmount())
            );
        }

        if (monthlyAllowanceTotal.compareTo(BigDecimal.ZERO) == 0) {
            return safe(payroll.getTotalAllowances());
        }

        return monthlyAllowanceTotal
                .divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateSss(BigDecimal monthlySalary) {
        if (monthlySalary.compareTo(BigDecimal.valueOf(3250)) < 0) {
            return BigDecimal.valueOf(67.50).setScale(2, RoundingMode.HALF_UP);
        }

        if (monthlySalary.compareTo(BigDecimal.valueOf(24750)) >= 0) {
            return BigDecimal.valueOf(562.50).setScale(2, RoundingMode.HALF_UP);
        }

        BigDecimal bracketCount = monthlySalary
                .subtract(BigDecimal.valueOf(2750))
                .divideToIntegralValue(BigDecimal.valueOf(500));

        return BigDecimal.valueOf(67.50)
                .add(bracketCount.multiply(BigDecimal.valueOf(11.25)))
                .setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculatePhilHealth(BigDecimal monthlySalary) {
        BigDecimal salaryBase = monthlySalary
                .max(BigDecimal.valueOf(10000))
                .min(BigDecimal.valueOf(60000));

        return salaryBase
                .multiply(BigDecimal.valueOf(0.03))
                .multiply(BigDecimal.valueOf(0.50))
                .divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculatePagibig(BigDecimal monthlySalary) {
        if (monthlySalary.compareTo(BigDecimal.valueOf(1000)) < 0) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }

        BigDecimal monthlyContribution;

        if (monthlySalary.compareTo(BigDecimal.valueOf(1500)) <= 0) {
            monthlyContribution = monthlySalary.multiply(BigDecimal.valueOf(0.01));
        } else {
            monthlyContribution = monthlySalary.multiply(BigDecimal.valueOf(0.02));
        }

        return monthlyContribution
                .min(BigDecimal.valueOf(100))
                .divide(BigDecimal.valueOf(2), 2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateWithholdingTax(
            BigDecimal grossIncome,
            BigDecimal sss,
            BigDecimal philHealth,
            BigDecimal pagibig
    ) {
        BigDecimal taxableIncome = grossIncome
                .subtract(sss)
                .subtract(philHealth)
                .subtract(pagibig)
                .max(BigDecimal.ZERO)
                .setScale(2, RoundingMode.HALF_UP);

        if (taxableIncome.compareTo(BigDecimal.valueOf(10416.50)) <= 0) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }

        if (taxableIncome.compareTo(BigDecimal.valueOf(16666.50)) < 0) {
            return taxableIncome
                    .subtract(BigDecimal.valueOf(10416.50))
                    .multiply(BigDecimal.valueOf(0.20))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        if (taxableIncome.compareTo(BigDecimal.valueOf(33333.50)) < 0) {
            return BigDecimal.valueOf(1250.00)
                    .add(taxableIncome
                            .subtract(BigDecimal.valueOf(16666.50))
                            .multiply(BigDecimal.valueOf(0.25)))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        if (taxableIncome.compareTo(BigDecimal.valueOf(83333.50)) < 0) {
            return BigDecimal.valueOf(5416.50)
                    .add(taxableIncome
                            .subtract(BigDecimal.valueOf(33333.50))
                            .multiply(BigDecimal.valueOf(0.30)))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        if (taxableIncome.compareTo(BigDecimal.valueOf(333333.50)) < 0) {
            return BigDecimal.valueOf(20416.67)
                    .add(taxableIncome
                            .subtract(BigDecimal.valueOf(83333.50))
                            .multiply(BigDecimal.valueOf(0.32)))
                    .setScale(2, RoundingMode.HALF_UP);
        }

        return BigDecimal.valueOf(100416.67)
                .add(taxableIncome
                        .subtract(BigDecimal.valueOf(333333.50))
                        .multiply(BigDecimal.valueOf(0.35)))
                .setScale(2, RoundingMode.HALF_UP);
    }

    private PayPeriodEntity findPayPeriod(String monthYear, String cutoff)
            throws Exception {

        List<PayPeriodEntity> payPeriods = payPeriodRepository.findAll();

        YearMonth selectedMonth =
                YearMonth.parse(monthYear, MONTH_FORMAT);

        for (PayPeriodEntity payPeriod : payPeriods) {
            LocalDate startDate = payPeriod.getStartDate();
            LocalDate endDate = payPeriod.getEndDate();

            if (startDate == null || endDate == null) {
                continue;
            }

            YearMonth periodMonth = YearMonth.from(endDate);

            if (!periodMonth.equals(selectedMonth)) {
                continue;
            }

            if ("1st-15th".equalsIgnoreCase(cutoff)
                    && endDate.getDayOfMonth() == 15) {
                return payPeriod;
            }

            if (cutoff.startsWith("16th")
                    && startDate.getDayOfMonth() == 16) {
                return payPeriod;
            }
        }

        return null;
    }

    public List<PayrollEntity> getPayrollByEmployee(String employeeNumber)
            throws IOException {

        return payrollRepository.findByEmployeeNumber(
                Integer.parseInt(employeeNumber)
        );
    }

    public List<PayrollEntity> getPayrollByPayPeriod(int payPeriodId)
            throws IOException {

        return payrollRepository.findByPayPeriodId(payPeriodId);
    }

    public List<AllowanceEntity> getAllowancesByEmployee(
            String employeeNumber) throws IOException {

        return allowanceRepository.findByEmployeeNumber(
                Integer.parseInt(employeeNumber)
        );
    }

    public List<DeductionEntity> getDeductionsByPayrollId(int payrollId)
            throws IOException {

        return deductionRepository.findByPayrollId(payrollId);
    }

    public CompensationEntity getCompensationByEmployee(
            String employeeNumber) throws IOException {

        return compensationRepository.findByEmployeeNumber(
                Integer.parseInt(employeeNumber)
        );
    }

    public List<PayPeriodEntity> getAllPayPeriods()
            throws IOException {

        return payPeriodRepository.findAll();
    }

    public List<String> getAvailablePayrollMonths() throws Exception {

        List<PayPeriodEntity> payPeriods =
                payPeriodRepository.findAll();

        Set<String> months = new LinkedHashSet<>();

        for (PayPeriodEntity payPeriod : payPeriods) {
            LocalDate date = payPeriod.getEndDate();

            if (date != null) {
                months.add(date.format(MONTH_FORMAT));
            }
        }

        return new ArrayList<>(months);
    }

    public List<Integer> getCutoffsForMonth(String monthYear)
            throws Exception {

        List<PayPeriodEntity> payPeriods =
                payPeriodRepository.findAll();

        List<Integer> cutoffs = new ArrayList<>();

        for (PayPeriodEntity payPeriod : payPeriods) {
            LocalDate endDate = payPeriod.getEndDate();

            if (endDate == null) {
                continue;
            }

            if (endDate.format(MONTH_FORMAT).equals(monthYear)) {
                cutoffs.add(endDate.getDayOfMonth());
            }
        }

        return cutoffs;
    }

    public Map<String, Set<Integer>> getMonthCutoffs()
            throws Exception {

        Map<String, Set<Integer>> monthCutoffs =
                new LinkedHashMap<>();

        List<PayPeriodEntity> payPeriods =
                payPeriodRepository.findAll();

        for (PayPeriodEntity payPeriod : payPeriods) {

            if (payPeriod.getEndDate() == null) {
                continue;
            }

            String monthYear =
                    payPeriod.getEndDate().format(MONTH_FORMAT);

            int cutoffDay =
                    payPeriod.getEndDate().getDayOfMonth();

            monthCutoffs
                    .computeIfAbsent(
                            monthYear,
                            key -> new LinkedHashSet<>()
                    )
                    .add(cutoffDay);
        }

        return monthCutoffs;
    }

    private BigDecimal safe(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }
}