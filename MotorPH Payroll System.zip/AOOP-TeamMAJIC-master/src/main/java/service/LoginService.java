package service;

import entity.UserAccountEntity;
import entity.UserRoleEntity;
import java.security.MessageDigest;
import java.util.List;
import repository.UserAccountRepository;
import repository.UserRoleRepository;


/**
 * Coordinates authentication, session, and role-based access operations.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 */
public class LoginService {

    private static LoginService instance;
    
    private int loggedInUserAccountId;

    private static final String[] SUPPORTED_PERMISSIONS = {
        "Admin", "IT", "HR", "Finance", "Employee"
    };

    private String loggedInEmployeeNumber;
    private String permissionLevel;

    private final UserAccountRepository userAccountRepository;
    private final UserRoleRepository userRoleRepository;

    private LoginService() {
        this.userAccountRepository = new UserAccountRepository();
        this.userRoleRepository = new UserRoleRepository();
        this.loggedInUserAccountId = 0;
    }
    
        public int getLoggedInUserAccountId() {
        return loggedInUserAccountId;
    }

    public static LoginService getInstance() {
        if (instance == null) {
            instance = new LoginService();
        }
        return instance;
    }

    public boolean loginUser(String username, String password) {
        try {
            UserAccountEntity user =
                    userAccountRepository.findByUsername(username);

            if (user == null) {
                System.out.println("Login Failed! User not found.");
                return false;
            }

            if (user.getAccountStatus() == null
                    || user.getAccountStatus()
                    != UserAccountEntity.AccountStatus.Active) {
                System.out.println("Login Failed! Account is inactive.");
                return false;
            }

            String enteredPasswordHash = sha256(password);

            if (!user.getPasswordHash().equalsIgnoreCase(enteredPasswordHash)) {
                System.out.println("Login Failed! Invalid password.");
                return false;
            }

            this.loggedInEmployeeNumber =
                    String.valueOf(user.getEmployeeNumber());
            
            this.loggedInUserAccountId =
                    user.getUserAccountId();

            this.permissionLevel =
                    getPrimaryRoleName(user.getUserAccountId());

            System.out.println("Login Successful!");
            System.out.println("Employee Number: " + loggedInEmployeeNumber);
            System.out.println("Permission Level: " + permissionLevel);

            return true;

        } catch (Exception e) {
            System.out.println("Database login error: " + e.getMessage());
            return false;
        }
    }

    public String getLoggedInEmployeeNumber() {
        return loggedInEmployeeNumber;
    }

    public String getPermissionLevel() {
        return permissionLevel;
    }

    public void logout() {
        loggedInEmployeeNumber = null;
        permissionLevel = null;
        loggedInUserAccountId = 0;
    }

    public boolean isAdmin() {
        return "Admin".equalsIgnoreCase(permissionLevel);
    }

    public boolean isIT() {
        return "IT".equalsIgnoreCase(permissionLevel);
    }

    public boolean isHR() {
        return "HR".equalsIgnoreCase(permissionLevel);
    }

    public boolean isFinance() {
        return "Finance".equalsIgnoreCase(permissionLevel);
    }

    public boolean isEmployee() {
        return "Employee".equalsIgnoreCase(permissionLevel);
    }

    public String[][] getAllUsers() {
        try {
            List<UserAccountEntity> users =
                    userAccountRepository.findAll();

            String[][] data = new String[users.size() + 1][5];

            data[0][0] = "Employee Number";
            data[0][1] = "Username";
            data[0][2] = "Password";
            data[0][3] = "Permission";
            data[0][4] = "Status";

            for (int i = 0; i < users.size(); i++) {
                UserAccountEntity user = users.get(i);

                data[i + 1][0] =
                        String.valueOf(user.getEmployeeNumber());

                data[i + 1][1] =
                        user.getUsername();

                data[i + 1][2] =
                        user.getPasswordHash();

                data[i + 1][3] =
                        getPrimaryRoleName(user.getUserAccountId());

                data[i + 1][4] =
                        user.getAccountStatus() != null
                        ? user.getAccountStatus().name()
                        : "";
            }

            return data;

        } catch (Exception e) {
            System.out.println(
                    "Error reading users from database: "
                    + e.getMessage()
            );
            return new String[0][0];
        }
    }

    public void updateUserPermission(
        String employeeNumber,
        String newPermission) {

        try {

            String normalizedPermission =
                    canonicalizePermission(newPermission);

            List<UserAccountEntity> users =
                    userAccountRepository.findAll();

            UserAccountEntity targetUser = null;

            for (UserAccountEntity user : users) {

                if (String.valueOf(user.getEmployeeNumber())
                        .equals(employeeNumber)) {

                    targetUser = user;
                    break;
                }
            }

            if (targetUser == null) {
                throw new IllegalArgumentException(
                        "User not found."
                );
            }

            int roleId;

            switch (normalizedPermission) {

                case "Admin":
                    roleId = 1;
                    break;

                case "IT":
                    roleId = 2;
                    break;

                case "Finance":
                    roleId = 3;
                    break;

                case "HR":
                    roleId = 4;
                    break;

                case "Employee":
                    roleId = 5;
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Invalid permission."
                    );
            }

            userRoleRepository.replaceRoleForUserAccount(
                    targetUser.getUserAccountId(),
                    roleId
            );

        } catch (Exception e) {

            System.out.println(
                    "Error updating permission: "
                    + e.getMessage()
            );
        }
    }

    public void resetPasswordToDefault(String employeeNumber) {
        try {
            List<UserAccountEntity> users =
                    userAccountRepository.findAll();

            for (UserAccountEntity user : users) {
                if (String.valueOf(user.getEmployeeNumber())
                        .equals(employeeNumber)) {

                    user.setPasswordHash(sha256("password123"));
                    userAccountRepository.update(user);
                    return;
                }
            }

        } catch (Exception e) {
            System.out.println(
                    "Error resetting password in database: "
                    + e.getMessage()
            );
        }
    }

    public static String[] getSupportedPermissions() {
        return SUPPORTED_PERMISSIONS.clone();
    }

    private String getPrimaryRoleName(int userAccountId) {
        List<UserRoleEntity> roles =
                userRoleRepository.findByUserAccountId(userAccountId);

        if (roles == null || roles.isEmpty()) {
            return "Employee";
        }

        UserRoleEntity role = roles.get(0);

        if (role.getSystemRole() == null
                || role.getSystemRole().getRoleName() == null) {
            return "Employee";
        }

        return canonicalizePermission(
                role.getSystemRole().getRoleName()
        );
    }

    private static String canonicalizePermission(String permission) {
        if (permission == null) {
            throw new IllegalArgumentException(
                    "Permission is required."
            );
        }

        String trimmed = permission.trim();

        for (String supported : SUPPORTED_PERMISSIONS) {
            if (supported.equalsIgnoreCase(trimmed)) {
                return supported;
            }
        }

        throw new IllegalArgumentException(
                "Invalid permission. Allowed values: "
                + "Admin, IT, HR, Finance, Employee."
        );
    }

    private String sha256(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes("UTF-8"));

        StringBuilder hexString = new StringBuilder();

        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);

            if (hex.length() == 1) {
                hexString.append('0');
            }

            hexString.append(hex);
        }

        return hexString.toString();
    }
}