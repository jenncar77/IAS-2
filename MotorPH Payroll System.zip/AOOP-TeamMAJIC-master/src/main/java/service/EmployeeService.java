package service;

import entity.AddressEntity;
import entity.EmployeeDetailsEntity;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.EmployeeDetails;
import repository.EmployeeRepository;
import entity.AllowanceEntity;
import entity.CompensationEntity;
import java.math.BigDecimal;
import java.math.RoundingMode;
import repository.AllowanceRepository;
import repository.CompensationRepository;

/**
 * Coordinates employee-related business operations.
 *
 * @author Mary Cel Lobendino
 * @author Jennifer Encarnacion
 * @author Adrian San Juan
 * @author Mark Anthony Diano
 * @author Immaculate De Guzman
 */

public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final CompensationRepository compensationRepository;
    private final AllowanceRepository allowanceRepository;

    public EmployeeService() {
        this.employeeRepository = new EmployeeRepository();
        this.compensationRepository = new CompensationRepository();
        this.allowanceRepository = new AllowanceRepository();
    }

    public List<EmployeeDetailsEntity> getAllEmployeeEntities()
            throws IOException {

        return employeeRepository.findAll();
    }

    public EmployeeDetailsEntity getEmployeeEntityByNumber(
            String employeeNumber) throws IOException {

        return employeeRepository.findByEmployeeNumber(
                Integer.parseInt(employeeNumber)
        );
    }

    public List<Object[]> getEmployeeTableRows() throws IOException {
        List<EmployeeDetailsEntity> entityList =
                employeeRepository.findAll();

        List<Object[]> rows = new ArrayList<>();

        for (EmployeeDetailsEntity entity : entityList) {
            String sss = "";
            String philHealth = "";
            String tin = "";
            String pagibig = "";

            if (entity.getEmployee() != null) {
                sss = safe(entity.getEmployee().getSssNumber());
                philHealth = safe(entity.getEmployee().getPhilhealthNumber());
                tin = safe(entity.getEmployee().getTinNumber());
                pagibig = safe(entity.getEmployee().getPagibigNumber());
            }

            rows.add(new Object[] {
                entity.getEmployeeNumber(),
                safe(entity.getLastName()),
                safe(entity.getFirstName()),
                sss,
                philHealth,
                tin,
                pagibig
            });
        }

        return rows;
    }

    public Object[] getCompensationAndAllowanceFields(String employeeNumber)
            throws IOException {

        int empNo = Integer.parseInt(employeeNumber);

        BigDecimal monthlySalary = BigDecimal.ZERO;
        BigDecimal grossSemiMonthly = BigDecimal.ZERO;
        BigDecimal hourlyRate = BigDecimal.ZERO;

        BigDecimal riceSubsidy = BigDecimal.ZERO;
        BigDecimal phoneAllowance = BigDecimal.ZERO;
        BigDecimal clothingAllowance = BigDecimal.ZERO;

        CompensationEntity compensation =
                compensationRepository.findByEmployeeNumber(empNo);

        if (compensation != null
                && compensation.getMonthlySalary() != null) {

            monthlySalary = compensation.getMonthlySalary();

            grossSemiMonthly = monthlySalary.divide(
                    new BigDecimal("2"),
                    2,
                    RoundingMode.HALF_UP
            );

            hourlyRate = monthlySalary.divide(
                    new BigDecimal("168"),
                    2,
                    RoundingMode.HALF_UP
            );
        }

        List<AllowanceEntity> allowances =
                allowanceRepository.findByEmployeeNumber(empNo);

        for (AllowanceEntity allowance : allowances) {

            if (allowance.getAllowanceType() == null
                    || allowance.getAllowanceType().getAllowanceTypeName() == null
                    || allowance.getAmount() == null) {
                continue;
            }

            String typeName =
                    allowance.getAllowanceType().getAllowanceTypeName();

            if (typeName.equalsIgnoreCase("Rice Subsidy")) {
                riceSubsidy = allowance.getAmount();
            } else if (typeName.equalsIgnoreCase("Phone Allowance")) {
                phoneAllowance = allowance.getAmount();
            } else if (typeName.equalsIgnoreCase("Clothing Allowance")) {
                clothingAllowance = allowance.getAmount();
            }
        }

        return new Object[] {
            monthlySalary,
            riceSubsidy,
            phoneAllowance,
            clothingAllowance,
            grossSemiMonthly,
            hourlyRate
        };
    }

    public void updateEmployeeEntity(EmployeeDetailsEntity employee)
            throws IOException {

        if (employee == null) {
            throw new IllegalArgumentException("Employee cannot be null.");
        }

        employeeRepository.update(employee);
    }

    public void deleteEmployee(String employeeNumber) throws IOException {
        EmployeeDetailsEntity entity =
                employeeRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNumber)
                );

        if (entity == null) {
            throw new IllegalArgumentException("Employee not found.");
        }

        employeeRepository.delete(entity);
    }

    public String generateNextEmployeeNumber() throws IOException {
        List<EmployeeDetailsEntity> employees =
                employeeRepository.findAll();

        int max = 10000;

        for (EmployeeDetailsEntity employee : employees) {
            if (employee.getEmployeeNumber() > max) {
                max = employee.getEmployeeNumber();
            }
        }

        return String.valueOf(max + 1);
    }

    /*
     * Legacy methods below are kept only so older screens still compile.
     * They still get data from MySQL through EmployeeRepository,
     * but they convert it into the old EmployeeDetails model.
     * Use EmployeeDetailsEntity methods for new ORM-based screens.
     */

    public List<EmployeeDetails> getAllEmployees() throws IOException {
        List<EmployeeDetailsEntity> entityList =
                employeeRepository.findAll();

        List<EmployeeDetails> employees = new ArrayList<>();

        for (EmployeeDetailsEntity entity : entityList) {
            employees.add(convertToModel(entity));
        }

        return employees;
    }

    public EmployeeDetails getEmployeeById(String employeeNumber)
            throws IOException {

        EmployeeDetailsEntity entity =
                employeeRepository.findByEmployeeNumber(
                        Integer.parseInt(employeeNumber)
                );

        if (entity == null) {
            return null;
        }

        return convertToModel(entity);
    }

    public EmployeeDetails getEmployeeByNumber(String employeeNumber)
            throws IOException {

        return getEmployeeById(employeeNumber);
    }

    public void addEmployee(EmployeeDetails employee, AddressEntity address) throws IOException {
            if (employee == null) {
                throw new IllegalArgumentException("Employee cannot be null.");
            }

            if (address == null) {
                throw new IllegalArgumentException("Address cannot be null.");
            }

            EmployeeDetailsEntity entity = new EmployeeDetailsEntity();

            entity.setEmployeeNumber(Integer.parseInt(employee.getEmployeeNumber()));
            entity.setLastName(employee.getPerson().getLastName());
            entity.setFirstName(employee.getPerson().getFirstName());
            entity.setBirthday(employee.getPerson().getBirthday());
            entity.setPhoneNumber(employee.getContact().getPhoneNo());
            entity.setAddress(address);

            employeeRepository.saveWithAddress(entity, address);
        }

    public void updateEmployee(EmployeeDetails employee) throws IOException {
        EmployeeDetailsEntity entity =
                employeeRepository.findByEmployeeNumber(
                        Integer.parseInt(employee.getEmployeeNumber())
                );

        if (entity == null) {
            throw new IllegalArgumentException("Employee not found.");
        }

        entity.setLastName(employee.getPerson().getLastName());
        entity.setFirstName(employee.getPerson().getFirstName());
        entity.setPhoneNumber(employee.getContact().getPhoneNo());

        employeeRepository.update(entity);
    }

    private EmployeeDetails convertToModel(EmployeeDetailsEntity entity) {
        String[] row = new String[20];

        row[0] = String.valueOf(entity.getEmployeeNumber());
        row[1] = safe(entity.getLastName());
        row[2] = safe(entity.getFirstName());

        row[3] = entity.getBirthday() != null
                ? entity.getBirthday().toString()
                : "1990-01-01";

        row[4] = "";
        row[5] = safe(entity.getPhoneNumber());
        row[6] = "";

        if (entity.getEmployee() != null) {
            row[7] = safe(entity.getEmployee().getSssNumber());
            row[8] = safe(entity.getEmployee().getPhilhealthNumber());
            row[9] = safe(entity.getEmployee().getTinNumber());
            row[10] = safe(entity.getEmployee().getPagibigNumber());

            if (entity.getEmployee().getEmploymentStatus() != null) {
                row[11] = safe(
                        entity.getEmployee()
                                .getEmploymentStatus()
                                .getEmploymentStatusName()
                );
            } else {
                row[11] = "";
            }

            if (entity.getEmployee().getPosition() != null) {
                row[12] = safe(
                        entity.getEmployee()
                                .getPosition()
                                .getPositionName()
                );
            } else {
                row[12] = "";
            }
        } else {
            row[7] = "";
            row[8] = "";
            row[9] = "";
            row[10] = "";
            row[11] = "";
            row[12] = "";
        }

        row[13] = "";
        row[14] = "0";
        row[15] = "0";
        row[16] = "0";
        row[17] = "0";
        row[18] = "0";
        row[19] = "0";

        return new EmployeeDetails(row);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
    
    public void updateCompensationAndAllowances(
        String employeeNumber,
        double basicSalary,
        double riceSubsidy,
        double phoneAllowance,
        double clothingAllowance
    ) throws IOException {

        int empNo = Integer.parseInt(employeeNumber);

        CompensationEntity compensation =
                compensationRepository.findByEmployeeNumber(empNo);

        if (compensation == null) {
            throw new IllegalArgumentException("Compensation record not found.");
        }

        compensation.setMonthlySalary(BigDecimal.valueOf(basicSalary));
        compensationRepository.update(compensation);

        allowanceRepository.updateAllowanceAmount(empNo, "Rice Subsidy", BigDecimal.valueOf(riceSubsidy));
        allowanceRepository.updateAllowanceAmount(empNo, "Phone Allowance", BigDecimal.valueOf(phoneAllowance));
        allowanceRepository.updateAllowanceAmount(empNo, "Clothing Allowance", BigDecimal.valueOf(clothingAllowance));
    }
    
    public void updateGovernmentIds(
            String employeeNumber,
            String sssNumber,
            String philhealthNumber,
            String tinNumber,
            String pagibigNumber
    ) throws IOException {
        employeeRepository.updateGovernmentIds(
                Integer.parseInt(employeeNumber),
                sssNumber,
                philhealthNumber,
                tinNumber,
                pagibigNumber
        );
    }
}