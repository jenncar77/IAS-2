/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.DeductionEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;      

/**
 *
 * @author Mary
 */
public class DeductionRepository {

    public List<DeductionEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM DeductionEntity",
                    DeductionEntity.class
            ).list();
        }
    }

    public List<DeductionEntity> findByPayrollId(int payrollId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM DeductionEntity d "
                    + "WHERE d.payroll.payrollId = :payrollId",
                    DeductionEntity.class
            )
            .setParameter("payrollId", payrollId)
            .list();
        }
    }

    public DeductionEntity findById(int deductionId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(DeductionEntity.class, deductionId);
        }
    }

    public void save(DeductionEntity deduction) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(deduction);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(DeductionEntity deduction) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(deduction);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(DeductionEntity deduction) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(deduction)
                    ? deduction
                    : session.merge(deduction)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}