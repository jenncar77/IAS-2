/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.PayPeriodEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class PayPeriodRepository {

    public List<PayPeriodEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM PayPeriodEntity",
                    PayPeriodEntity.class
            ).list();
        }
    }

    public PayPeriodEntity findById(int payPeriodId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(PayPeriodEntity.class, payPeriodId);
        }
    }

    public void save(PayPeriodEntity payPeriod) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(payPeriod);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(PayPeriodEntity payPeriod) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.merge(payPeriod);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(PayPeriodEntity payPeriod) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.remove(
                    session.contains(payPeriod)
                    ? payPeriod
                    : session.merge(payPeriod)
            );

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}
