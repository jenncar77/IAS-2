/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.PayrollEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class PayrollRepository {

    public List<PayrollEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM PayrollEntity", PayrollEntity.class)
                    .list();
        }
    }

    public PayrollEntity findById(int payrollId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(PayrollEntity.class, payrollId);
        }
    }

    public List<PayrollEntity> findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM PayrollEntity p WHERE p.employee.employeeNumber = :employeeNumber",
                    PayrollEntity.class
            )
                    .setParameter("employeeNumber", employeeNumber)
                    .list();
        }
    }

    public List<PayrollEntity> findByPayPeriodId(int payPeriodId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM PayrollEntity p WHERE p.payPeriod.payPeriodId = :payPeriodId",
                    PayrollEntity.class
            )
                    .setParameter("payPeriodId", payPeriodId)
                    .list();
        }
    }
    
    public void save(PayrollEntity payroll) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(payroll);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(PayrollEntity payroll) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.merge(payroll);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(PayrollEntity payroll) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.remove(
                    session.contains(payroll)
                    ? payroll
                    : session.merge(payroll)
            );

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}
