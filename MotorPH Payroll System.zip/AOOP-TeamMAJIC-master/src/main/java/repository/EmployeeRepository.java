/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.AddressEntity;
import entity.EmployeeDetailsEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class EmployeeRepository {

    public List<EmployeeDetailsEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM EmployeeDetailsEntity",
                    EmployeeDetailsEntity.class
            ).list();
        }
    }

    public EmployeeDetailsEntity findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(EmployeeDetailsEntity.class, employeeNumber);
        }
    }

    public void save(EmployeeDetailsEntity employeeDetails) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(employeeDetails);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(EmployeeDetailsEntity employeeDetails) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(employeeDetails);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(EmployeeDetailsEntity employeeDetails) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(employeeDetails)
                    ? employeeDetails
                    : session.merge(employeeDetails)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
    
    public void updateGovernmentIds(
        int employeeNumber,
        String sssNumber,
        String philhealthNumber,
        String tinNumber,
        String pagibigNumber
) {
    Transaction transaction = null;

    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        transaction = session.beginTransaction();

        session.createMutationQuery(
                "UPDATE EmployeeEntity e "
                + "SET e.sssNumber = :sssNumber, "
                + "e.philhealthNumber = :philhealthNumber, "
                + "e.tinNumber = :tinNumber, "
                + "e.pagibigNumber = :pagibigNumber "
                + "WHERE e.employeeNumber = :employeeNumber"
        )
        .setParameter("sssNumber", sssNumber)
        .setParameter("philhealthNumber", philhealthNumber)
        .setParameter("tinNumber", tinNumber)
        .setParameter("pagibigNumber", pagibigNumber)
        .setParameter("employeeNumber", employeeNumber)
        .executeUpdate();

        transaction.commit();

    } catch (Exception e) {
        if (transaction != null) {
            transaction.rollback();
        }
        throw e;
    }
        }
    
    public void saveWithAddress(EmployeeDetailsEntity employeeDetails, AddressEntity address) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(address);
            session.persist(employeeDetails);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}