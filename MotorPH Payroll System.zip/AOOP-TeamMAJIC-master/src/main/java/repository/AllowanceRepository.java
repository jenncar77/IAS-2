/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.AllowanceEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class AllowanceRepository {

    public List<AllowanceEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM AllowanceEntity",
                    AllowanceEntity.class
            ).list();
        }
    }

    public List<AllowanceEntity> findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM AllowanceEntity a "
                    + "WHERE a.employee.employeeNumber = :employeeNumber",
                    AllowanceEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .list();
        }
    }

    public AllowanceEntity findById(int allowanceId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(AllowanceEntity.class, allowanceId);
        }
    }

    public void save(AllowanceEntity allowance) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(allowance);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(AllowanceEntity allowance) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.merge(allowance);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(AllowanceEntity allowance) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.remove(
                    session.contains(allowance)
                    ? allowance
                    : session.merge(allowance)
            );

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
    
    public void updateAllowanceAmount(
            int employeeNumber,
            String allowanceTypeName,
            java.math.BigDecimal amount
    ) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            AllowanceEntity allowance = session.createQuery(
                    "FROM AllowanceEntity a "
                    + "WHERE a.employee.employeeNumber = :employeeNumber "
                    + "AND a.allowanceType.allowanceTypeName = :allowanceTypeName",
                    AllowanceEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .setParameter("allowanceTypeName", allowanceTypeName)
            .uniqueResult();

            if (allowance == null) {
                throw new IllegalArgumentException(
                        allowanceTypeName + " record not found."
                );
            }

            allowance.setAmount(amount);

            session.merge(allowance);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}