/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.OvertimeEntity;
import java.time.LocalDate;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class OvertimeRepository {

    public List<OvertimeEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM OvertimeEntity",
                    OvertimeEntity.class
            ).list();
        }
    }

    public List<OvertimeEntity> findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM OvertimeEntity o "
                    + "WHERE o.attendance.employee.employeeNumber = :employeeNumber",
                    OvertimeEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .list();
        }
    }


    public List<OvertimeEntity> findByEmployeeNumberAndDateRange(
            int employeeNumber,
            LocalDate startDate,
            LocalDate endDate
    ) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM OvertimeEntity o "
                    + "WHERE o.attendance.employee.employeeNumber = :employeeNumber "
                    + "AND o.attendance.attendanceDate BETWEEN :startDate AND :endDate",
                    OvertimeEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .setParameter("startDate", startDate)
            .setParameter("endDate", endDate)
            .list();
        }
    }
    public OvertimeEntity findById(int overtimeId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(OvertimeEntity.class, overtimeId);
        }
    }

    public void save(OvertimeEntity overtime) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(overtime);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    public void update(OvertimeEntity overtime) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(overtime);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    public void delete(OvertimeEntity overtime) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(overtime)
                    ? overtime
                    : session.merge(overtime)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }
}