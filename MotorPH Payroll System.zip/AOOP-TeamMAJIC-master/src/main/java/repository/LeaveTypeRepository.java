/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.LeaveTypeEntity;
import java.util.List;
import org.hibernate.Session;

/**
 *
 * @author Mary
 */
public class LeaveTypeRepository {

    public List<LeaveTypeEntity> findAll() {
        try (Session session =
                HibernateUtil.getSessionFactory().openSession()) {

            return session.createQuery(
                    "FROM LeaveTypeEntity ORDER BY leaveTypeId",
                    LeaveTypeEntity.class
            ).list();
        }
    }

    public LeaveTypeEntity findById(int leaveTypeId) {
        try (Session session =
                HibernateUtil.getSessionFactory().openSession()) {

            return session.get(LeaveTypeEntity.class, leaveTypeId);
        }
    }
}
