/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.UserAccountEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class UserAccountRepository {

    public List<UserAccountEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM UserAccountEntity",
                    UserAccountEntity.class
            ).list();
        }
    }

    public UserAccountEntity findById(int userAccountId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(UserAccountEntity.class, userAccountId);
        }
    }

    public UserAccountEntity findByUsername(String username) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM UserAccountEntity u "
                    + "WHERE u.username = :username",
                    UserAccountEntity.class
            )
            .setParameter("username", username)
            .uniqueResult();
        }
    }

    public void save(UserAccountEntity userAccount) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.persist(userAccount);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(UserAccountEntity userAccount) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.merge(userAccount);

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(UserAccountEntity userAccount) {

        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.remove(
                    session.contains(userAccount)
                    ? userAccount
                    : session.merge(userAccount)
            );

            transaction.commit();

        } catch (Exception e) {

            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
    
    public UserAccountEntity findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM UserAccountEntity u "
                    + "WHERE u.employeeNumber = :employeeNumber",
                    UserAccountEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .uniqueResult();
        }
    }
}