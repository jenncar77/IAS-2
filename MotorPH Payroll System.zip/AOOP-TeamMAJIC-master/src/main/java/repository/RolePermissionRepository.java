/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.RolePermissionEntity;
import entity.RolePermissionId;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mary
 */
public class RolePermissionRepository {

    public List<RolePermissionEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM RolePermissionEntity",
                    RolePermissionEntity.class
            ).list();
        }
    }

    public List<RolePermissionEntity> findByRoleId(int systemRoleId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM RolePermissionEntity rp "
                    + "WHERE rp.systemRole.systemRoleId = :systemRoleId",
                    RolePermissionEntity.class
            )
            .setParameter("systemRoleId", systemRoleId)
            .list();
        }
    }

    public RolePermissionEntity findById(RolePermissionId id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(RolePermissionEntity.class, id);
        }
    }

    public void save(RolePermissionEntity rolePermission) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(rolePermission);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    public void delete(RolePermissionEntity rolePermission) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(rolePermission)
                    ? rolePermission
                    : session.merge(rolePermission)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }
}