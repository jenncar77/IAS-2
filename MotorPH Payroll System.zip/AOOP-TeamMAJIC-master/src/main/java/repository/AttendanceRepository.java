/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.AttendanceEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import entity.EmployeeEntity;

/**
 *
 * @author Mary
 */
public class AttendanceRepository {

    public List<AttendanceEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM AttendanceEntity",
                    AttendanceEntity.class
            ).list();
        }
    }

    public List<AttendanceEntity> findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM AttendanceEntity a "
                    + "WHERE a.employee.employeeNumber = :employeeNumber",
                    AttendanceEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .list();
        }
    }

    public AttendanceEntity findById(int attendanceId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(AttendanceEntity.class, attendanceId);
        }
    }

    public void save(AttendanceEntity attendance) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(attendance);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(AttendanceEntity attendance) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(attendance);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(AttendanceEntity attendance) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(attendance)
                    ? attendance
                    : session.merge(attendance)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
    
    public AttendanceEntity findByEmployeeNumberAndDate(
            int employeeNumber,
            java.time.LocalDate attendanceDate) {

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM AttendanceEntity a "
                    + "WHERE a.employee.employeeNumber = :employeeNumber "
                    + "AND a.attendanceDate = :attendanceDate",
                    AttendanceEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .setParameter("attendanceDate", attendanceDate)
            .uniqueResult();
        }
    }
    
    public EmployeeEntity findEmployeeByNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(EmployeeEntity.class, employeeNumber);
        }
    }
}