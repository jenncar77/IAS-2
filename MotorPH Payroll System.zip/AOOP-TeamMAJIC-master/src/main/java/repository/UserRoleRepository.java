/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.UserRoleEntity;
import entity.UserRoleId;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 *
 * @author Mary
 */
public class UserRoleRepository {

    public List<UserRoleEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM UserRoleEntity",
                    UserRoleEntity.class
            ).list();
        }
    }

    public List<UserRoleEntity> findByUserAccountId(int userAccountId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM UserRoleEntity ur "
                    + "WHERE ur.userAccount.userAccountId = :userAccountId",
                    UserRoleEntity.class
            )
            .setParameter("userAccountId", userAccountId)
            .list();
        }
    }

    public UserRoleEntity findById(UserRoleId id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(UserRoleEntity.class, id);
        }
    }

    public void save(UserRoleEntity userRole) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(userRole);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }

    public void delete(UserRoleEntity userRole) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(userRole)
                    ? userRole
                    : session.merge(userRole)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        }
    }
    
    public void replaceRoleForUserAccount(
            int userAccountId,
            int newSystemRoleId) {

        Transaction transaction = null;

        try (Session session =
                HibernateUtil.getSessionFactory().openSession()) {

            transaction = session.beginTransaction();

            session.createMutationQuery(
                    "DELETE FROM UserRoleEntity ur "
                    + "WHERE ur.userAccount.userAccountId = :userAccountId"
            )
            .setParameter("userAccountId", userAccountId)
            .executeUpdate();

            entity.UserAccountEntity userAccount =
                    session.get(entity.UserAccountEntity.class, userAccountId);

            entity.SystemRoleEntity systemRole =
                    session.get(entity.SystemRoleEntity.class, newSystemRoleId);

            UserRoleEntity userRole = new UserRoleEntity();
            userRole.setUserAccount(userAccount);
            userRole.setSystemRole(systemRole);

            UserRoleId id = new UserRoleId();
            id.setUserAccountId(userAccountId);
            id.setSystemRoleId(newSystemRoleId);

            userRole.setId(id);

            session.persist(userRole);

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}