/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import config.HibernateUtil;
import entity.LeaveRequestEntity;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 *
 * @author Mary
 */
public class LeaveRepository {

    public List<LeaveRequestEntity> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM LeaveRequestEntity",
                    LeaveRequestEntity.class
            ).list();
        }
    }

    public List<LeaveRequestEntity> findByEmployeeNumber(int employeeNumber) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM LeaveRequestEntity l "
                    + "WHERE l.employee.employeeNumber = :employeeNumber",
                    LeaveRequestEntity.class
            )
            .setParameter("employeeNumber", employeeNumber)
            .list();
        }
    }

    public LeaveRequestEntity findById(int leaveRequestId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(LeaveRequestEntity.class, leaveRequestId);
        }
    }

    public void save(LeaveRequestEntity leaveRequest) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(leaveRequest);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void update(LeaveRequestEntity leaveRequest) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(leaveRequest);
            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }

    public void delete(LeaveRequestEntity leaveRequest) {
        Transaction transaction = null;

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.remove(
                    session.contains(leaveRequest)
                    ? leaveRequest
                    : session.merge(leaveRequest)
            );

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw e;
        }
    }
}