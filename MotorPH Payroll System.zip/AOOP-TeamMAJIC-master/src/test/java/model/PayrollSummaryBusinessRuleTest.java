package model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PayrollSummaryBusinessRuleTest {

    @Test
    void dailyRateUsesTwentyOneWorkingDays() {
        PayrollSummary summary = new PayrollSummary(
                88.0,
                0.0,
                0.0,
                25000.0,
                21000.0,
                1000.0,
                500.0,
                100.0,
                2400.0,
                4000.0,
                63000.0,
                5000.0
        );

        assertEquals(3000.0, summary.getDailyRate(), 0.01);
    }

    @Test
    void daysWorkedUsesEightHourWorkDay() {
        PayrollSummary summary = new PayrollSummary(
                88.0,
                0.0,
                0.0,
                25000.0,
                21000.0,
                1000.0,
                500.0,
                100.0,
                2400.0,
                4000.0,
                63000.0,
                5000.0
        );

        assertEquals(11.0, summary.getDaysWorked(), 0.01);
    }

    @Test
    void overtimePayUsesHoursRateAndMultiplier() {
        PayrollSummary summary = new PayrollSummary(80.0, 5.0, 250.0, 1.25);

        assertTrue(summary.hasOvertime());
        assertEquals(1562.50, summary.getOvertimePay(), 0.01);
        assertEquals(21562.50, summary.getGrossIncome(), 0.01);
    }

    @Test
    void deductionFlagFollowsTotalDeductions() {
        PayrollSummary withDeductions = new PayrollSummary(
                80.0, 0.0, 0.0,
                20000.0, 18000.0,
                500.0, 300.0, 200.0, 1000.0,
                2000.0
        );
        PayrollSummary withoutDeductions = new PayrollSummary(80.0, 250.0);

        assertTrue(withDeductions.hasDeductions());
        assertFalse(withoutDeductions.hasDeductions());
    }
}