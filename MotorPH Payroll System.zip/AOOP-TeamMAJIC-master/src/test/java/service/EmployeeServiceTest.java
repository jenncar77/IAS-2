/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import model.EmployeeDetails;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Mary
 */
public class EmployeeServiceTest {

    // Test 1 - Existing employee should be found
    @Test
    public void testGetEmployeeByNumber() throws Exception {

        EmployeeService service = new EmployeeService();

        EmployeeDetails employee =
                service.getEmployeeByNumber("10001");

        assertNotNull(employee);
    }

    // Test 2 - Non-existent employee should return null
    @Test
    public void testEmployeeNotFound() throws Exception {

        EmployeeService service = new EmployeeService();

        EmployeeDetails employee =
                service.getEmployeeByNumber("99999");

        assertNull(employee);
    }

    // Test 3 - Employee list should not be empty
    @Test
    public void testGetAllEmployees() throws Exception {

        EmployeeService service = new EmployeeService();

        assertFalse(
                service.getAllEmployees().isEmpty()
        );
    }

    // Test 4 - Generate next employee number
    @Test
    public void testGenerateNextEmployeeNumber()
            throws Exception {

        EmployeeService service = new EmployeeService();

        String nextNumber =
                service.generateNextEmployeeNumber();

        assertNotNull(nextNumber);
        assertFalse(nextNumber.isBlank());
    }

    // Test 5 - Compensation and allowances should exist
    @Test
    public void testGetCompensationAndAllowanceFields()
            throws Exception {

        EmployeeService service = new EmployeeService();

        Object[] fields =
                service.getCompensationAndAllowanceFields(
                        "10001"
                );

        assertNotNull(fields);
        assertEquals(6, fields.length);
    }
    
    // Test 6 - Update employee with null data
    @Test
    public void testUpdateEmployeeEntityNull() {

        EmployeeService service = new EmployeeService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateEmployeeEntity(null)
        );
    }
    
    // Test 7 - Delete non-existent employee
    @Test
    public void testDeleteEmployeeNotFound() {

        EmployeeService service = new EmployeeService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteEmployee("99999")
        );
    }
    
    // Test 8 - Government ID update with valid employee
    @Test
    public void testUpdateGovernmentIds() throws Exception {

        EmployeeService service = new EmployeeService();

        assertDoesNotThrow(
                () -> service.updateGovernmentIds(
                        "10001",
                        "12-3456789-0",
                        "123456789012",
                        "123-456-789-000",
                        "123456789012"
                )
        );
    }
    
    // Test 9 - Compensation update with valid employee
    @Test
    public void testUpdateCompensationAndAllowances()
            throws Exception {

        EmployeeService service = new EmployeeService();

        assertDoesNotThrow(
                () -> service.updateCompensationAndAllowances(
                        "10001",
                        50000,
                        1500,
                        1000,
                        1000
                )
        );
    }
    
    // Test 10 - Invalid compensation record
    @Test
    public void testUpdateCompensationInvalidEmployee() {

        EmployeeService service = new EmployeeService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateCompensationAndAllowances(
                        "99999",
                        50000,
                        1500,
                        1000,
                        1000
                )
        );
    }
    
    
    
}