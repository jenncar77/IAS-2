/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Mary
 */
public class LoginServiceTest {

    // Test 1 - Valid login
    @Test
    public void testValidLogin() {

        LoginService service = LoginService.getInstance();

        boolean result =
                service.loginUser("antonio_lim@motorph.com", "admin12345");

        assertTrue(result);
        assertNotNull(service.getLoggedInEmployeeNumber());
        assertNotNull(service.getPermissionLevel());
    }

    // Test 2 - Invalid password
    @Test
    public void testInvalidLoginIncorrectPassword() {

        LoginService service = LoginService.getInstance();

        boolean result =
                service.loginUser("antonio_lim@motorph.com", "wrongpassword");

        assertFalse(result);
    }

    // Test 3 - Unknown user
    @Test
    public void testInvalidLoginUnknownUser() {

        LoginService service = LoginService.getInstance();

        boolean result =
                service.loginUser("unknown@motorph.com", "admin123");

        assertFalse(result);
    }

    // Test 4 - Logout clears session
    @Test
    public void testLogoutClearsSession() {

        LoginService service = LoginService.getInstance();

        service.logout();

        assertNull(service.getLoggedInEmployeeNumber());
        assertNull(service.getPermissionLevel());
        assertEquals(0, service.getLoggedInUserAccountId());
    }

    // Test 5 - Supported permissions should not be empty
    @Test
    public void testSupportedPermissionsNotEmpty() {

        String[] permissions =
                LoginService.getSupportedPermissions();

        assertNotNull(permissions);
        assertTrue(permissions.length > 0);
    }
}
