/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import model.PayrollSummary;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Mary
 */
public class PayrollServiceTest {
    
//Test 1 - Invalid Employee Number    
    
    @Test
    public void testComputePayrollInvalidEmployee() {

        PayrollService service = new PayrollService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.computePayroll("99999")
        );
    }

//Test 2 - Existing Employee Payroll

    @Test
    public void testComputePayrollValidEmployee() throws Exception {

        PayrollService service = new PayrollService();

        PayrollSummary summary =
                service.computePayroll("10001");

        assertNotNull(summary);
    }

// Test 3 - Invalid Pay Period

    @Test
    public void testGetPayrollSummaryInvalidPeriod() {

        PayrollService service = new PayrollService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getPayrollSummary(
                        "10001",
                        "January 2030",
                        "1st-15th"
                )
        );
    }
    
 // Test 4 - Available Payroll Months 
    
    @Test
    public void testAvailablePayrollMonthsNotEmpty()
            throws Exception {

        PayrollService service = new PayrollService();

        List<String> months =
                service.getAvailablePayrollMonths();

        assertNotNull(months);
        assertFalse(months.isEmpty());
    }
    
// Test 5 - Month Cutoff Mapping   
    @Test
    public void testMonthCutoffMapping()
            throws Exception {

        PayrollService service = new PayrollService();

        Map<String, Set<Integer>> monthCutoffs =
                service.getMonthCutoffs();

        assertNotNull(monthCutoffs);
        assertFalse(monthCutoffs.isEmpty());
    }
    
 // Test 6 - Payroll by Employee should not be empty
        @Test
        public void testGetPayrollByEmployee()
                throws Exception {

            PayrollService service = new PayrollService();

            assertFalse(
                    service.getPayrollByEmployee("10001").isEmpty()
            );
        }
 
// Test 7 - Pay Period list should not be empty
        @Test
        public void testGetAllPayPeriods()
                throws Exception {

            PayrollService service = new PayrollService();

            assertFalse(
                    service.getAllPayPeriods().isEmpty()
            );
        } 
        
// Test 8 - Payroll by valid pay period
        @Test
        public void testGetPayrollByPayPeriod()
                throws Exception {

            PayrollService service = new PayrollService();

            assertNotNull(
                    service.getPayrollByPayPeriod(1)
            );
        } 
        
        
// Test 9 - Available payroll months should contain data
        @Test
        public void testAvailablePayrollMonthsContainsData()
                throws Exception {

            PayrollService service = new PayrollService();

            List<String> months =
                    service.getAvailablePayrollMonths();

            assertTrue(months.size() > 0);
        }
        
        // Test 10 - Month cutoff mapping should contain at least one month
        @Test
        public void testMonthCutoffContainsData()
                throws Exception {

            PayrollService service = new PayrollService();

            Map<String, Set<Integer>> monthCutoffs =
                    service.getMonthCutoffs();

            assertTrue(monthCutoffs.size() > 0);
        }

}
