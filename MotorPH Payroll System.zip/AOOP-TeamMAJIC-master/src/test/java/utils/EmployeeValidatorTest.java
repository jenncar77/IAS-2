/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Mary
 */
public class EmployeeValidatorTest {

    @Test
    public void testFutureJoinDateIsInvalid() {
        LocalDate futureDate = LocalDate.now().plusDays(1);

        assertFalse(EmployeeValidator.isValidBirthday(futureDate));
    }

    @Test
    public void testPhoneNumberFormatInvalid() {
        assertFalse(EmployeeValidator.isValidPhone("abc123"));
    }

    @Test
    public void testTINFormat() {
        assertTrue(EmployeeValidator.isValidTIN("123-456-789-000"));
        assertFalse(EmployeeValidator.isValidTIN("123456789000"));
    }

    @Test
    public void testPhilhealthFormat() {
        assertTrue(EmployeeValidator.isValidPhilHealth("123456789012"));
        assertFalse(EmployeeValidator.isValidPhilHealth("12345"));
    }

    @Test
    public void testPagibigFormat() {
        assertTrue(EmployeeValidator.isValidPagibig("123456789012"));
        assertFalse(EmployeeValidator.isValidPagibig("123"));
    }
}