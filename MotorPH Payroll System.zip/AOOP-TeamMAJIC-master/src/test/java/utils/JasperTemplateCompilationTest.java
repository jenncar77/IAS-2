package utils;

import java.io.InputStream;
import net.sf.jasperreports.engine.JasperCompileManager;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class JasperTemplateCompilationTest {

    @Test
    void employeePayslipTemplateCompiles() throws Exception {
        assertTemplateCompiles("/reports/EmployeePayslip.jrxml");
    }

    @Test
    void monthlyPayrollReportTemplateCompiles() throws Exception {
        assertTemplateCompiles("/reports/PayrollReportPerDepartment.jrxml");
    }

    @Test
    void employeeTimeCardTemplateCompiles() throws Exception {
        assertTemplateCompiles("/reports/EmployeeTimeCard.jrxml");
    }

    private void assertTemplateCompiles(String resourcePath) throws Exception {
        System.setProperty(
                "net.sf.jasperreports.compiler.classpath",
                System.getProperty("java.class.path")
        );

        try (InputStream reportStream = getClass().getResourceAsStream(resourcePath)) {
            assertNotNull(reportStream, resourcePath + " must exist in test classpath");
            assertNotNull(JasperCompileManager.compileReport(reportStream));
        }
    }
}
