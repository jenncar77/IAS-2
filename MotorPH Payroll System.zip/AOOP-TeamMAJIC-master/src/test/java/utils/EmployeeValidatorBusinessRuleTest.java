package utils;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeValidatorBusinessRuleTest {

    @Test
    void completeValidEmployeeUpdateFieldsPassValidation() {
        EmployeeValidator.ValidationResult result = EmployeeValidator.validateEmployeeUpdateFields(
                "Juan",
                "Dela Cruz",
                "123 Main St",
                "Barangay 1",
                "Manila",
                "Metro Manila",
                "1000",
                "0917-123-4567",
                "juan.delacruz@example.com",
                "12-3456789-0",
                "123456789012",
                "123-456-789-000",
                "123456789012",
                "Maria Santos",
                LocalDate.now().minusYears(30),
                "50,000.00",
                "1,500.00",
                "1,000.00",
                "500.00"
        );

        assertTrue(result.isValid());
        assertTrue(result.getErrors().isEmpty());
    }

    @Test
    void employeeMustBeAtLeastEighteenYearsOld() {
        EmployeeValidator.ValidationResult result = EmployeeValidator.validateEmployeeUpdateFields(
                "Juan",
                "Dela Cruz",
                "123 Main St",
                "Barangay 1",
                "Manila",
                "Metro Manila",
                "1000",
                "0917-123-4567",
                "juan.delacruz@example.com",
                "12-3456789-0",
                "123456789012",
                "123-456-789-000",
                "123456789012",
                "Maria Santos",
                LocalDate.now().minusYears(17),
                "50000",
                "1500",
                "1000",
                "500"
        );

        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("Employee must be at least 18 years old."));
    }

    @Test
    void invalidCompensationValuesFailValidation() {
        EmployeeValidator.ValidationResult result = EmployeeValidator.validateEmployeeUpdateFields(
                "Juan",
                "Dela Cruz",
                "123 Main St",
                "Barangay 1",
                "Manila",
                "Metro Manila",
                "1000",
                "0917-123-4567",
                "juan.delacruz@example.com",
                "12-3456789-0",
                "123456789012",
                "123-456-789-000",
                "123456789012",
                "Maria Santos",
                LocalDate.now().minusYears(30),
                "-50000",
                "1500",
                "1000",
                "500"
        );

        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("Salary and allowances must be valid numbers."));
    }
}