# MotorPH Payroll System

## Overview

The MotorPH Payroll System is a desktop-based payroll management application developed in Java as part of the Advanced Object-Oriented Programming (AOOP) course. The system manages employee records, attendance, payroll processing, reporting, and role-based access control.

This version uses **Hibernate ORM** for database persistence, **MySQL** as the backend database, **JasperReports** for PDF report generation, and **JFreeChart** for analytics and visualization.

---

## Features

### Employee Management
- View employee records
- Add new employees
- Update employee information
- Manage employee compensation and allowances
- Store government identification details

### Attendance Management
- Record employee attendance
- Track worked hours
- Maintain attendance history

### Payroll Processing
- Semi-monthly payroll computation
- Gross pay calculation
- Allowance computation
- Government contribution deductions
  - SSS
  - PhilHealth
  - Pag-IBIG
- Withholding tax computation
- Net pay calculation

### Leave Management
- Leave request submission
- Leave approval workflow
- Leave status monitoring

### Overtime Management
- Overtime request submission
- Overtime approval workflow
- Overtime earnings calculation

### Role-Based Access Control (RBAC)
- User authentication
- Role management
- Permission-based access control
- Activity logging

### Reporting
- Employee Payslip PDF Generation
- Monthly Payroll Summary Report
- Payroll Analytics Dashboard
- Data Visualization using JFreeChart

---

## System Architecture

The application follows a layered architecture:

### Presentation Layer
- Java Swing User Interface
- Forms and Dashboard Components

### Service Layer
- Business Logic
- Payroll Computation
- Validation Services
- Authentication Services

### Repository Layer
- Data Access Operations
- Hibernate Repository Pattern

### Persistence Layer
- Hibernate ORM
- MySQL Database

### ORM Migration

The project was originally implemented using CSV-based data storage and DAO classes. As part of AOOP course, the application was migrated to Hibernate ORM with MySQL persistence. Repository classes now handle all database operations through Hibernate sessions and entity mappings.

---

## Technologies Used

| Technology | Purpose |
|------------|---------|
| Java | Application Development |
| Java Swing | User Interface |
| Hibernate ORM | Object Relational Mapping |
| MySQL | Database Management System |
| Maven | Dependency Management |
| JasperReports | PDF Report Generation |
| JFreeChart | Analytics and Charts |
| JUnit 5 | Unit Testing |

---

## Project Structure

```text
.
├── database
│   └── motorph_payroll_system.sql
├── src
│   ├── main
│   │   ├── java
│   │   │   ├── config
│   │   │   ├── entity
│   │   │   ├── model
│   │   │   ├── repository
│   │   │   ├── service
│   │   │   ├── ui
│   │   │   ├── ui.helpers
│   │   │   └── utils
│   │   └── resources
│   │       ├── reports
│   │       ├── images
│   │       └── hibernate.cfg.xml
│   └── test
├── pom.xml
├── README.md
└── .gitignore
```

---

## Database Setup

The SQL dump required to run the application is located at:

database/motorph_payroll_system.sql

Import the SQL dump, which automatically creates and selects the `motorph_payroll_system` database.

```bash
mysql -u root -p < database/motorph_payroll_system.sql

### Hibernate Configuration

Update the database connection settings in:

```text
src/main/resources/hibernate.cfg.xml
```

Example:

```xml
<property name="hibernate.connection.url">
    jdbc:mysql://localhost:3306/motorph_payroll_system
</property>

<property name="hibernate.connection.username">
    root
</property>

<property name="hibernate.connection.password">
    your_password
</property>
```

---

## Running the Application

### Prerequisites

- JDK 24 or later
- MySQL Server 8.0+
- Maven 3.9+

### Steps

1. Clone the repository

```bash
git clone <repository-url>
```

2. Import the SQL dump

> The SQL dump automatically creates and selects the `motorph_payroll_system` database.

```bash
mysql -u root -p < database/motorph_payroll_system.sql
```

3. Configure Hibernate

Update the database credentials in:

```text
src/main/resources/hibernate.cfg.xml
```

4. Build the project

```bash
mvn clean install
```

5. Run the application

```bash
mvn exec:java
```

Or run the main application class directly from NetBeans.

---

## Report Generation

### JasperReports

The system uses JasperReports to generate:

- Employee Payslips
- Payroll Reports

Generated reports are exported as PDF documents.

### JFreeChart

The system uses JFreeChart to display:

- Payroll Analytics
- Employee Distribution
- Department Statistics
- Payroll Trends

---

## Testing

The project uses JUnit 5 for unit testing.

Run tests using:

```bash
mvn test
```

Test coverage includes:

- Employee Validation
- Authentication
- Employee Services
- Payroll Services
- Business Rules

---

## Authors

### Team MAJIC

- Mary Cel Lobendino
- Adrian San Juan
- Jennifer Encarnacion
- Immaculate (Mikee) De Guzman
- Mark Anthony Diano

---

## Notes

This project uses Hibernate ORM and MySQL for persistent data storage. All legacy CSV-based DAO implementations and file-based persistence mechanisms have been removed following the ORM migration.

The repository includes a complete SQL dump located at: database/motorph_payroll_system.sql

Import the SQL dump before running the application to create the required schema and sample data.
